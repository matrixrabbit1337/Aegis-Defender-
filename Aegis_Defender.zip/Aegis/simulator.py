#!/usr/bin/env python3
"""FAKE ransomware — for testing the Aegis detection agent ONLY.

It encrypts files with Fernet, renames them with a `.locked` extension, and
drops ransom notes, mimicking real ransomware behavior closely enough to
exercise detection, process kill, and rollback.

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
SAFETY — READ THIS BEFORE RUNNING
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
This script REFUSES to run unless --target points inside a sandbox directory
whose resolved path starts with <realpath(temp dir)>/aegis-sim-
(e.g. /tmp/aegis-sim-test123 on Linux).

  * /tmp itself            -> REFUSED
  * /tmp/aegis-sim         -> REFUSED (no sandbox id)
  * /home/anything         -> REFUSED
  * /                      -> REFUSED
  * symlinks escaping the sandbox are resolved and REFUSED

It will NEVER touch files outside the sandbox. Run it only against
throwaway test data you created for this purpose.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
"""
from __future__ import annotations

import argparse
import os
import sys
import tempfile
import time

# The OS temp dir, resolved: /tmp on Linux, /var/folders/... (-> /private/...)
# on macOS, %TEMP% on Windows. The guard compares against the resolved base.
SANDBOX_PREFIX = os.path.join(os.path.realpath(tempfile.gettempdir()),
                              "aegis-sim-")

RANSOM_NOTE = """\
ALL YOUR FILES HAVE BEEN ENCRYPTED!

(This is a FAKE ransom note written by the Aegis test simulator.
No real ransomware was involved. Your files can be restored with:
    aegis rollback --since <incident-id>)

To recover your data, send 0.5 BTC to: 1AegisTestSimulatorFakeAddress
Then wait. Forever. (This is a drill.)
"""


def require_sandbox(target: str) -> str:
    """Resolve target and abort unless it is inside /tmp/aegis-sim-*."""
    real = os.path.realpath(os.path.abspath(target))
    if len(real) <= len(SANDBOX_PREFIX) or not real.startswith(SANDBOX_PREFIX):
        sys.stderr.write(
            "[simulator] REFUSED: --target must be inside a sandbox "
            f"directory starting with {SANDBOX_PREFIX!r} "
            f"(got {target!r} -> {real!r}). Aborting.\n")
        sys.exit(2)
    if not os.path.isdir(real):
        sys.stderr.write(f"[simulator] REFUSED: not a directory: {real}\n")
        sys.exit(2)
    return real


def encrypt_tree(root: str) -> int:
    """Encrypt every file under root in place. Returns files encrypted."""
    from cryptography.fernet import Fernet

    key = Fernet.generate_key()
    with open(os.path.join(root, ".sim_key.bin"), "wb") as fh:
        fh.write(key)
    fernet = Fernet(key)
    skip = {".sim_key.bin"}
    count = 0

    for dirpath, _, filenames in os.walk(root):
        # Drop the ransom note first, then encrypt the directory's files —
        # this exercises note + rename + entropy signals in one run.
        with open(os.path.join(dirpath, "HOW_TO_RECOVER.txt"), "w",
                  encoding="utf-8") as fh:
            fh.write(RANSOM_NOTE)
        for fn in sorted(filenames):
            if fn in skip or fn.startswith("HOW_TO_RECOVER"):
                continue
            src = os.path.join(dirpath, fn)
            if os.path.islink(src):
                continue
            with open(src, "rb") as fh:
                data = fh.read()
            token = fernet.encrypt(data)
            # Chunked write with the handle held open: gives the agent's
            # user-space attributor a chance to observe this process on the
            # file (real ransomware does buffered writes too).
            with open(src, "wb") as fh:
                for i in range(0, len(token), 8192):
                    fh.write(token[i:i + 8192])
                    fh.flush()
                    time.sleep(0.01)
            os.replace(src, src + ".locked")
            count += 1
            print(f"[simulator] encrypted {src}", flush=True)
            time.sleep(0.05)
    return count


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="FAKE ransomware for testing Aegis (sandbox-only).")
    parser.add_argument("--target", required=True,
                        help="sandbox dir, must start with /tmp/aegis-sim-")
    args = parser.parse_args(argv)
    root = require_sandbox(args.target)
    print(f"[simulator] starting FAKE ransomware run against {root}",
          flush=True)
    n = encrypt_tree(root)
    print(f"[simulator] encrypted {n} files.", flush=True)
    print("[simulator] awaiting payment. do NOT close this window ;)",
          flush=True)
    time.sleep(120)  # give the agent time to detect and kill us
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
