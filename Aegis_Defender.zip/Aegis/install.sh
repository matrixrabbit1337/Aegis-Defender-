#!/usr/bin/env bash
# Aegis installer dispatcher: runs the installer for this operating system.
#   Linux   -> install_linux.sh
#   macOS   -> install_macos.sh
#   Windows -> install_windows.ps1   (run from PowerShell; see README)
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
case "$(uname -s)" in
    Linux)  exec bash "$DIR/install_linux.sh" "$@" ;;
    Darwin) exec bash "$DIR/install_macos.sh" "$@" ;;
    MINGW*|MSYS*|CYGWIN*)
        echo "On Windows run, from PowerShell:"
        echo "  powershell -ExecutionPolicy Bypass -File .\\install_windows.ps1"
        exit 1 ;;
    *) echo "Unsupported OS: $(uname -s)"; exit 1 ;;
esac
