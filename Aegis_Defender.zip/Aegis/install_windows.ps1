# Aegis installer — WINDOWS (system-wide, no venv).
$ErrorActionPreference = "Stop"
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectDir

function Find-Python {
    $candidates = @(@("py", "-3"), @("python"), @("python3"))
    foreach ($c in $candidates) {
        $exe = $c[0]
        $extra = if ($c.Count -gt 1) { $c[1..($c.Count - 1)] } else { @() }
        if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { continue }
        try {
            $out = & $exe @extra -c "import sys; print('%d.%d' % sys.version_info[:2])" 2>$null
        } catch { continue }
        if ($LASTEXITCODE -eq 0 -and $out -match "^(\d+)\.(\d+)$") {
            $maj = [int]$Matches[1]; $min = [int]$Matches[2]
            if ($maj -gt 3 -or ($maj -eq 3 -and $min -ge 10)) { return ,$c }
        }
    }
    return $null
}

Write-Host "=== Aegis Shield Installer (Windows) ==="
$py = Find-Python
if (-not $py) {
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        $ans = Read-Host "Python not found. Install via winget? [y/N]"
        if ($ans -match "^[Yy]$") {
            winget install --accept-source-agreements --accept-package-agreements Python.Python.3.12
            $env:Path = [Environment]::GetEnvironmentVariable("Path", "Machine") + ";" +
                        [Environment]::GetEnvironmentVariable("Path", "User")
            $py = Find-Python
        }
    }
    if (-not $py) { Write-Host "Install Python 3.10+ then re-run"; exit 1 }
}
$pyExe = $py[0]
$pyExtra = if ($py.Count -gt 1) { $py[1..($py.Count - 1)] } else { @() }
Write-Host "Using Python: $($py -join ' ')"

# ── clean previous install ──────────────────────────────────────────────────
Write-Host ""
Write-Host "[1/4] Removing previous Aegis installation..."
Get-Process -Name "aegis*" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

& $pyExe @pyExtra -m pip uninstall -y aegis 2>$null
if (Test-Path "$ProjectDir\.venv") { Remove-Item -Recurse -Force "$ProjectDir\.venv" }
if (Test-Path "$ProjectDir\aegis.egg-info") { Remove-Item -Recurse -Force "$ProjectDir\aegis.egg-info" }
if (Test-Path "$ProjectDir\build") { Remove-Item -Recurse -Force "$ProjectDir\build" }

$desktop = [Environment]::GetFolderPath("Desktop")
$startMenu = Join-Path ([Environment]::GetFolderPath("Programs")) "Aegis Shield.lnk"
foreach ($old in @(
    (Join-Path $desktop "Aegis Shield.lnk"),
    (Join-Path $desktop "Aegis.lnk"),
    $startMenu
)) {
    if (Test-Path $old) { Remove-Item -Force $old; Write-Host "  Removed: $old" }
}
Get-ChildItem -Path $ProjectDir -Filter "__pycache__" -Recurse -Directory | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  Previous installation cleaned."

# ── install fresh ───────────────────────────────────────────────────────────
Write-Host ""
Write-Host "[2/4] Installing dependencies..."
& $pyExe @pyExtra -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

Write-Host ""
Write-Host "[3/4] Installing Aegis..."
& $pyExe @pyExtra -m pip install -e $ProjectDir
if ($LASTEXITCODE -ne 0) { throw "pip install failed" }

$aegisExe = (Get-Command aegis -ErrorAction SilentlyContinue).Source
if (-not $aegisExe) {
    $scripts = & $pyExe @pyExtra -c "import sysconfig; print(sysconfig.get_path('scripts'))"
    $aegisExe = Join-Path $scripts "aegis.exe"
}
Write-Host "  Aegis binary: $aegisExe"

# ── desktop + start menu shortcuts ──────────────────────────────────────────
Write-Host ""
Write-Host "[4/4] Creating desktop icon..."
$wsh = New-Object -ComObject WScript.Shell

$lnkPath = Join-Path $desktop "Aegis Shield.lnk"
$lnk = $wsh.CreateShortcut($lnkPath)
$lnk.TargetPath = $aegisExe
$lnk.Arguments = "gui"
$lnk.WorkingDirectory = $ProjectDir
$lnk.Description = "Aegis anti-ransomware shield"
$lnk.Save()
Write-Host "  Desktop: $lnkPath"

$lnk2 = $wsh.CreateShortcut($startMenu)
$lnk2.TargetPath = $aegisExe
$lnk2.Arguments = "gui"
$lnk2.WorkingDirectory = $ProjectDir
$lnk2.Description = "Aegis anti-ransomware shield"
$lnk2.Save()
Write-Host "  Start Menu: $startMenu"

Write-Host ""
Write-Host "============================================"
Write-Host "  Aegis Shield installed!"
Write-Host "============================================"
Write-Host "  Launch:  aegis gui"
Write-Host "  Or double-click 'Aegis Shield' on Desktop / Start Menu."
Write-Host ""
