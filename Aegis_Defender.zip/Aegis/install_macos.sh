#!/usr/bin/env bash
# Aegis installer — macOS (system-wide, no venv).
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

[ "$(uname -s)" = "Darwin" ] || { echo "Use install_linux.sh or install_windows.ps1"; exit 1; }

ask() { local a; read -r -p "$1 [y/N] " a < /dev/tty || return 1; [[ "$a" =~ ^[Yy]$ ]]; }

find_python() {
    for c in python3.13 python3.12 python3.11 python3.10 python3; do
        if command -v "$c" >/dev/null 2>&1 &&
           "$c" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
            command -v "$c"; return 0
        fi
    done
    return 1
}

echo "=== Aegis Shield Installer (macOS) ==="
PY="$(find_python || true)"
if [ -z "$PY" ]; then
    if command -v brew >/dev/null 2>&1; then
        ask "Install Python via Homebrew?" && brew install python-tk@3.12
        PY="$(find_python || true)"
    fi
    [ -z "$PY" ] && { echo "Install Python 3.10+ then re-run"; exit 1; }
fi
echo "Using: $("$PY" --version)"

# ── clean previous install ──────────────────────────────────────────────────
echo ""
echo "[1/4] Removing previous Aegis installation..."
pkill -f "aegis watch" 2>/dev/null || true
pkill -f "aegis gui" 2>/dev/null || true
sleep 1

"$PY" -m pip uninstall --break-system-packages -y aegis 2>/dev/null || \
"$PY" -m pip uninstall -y aegis 2>/dev/null || true

for old in "$PROJECT_DIR/.venv" "$HOME/Desktop/Aegis Shield.command" \
           "$HOME/Desktop/Aegis.command" "$HOME/Applications/Aegis Shield.app"; do
    [ -e "$old" ] && { echo "  Removing: $old"; rm -rf "$old"; }
done
rm -rf "$PROJECT_DIR/aegis.egg-info" "$PROJECT_DIR/build" "$PROJECT_DIR/dist"
find "$PROJECT_DIR" -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
echo "  Previous installation cleaned."

# ── install fresh ───────────────────────────────────────────────────────────
echo ""
echo "[2/4] Installing dependencies..."
"$PY" -m pip install --break-system-packages -r requirements.txt || \
"$PY" -m pip install --break-system-packages --user -r requirements.txt

echo ""
echo "[3/4] Installing Aegis..."
"$PY" -m pip install --break-system-packages -e "$PROJECT_DIR" || \
"$PY" -m pip install --break-system-packages --user -e "$PROJECT_DIR"

AEGIS_BIN="$(command -v aegis 2>/dev/null || echo "$("$PY" -c 'import sysconfig; print(sysconfig.get_path("scripts"))')/aegis")"

# ── desktop + Spotlight ─────────────────────────────────────────────────────
echo ""
echo "[4/4] Creating desktop icon..."
if [ -d "$HOME/Desktop" ]; then
    cat > "$HOME/Desktop/Aegis Shield.command" <<LAUNCH
#!/bin/bash
"$AEGIS_BIN" gui
LAUNCH
    chmod +x "$HOME/Desktop/Aegis Shield.command"
    echo "  Desktop: ~/Desktop/Aegis Shield.command"
fi

APP="$HOME/Applications/Aegis Shield.app"
mkdir -p "$APP/Contents/MacOS"
cat > "$APP/Contents/MacOS/aegis-launch" <<LAUNCH
#!/bin/bash
"$AEGIS_BIN" gui
LAUNCH
chmod +x "$APP/Contents/MacOS/aegis-launch"
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>aegis-launch</string>
<key>CFBundleName</key><string>Aegis Shield</string>
<key>CFBundleIdentifier</key><string>com.rabbit1337.aegis</string>
<key>CFBundleVersion</key><string>0.4.1</string>
</dict></plist>
PLIST

echo ""
echo "============================================"
echo "  Aegis Shield installed!"
echo "============================================"
echo "  Launch:  aegis gui"
echo "  Or double-click Aegis Shield on Desktop / Spotlight."
echo ""
