#!/usr/bin/env bash
# Aegis installer — LINUX (system-wide, no venv).
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

[ "$(uname -s)" = "Linux" ] || { echo "Use install_macos.sh or install_windows.ps1"; exit 1; }

ask() { local a; read -r -p "$1 [y/N] " a < /dev/tty || return 1; [[ "$a" =~ ^[Yy]$ ]]; }

have_python() {
    command -v python3 >/dev/null 2>&1 &&
        python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null
}

bootstrap_python() {
    echo "Python 3.10+ not found."
    if command -v apt-get >/dev/null 2>&1; then
        ask "Install via apt?" && sudo apt-get update && sudo apt-get install -y python3 python3-pip python3-tk && return 0
    elif command -v dnf >/dev/null 2>&1; then
        ask "Install via dnf?" && sudo dnf install -y python3 python3-pip python3-tkinter && return 0
    elif command -v pacman >/dev/null 2>&1; then
        ask "Install via pacman?" && sudo pacman -S --noconfirm python python-pip tk && return 0
    fi
    echo "Install Python 3.10+ manually, then re-run ./install_linux.sh"
    exit 1
}

pip_install() {
    # PEP 668 distros (Parrot, Kali, Debian 12+, Ubuntu 23.04+) need
    # --break-system-packages. Errors are shown, not hidden.
    local log; log="$(mktemp)"
    if python3 -m pip install --break-system-packages "$@" 2>"$log"; then
        rm -f "$log"; return 0
    fi
    # older pip without that flag
    if grep -q "no such option: --break-system-packages" "$log"; then
        python3 -m pip install "$@" && { rm -f "$log"; return 0; }
    fi
    # system site-packages not writable -> per-user install
    if python3 -m pip install --break-system-packages --user "$@" 2>>"$log"; then
        rm -f "$log"; return 0
    fi
    echo ""
    echo "pip install failed. Last error:"
    tail -n 15 "$log"
    rm -f "$log"
    echo ""
    echo "Fix: run the installer with sudo:  sudo ./install.sh"
    exit 1
}

pip_uninstall() {
    pip3 uninstall --break-system-packages -y "$@" 2>/dev/null || \
    pip3 uninstall -y "$@" 2>/dev/null || \
    python3 -m pip uninstall --break-system-packages -y "$@" 2>/dev/null || \
    python3 -m pip uninstall -y "$@" 2>/dev/null || true
}

echo "=== Aegis Shield Installer (Linux) ==="
have_python || { bootstrap_python; have_python || exit 1; }
echo "Using: $(python3 --version)"

# ── clean up previous installation ──────────────────────────────────────────
echo ""
echo "[1/4] Removing previous Aegis installation..."

# kill any running aegis process (not this script)
pkill -f "aegis watch" 2>/dev/null || true
pkill -f "aegis gui" 2>/dev/null || true
pkill -f "aegis launch" 2>/dev/null || true
sleep 1

# uninstall old pip package
pip_uninstall aegis

# remove old venv installs (from v0.1–v0.3)
for old_dir in "$PROJECT_DIR/.venv" "$HOME/Desktop/Aegis/.venv" "$HOME/Aegis/.venv"; do
    if [ -d "$old_dir" ]; then
        echo "  Removing old venv: $old_dir"
        rm -rf "$old_dir"
    fi
done

# remove old desktop icons
for old_icon in \
    "$HOME/.local/share/applications/aegis.desktop" \
    "$HOME/Desktop/aegis.desktop" \
    "$HOME/Desktop/Aegis.command"; do
    if [ -f "$old_icon" ]; then
        echo "  Removing old icon: $old_icon"
        rm -f "$old_icon"
    fi
done

# remove old egg-info / build artifacts from the project dir
rm -rf "$PROJECT_DIR/aegis.egg-info" "$PROJECT_DIR/build" "$PROJECT_DIR/dist"
rm -rf "$PROJECT_DIR/__pycache__" "$PROJECT_DIR"/aegis/__pycache__
rm -rf "$PROJECT_DIR"/tests/__pycache__ "$PROJECT_DIR"/.pytest_cache

# remove stale compiled bytecode across the package
find "$PROJECT_DIR" -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null || true
find "$PROJECT_DIR" -name "*.pyc" -delete 2>/dev/null || true

echo "  Previous installation cleaned."

# ── install fresh ───────────────────────────────────────────────────────────
echo ""
echo "[2/4] Installing dependencies..."
pip_install -r requirements.txt

echo ""
echo "[3/4] Installing Aegis..."
pip_install -e "$PROJECT_DIR"

# --user installs put the launcher in ~/.local/bin
export PATH="$HOME/.local/bin:$PATH"
for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
    if [ -f "$rc" ] && ! grep -q '.local/bin' "$rc"; then
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$rc"
    fi
done

# find where aegis landed
AEGIS_BIN="$(command -v aegis 2>/dev/null || echo "$(python3 -c 'import sysconfig; print(sysconfig.get_path("scripts"))')/aegis")"
echo "  Aegis binary: $AEGIS_BIN"

# ── desktop icon ────────────────────────────────────────────────────────────
echo ""
echo "[4/4] Creating desktop icon..."
APPS_DIR="$HOME/.local/share/applications"
mkdir -p "$APPS_DIR"
cat > "$APPS_DIR/aegis.desktop" <<DESK
[Desktop Entry]
Type=Application
Name=Aegis Shield
Comment=Anti-ransomware protection
Exec=$AEGIS_BIN gui
Terminal=false
Categories=Security;Utility;
Icon=security-high
DESK
chmod +x "$APPS_DIR/aegis.desktop"

if [ -d "$HOME/Desktop" ]; then
    cp "$APPS_DIR/aegis.desktop" "$HOME/Desktop/aegis.desktop"
    chmod +x "$HOME/Desktop/aegis.desktop"
    command -v gio >/dev/null 2>&1 && gio set "$HOME/Desktop/aegis.desktop" metadata::trusted true 2>/dev/null || true
    echo "  Desktop icon: ~/Desktop/aegis.desktop"
fi

echo ""
echo "============================================"
echo "  Aegis Shield v$(python3 -c 'from aegis import __version__; print(__version__)' 2>/dev/null || echo '0.4.0') installed!"
echo "============================================"
echo ""
echo "  Launch:  aegis gui"
echo "  Or double-click the Aegis Shield icon on your desktop."
echo ""
