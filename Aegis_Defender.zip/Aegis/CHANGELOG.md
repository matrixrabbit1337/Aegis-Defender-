## 0.4.3 — Language-agnostic defence + root/non-root consistency
Added (research-driven)
- **Any-language attribution:** ransomware in bash, Go, Rust, C, Lua, a
  compiled binary, or AI-generated code is now attributed and killed, not just
  Python. New module aegis/attribution.py combines open-file lookup, a
  recent-writer cache, write-volume, and newest-process heuristics — none of
  which inspect the language. Regression test with a bash+openssl encryptor.
- **Inline freeze on canary trip (kernel mode):** the attacker is suspended in
  microseconds on the kernel answering thread, before the async worker builds
  the incident, so a fast multi-file encryptor can't race ahead. Result: 0
  files lost in testing regardless of file-walk order.
- **Write-intent detection** in the kernel sensor: reads are always allowed;
  only writes are candidates for blocking (via /proc fd flags).
- **More canaries (13):** names that sort first AND last in common filesystem
  walk orders, so a tripwire fires early whichever way ransomware enumerates.
Fixed
- **Root and non-root now behave consistently** — both detect, attribute,
  contain, and roll back. Verified 0/20 files lost in both modes across
  alphabetical, reverse, and random attack orders.
- Canary trips now use the fallback attributor (previously gave up as
  "unattributed" when open-file lookup missed a fast attacker).

## 0.4.2 — Critical full-drive fix
Fixed
- **Root/kernel mode blocked reading your own files.** With full-drive
  protection and `sudo`, simply opening a normal high-entropy file (photo,
  zip) returned "Operation not permitted". The kernel sensor now only blocks
  canary access and new ransomware-extension files on the open path; normal
  reads are always allowed. Encryption is still blocked on the write path.
  Regression test added.
- Full-drive now warns about journal snapshot size and the 100 MB file cap.

## 0.4.1 — Installer fixes for Parrot / Kali / Debian 12+
Fixed
- Install failed on Parrot OS: exact version pins (psutil==6.1.0) made pip try
  to replace the apt-managed psutil 7.0.0. Requirements now use minimum
  versions, so system packages are reused. Tested with psutil 5.9, 7.0 and
  7.2, watchdog 4.0 and 6.0.
- Installer hid pip's real error message; it now shows it.
- Non-root installs fall back to a per-user install (~/.local/bin) and add it
  to PATH in .bashrc and .zshrc.
- Installer removes any previous Aegis version (package, old venvs, old
  icons, caches) before installing.
- Egress guard's new-destination check silently did nothing on psutil 5.x
  (net_connections() missing); falls back to connections().
- pytest moved to requirements-dev.txt (not needed to run Aegis).

## 0.4.0 — Self-hardening + full-drive protection + no-venv install
Added
- **Self-hardening:** AES-256 encrypted state files (journal, incidents,
  canary records, evidence) at rest using machine-bound key derivation.
  Code integrity verification on startup and every 30 seconds (detects
  if an attacker modified Aegis's own source files). Process guard with
  anti-debug detection. Signal trap logs kill attempts.
- **Full-drive protection:** "Protect Entire Drive" button in GUI; `aegis
  setup --full-drive` in CLI. Watches home folder + all data drives.
- **System-wide install:** no venv — `pip install` directly. Desktop icons
  auto-created on all 3 OSes (Linux .desktop, macOS .app + .command,
  Windows Desktop + Start Menu shortcuts). Just double-click to launch.
Fixed
- Duplicate `_is_protected` method removed.
- `allow_dangerous_dirs` default changed to `True` for full-drive mode.

## 0.3.0 — Professional GUI + final bug fixes
Added
- **Professional GUI dashboard** (`aegis gui`): dark theme, real-time threat
  feed, folder management, incident viewer, canary health, settings panel.
  CustomTkinter-based, runs on Linux/macOS/Windows.
- Desktop icons and installers now launch the GUI by default.
Fixed
- Windows: duplicate `_quarantine_source` removed (Python used the broken first
  definition); POSIX absolute paths no longer skipped by the switch filter.
- Lint: removed unused imports and duplicate `_is_protected`.

## 0.2.1 — Cross-platform bug fixes (all 3 OSes)
Fixed
- **Windows:** `normcase` now normalises forward slashes to backslash so
  `C:/Users/x` and `C:\Users\x` compare equal; quarantine correctly
  identifies `.ps1`, `.vbs` and `.cmd` scripts run by an interpreter even
  when the args include `/Flag` style switches; `os_critical` never-kill list
  now case-insensitive.
- **All OSes:** `_quarantine_source` no longer skips POSIX absolute paths
  (e.g. `/home/user/evil.py`) because they start with `/`; the Windows-switch
  filter now only skips short flag-like tokens with no extension or separator.
- Removed duplicate `_quarantine_source` definition that silently shadowed the
  correct implementation (Python uses the first definition found).
- `macOS` attribution note updated: with `psutil.open_files()` + suspect-first
  containment the agent now suspends and kills attributed processes on macOS.

# Changelog

## 0.3.0
- Prevention on Windows/macOS/Linux without certificates: suspend-first
  containment freezes the attacker's process tree on detection, then kills it.
- Cross-OS test suite runs the real attack with each OS adapter forced.
- macOS attribution note corrected; removed dead `watcher.py`.

## 0.2.0
Added (research-driven)
- **Linux kernel sensor** (`fanotify`): real pre-write BLOCKING of ransomware,
  stopping encryption before any bytes land (root). Fail-open, never freezes
  the filesystem. Dedicated test proves a blocked write.
- **Recovery-inhibition guard (MITRE T1490):** detects shadow-copy deletion
  (`vssadmin`/`wmic`/`resize`), 2026 recovery-disruption (`reagentc /disable`,
  `cipher /w`, `diskpart` partition removal, log clearing), ESXi VM kill, and
  BYOVD drivers — the near-universal step just before encryption.
- **Exfiltration/egress guard (Phase E):** correlates transfer tools (rclone,
  MEGA, curl…), archive staging, novel destinations and bulk volume.
- **Threat intel module:** known ransomware file extensions (.akira, .lockbit,
  .royal, .avoslinux…) and family ransom-note names feed scoring.
- **Phase-A event contract + evidence log:** one cross-platform schema; every
  action carries a reason code in an append-only log.
- **Protected-store & persistence tripwires**; pre-modification copy path.
- Dry-run/audit mode across the whole pipeline.
- 31 new tests (101 total), incl. a live kernel-blocking test.


## 0.1.1
Fixed
- **Data loss:** rollback deleted files the snapshot never backed up (over the
  size cap, symlinks, locked/unreadable). They are now recorded as skipped,
  reported as "not backed up", and never deleted or overwritten.
- Rollback verifies backup hashes before and after restoring, writes
  atomically, never deletes canaries, and re-arms tripped canaries.
- `rollback --dry-run` and a confirmation prompt (`--yes` to skip).
- Canary trips never trigger the "top writer" guess; unattributed incidents
  alert but kill nothing. OS-critical processes are never killed.
- One attack = one incident (triggers are merged; a late attributed PID is
  still acted on).
- Baseline ids are unique; the newest baseline and those needed by unresolved
  incidents are never rotated away.
- Quarantine stores the script, not the interpreter.
- Canaries seeded while the watcher runs are picked up; zip canary is
  deterministic.
- Desktop launcher runs `aegis launch` (first-run setup, stays open on error).
- Config validation; refusal of home/system directories.
- `aegis.exe` recognised as the agent itself on Windows.

Added
- Per-OS adapters: `aegis/platforms/{linux,macos,windows}.py`.
- Per-OS installers: `install_linux.sh`, `install_macos.sh`,
  `install_windows.ps1` (`install.sh` dispatches; `install.ps1` is a shim).
- macOS: no I/O-counter sampling (psutil has none); case-insensitive paths on
  macOS/Windows; junctions skipped on Windows.
- `aegis setup`, `aegis launch`, `--version`; per-OS default state/config dirs.
- 38 new tests; GitHub Actions matrix (Linux/macOS/Windows).
