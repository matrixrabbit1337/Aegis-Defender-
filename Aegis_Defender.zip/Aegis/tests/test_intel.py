"""Research-derived threat-intel detectors."""
import pytest

from aegis.intel import (is_ransom_extension, matches_recovery_inhibit,
                         note_patterns, KNOWN_RANSOM_EXTS)


@pytest.mark.parametrize("path,hit", [
    ("/x/report.docx.akira", True),
    ("/x/data.lockbit", True),
    ("/x/f.txt.royal", True),
    ("/x/vm.avoslinux", True),
    ("/x/photo.jpg", False),
    ("/x/archive.zip", False),
])
def test_known_ransom_extensions(path, hit):
    assert is_ransom_extension(path) is hit


@pytest.mark.parametrize("cmd", [
    "vssadmin.exe Delete Shadows /all /quiet",
    "wmic shadowcopy delete /nointeractive",
    "vssadmin resize shadowstorage /for=c: /on=c: /maxsize=401MB",
    "reagentc /disable",
    "cmd.exe /c cipher /w:D:\\ >nul 2>&1",
    "powershell diskpart /s script.txt  delete",
    "wevtutil cl Security",
    "bcdedit /set {default} bootstatuspolicy ignoreallfailures",
    "esxcli vm process kill --type=force --world-id=12",
    "wbadmin delete catalog -quiet",
])
def test_recovery_inhibition_commands_detected(cmd):
    assert matches_recovery_inhibit(cmd)


@pytest.mark.parametrize("cmd", [
    "python train.py", "ls -la /home", "git commit -m vss",
    "cp a b", "vssadmin list shadows",  # listing is not deleting
])
def test_benign_commands_not_flagged(cmd):
    assert matches_recovery_inhibit(cmd) is None


def test_byovd_driver_names_flagged():
    assert matches_recovery_inhibit("sc create x binpath= C:\\gdrv.sys")
    assert matches_recovery_inhibit("loaddriver rtcore64.sys")


def test_note_patterns_include_family_specific():
    pats = " ".join(note_patterns())
    assert "akira_readme" in pats
    assert "darkside_readme" in pats


@pytest.mark.parametrize("cmd", [
    "tmutil deletelocalsnapshots /",
    "tmutil disable",
    "log erase --all",
    "net stop vss /y",
    'sc.exe config "VeeamBackupSvc" start= disabled',
    "net stop SQLWriter",
    "systemctl stop restic-backup.timer",
])
def test_macos_and_service_stop_detected(cmd):
    assert matches_recovery_inhibit(cmd)


def test_unrelated_service_ops_not_flagged():
    assert matches_recovery_inhibit("net stop spooler") is None
    assert matches_recovery_inhibit("systemctl stop nginx") is None
