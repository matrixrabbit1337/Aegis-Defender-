"""Linux fanotify kernel sensor — real pre-write blocking (root only)."""
import os
import sys
import time
import uuid
import shutil

import pytest

pytestmark = pytest.mark.skipif(
    not sys.platform.startswith("linux"),
    reason="fanotify is Linux-only")


def _root():
    return hasattr(os, "geteuid") and os.geteuid() == 0


def test_available_reports_root_requirement():
    from aegis.sensors.fanotify_sensor import available
    ok, why = available()
    if _root():
        assert ok, why
    else:
        assert not ok and "root" in why.lower()


@pytest.mark.skipif(not _root(), reason="needs root for permission events")
def test_kernel_sensor_blocks_canary_write(tmp_path):
    """A process writing a canary is DENIED at the kernel before bytes land."""
    from aegis.config import default_config
    from aegis.agent import AegisAgent
    from aegis.canary import CanaryManager

    sandbox = f"/tmp/aegis-sim-kern-{uuid.uuid4().hex[:8]}"
    os.makedirs(sandbox)
    state = str(tmp_path / "state")
    try:
        cfg = default_config()
        cfg["protected_dirs"] = [sandbox]
        cfg["state_dir"] = state
        cfg["sensor"]["mode"] = "kernel"
        cfg["recovery_guard"]["enabled"] = False
        cfg["egress"]["enabled"] = False
        seeded = CanaryManager(state).seed(
            [sandbox], cfg["canaries"]["filenames"])
        assert seeded
        agent = AegisAgent(cfg)
        agent.start()
        assert getattr(agent.sensor, "blocking", False), \
            "expected the blocking kernel sensor"
        time.sleep(0.5)
        # A CHILD process writes the canary (fanotify does not deliver perm
        # events for the agent's own pid). The kernel suspends the open and
        # asks Aegis; the canary verdict -> DENY, so the child sees EACCES.
        canary = seeded[0]
        import subprocess
        rc = subprocess.run(
            [sys.executable, "-c",
             f"open({canary!r}, 'r+b').write(b'ENCRYPTED')"],
            capture_output=True, text=True)
        time.sleep(1.0)
        incidents = agent.journal.list_incidents()
        agent.stop()
        blocked = ("Permission" in rc.stderr or rc.returncode != 0)
        assert blocked or incidents, (
            "kernel sensor neither blocked the write nor raised an incident; "
            f"child rc={rc.returncode} stderr={rc.stderr!r}")
        # and the canary bytes must be intact (write never landed)
        from aegis.canary import CanaryManager as _CM
        assert _CM(state).check(canary) is None or blocked
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)
