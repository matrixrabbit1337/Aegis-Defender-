"""Self-hardening tests: encryption, integrity, anti-tamper."""
import json
import os
import tempfile
import shutil

from aegis.hardening import StateEncryptor, IntegrityVerifier, derive_key


def test_encryption_round_trip():
    d = tempfile.mkdtemp()
    try:
        enc = StateEncryptor(d)
        original = {"incidents": [1, 2, 3], "secret": "canary_locations"}
        path = os.path.join(d, "data.json")
        enc.encrypt_json(path, original)
        # raw file is NOT readable JSON
        raw = open(path, "rb").read()
        assert raw.startswith(b"AEGIS-ENC-V1")
        try:
            json.loads(raw)
            assert False, "encrypted file should not parse as JSON"
        except (json.JSONDecodeError, UnicodeDecodeError):
            pass
        # but decryption recovers it
        recovered = enc.decrypt_json(path)
        assert recovered == original
    finally:
        shutil.rmtree(d)


def test_different_machines_get_different_keys():
    salt = os.urandom(32)
    k1 = derive_key(salt, b"password1")
    k2 = derive_key(salt, b"password2")
    assert k1 != k2
    assert len(k1) == 32


def test_legacy_plaintext_still_readable():
    """Files written before encryption was added should still load."""
    d = tempfile.mkdtemp()
    try:
        enc = StateEncryptor(d)
        path = os.path.join(d, "legacy.json")
        with open(path, "w") as f:
            json.dump({"old": "data"}, f)
        result = enc.decrypt_json(path)
        assert result == {"old": "data"}
    finally:
        shutil.rmtree(d)


def test_encrypt_file_in_place():
    d = tempfile.mkdtemp()
    try:
        enc = StateEncryptor(d)
        path = os.path.join(d, "secret.txt")
        with open(path, "wb") as f:
            f.write(b"top secret data")
        enc.encrypt_file(path)
        raw = open(path, "rb").read()
        assert b"top secret" not in raw
        assert raw.startswith(b"AEGIS-ENC-V1")
        plain = enc.decrypt_file(path)
        assert plain == b"top secret data"
    finally:
        shutil.rmtree(d)


def test_code_integrity_detects_tampering():
    v = IntegrityVerifier()
    assert v.verify() == [], "clean baseline should pass"
    # simulate tampering by changing a hash
    first_file = list(v._baseline.keys())[0]
    v._baseline[first_file] = "000000deadbeef"
    tampered = v.verify()
    assert first_file in tampered


def test_key_salt_file_created_and_reused():
    d = tempfile.mkdtemp()
    try:
        enc1 = StateEncryptor(d)
        salt1 = enc1._salt
        enc2 = StateEncryptor(d)
        assert enc2._salt == salt1, "salt should be reused from file"
        # encrypted by enc1 is decryptable by enc2
        path = os.path.join(d, "cross.json")
        enc1.encrypt_json(path, {"x": 1})
        assert enc2.decrypt_json(path) == {"x": 1}
    finally:
        shutil.rmtree(d)
