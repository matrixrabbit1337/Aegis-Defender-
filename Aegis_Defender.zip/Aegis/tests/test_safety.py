"""Round-3 safety tests: scope confinement, journal caps, rollback boundaries.

These prove the agent cannot act outside what the user configured, no matter
what happens elsewhere on the system.
"""
import os
import time

from aegis.agent import AegisAgent
from aegis.config import default_config
from aegis.journal import Journal


def _cfg(state, dirs, **overrides):
    cfg = default_config()
    cfg["state_dir"] = str(state)
    cfg["protected_dirs"] = [str(d) for d in dirs]
    for section, values in overrides.items():
        cfg[section].update(values)
    return cfg


def test_agent_ignores_unprotected_directories(tmp_path):
    watched = tmp_path / "watched"
    watched.mkdir()
    elsewhere = tmp_path / "elsewhere"
    elsewhere.mkdir()
    (elsewhere / "innocent.txt").write_bytes(b"do not touch")

    agent = AegisAgent(_cfg(tmp_path / "state", [watched]))
    agent.start()
    try:
        time.sleep(0.5)
        # Adversarial activity OUTSIDE the protected dir: ransom-note names,
        # high-entropy writes, mass renames — none of it may register.
        (elsewhere / "HOW_TO_RECOVER.txt").write_text("pay me")
        (elsewhere / "data.bin").write_bytes(os.urandom(8192))
        for i in range(5):
            p = elsewhere / f"f{i}.txt"
            p.write_bytes(b"x")
            os.replace(p, elsewhere / f"f{i}.txt.locked")
        time.sleep(2)  # let any (unexpected) events propagate
        assert agent.engine.trigger_log == []
        journal = agent.journal
        manifest = journal.baseline_dir / journal.last_baseline_id
        assert (manifest / "manifest.json").exists()
    finally:
        agent.stop()
    # and the files are untouched
    assert (elsewhere / "innocent.txt").read_bytes() == b"do not touch"


def test_in_scope_excludes_state_dir(tmp_path):
    watched = tmp_path / "watched"
    watched.mkdir()
    agent = AegisAgent(_cfg(tmp_path / "state", [watched]))
    assert agent._in_scope(str(watched / "file.txt"))
    assert not agent._in_scope(str(tmp_path / "state" / "journal" / "x"))
    assert not agent._in_scope(str(tmp_path / "other" / "file.txt"))


def test_journal_respects_max_file_mb(tmp_path):
    protected = tmp_path / "docs"
    protected.mkdir()
    (protected / "small.txt").write_bytes(b"small")
    (protected / "big.bin").write_bytes(os.urandom(200 * 1024))  # 200 KiB

    cfg = _cfg(tmp_path / "state", [protected], journal={"max_file_mb": 0.1})
    journal = Journal(str(tmp_path / "state"), cfg)
    bid = journal.take_baseline([str(protected)])
    import json
    manifest = json.loads(
        (journal.baseline_dir / bid / "manifest.json").read_text())
    keys = " ".join(manifest["files"])
    assert "small.txt" in keys
    assert "big.bin" not in keys  # over the cap: not snapshotted


def test_journal_evicts_old_baselines(tmp_path):
    protected = tmp_path / "docs"
    protected.mkdir()
    (protected / "a.txt").write_bytes(os.urandom(8192))  # ~8.5 KiB/baseline

    # cap fits one baseline (~8.5 KiB) but not two (~17 KiB)
    cfg = _cfg(tmp_path / "state", [protected], journal={"max_total_mb": 0.01})
    journal = Journal(str(tmp_path / "state"), cfg)
    first = journal.take_baseline([str(protected)])
    assert first in [p.name for p in journal.baseline_dir.iterdir()]
    time.sleep(1.1)
    second = journal.take_baseline([str(protected)])
    remaining = [p.name for p in journal.baseline_dir.iterdir() if p.is_dir()]
    assert second in remaining
    assert first not in remaining  # evicted past the cap


def test_rollback_never_touches_outside_protected_dirs(tmp_path):
    watched = tmp_path / "watched"
    watched.mkdir()
    (watched / "keep.txt").write_bytes(b"original")
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "precious.txt").write_bytes(b"do not touch")

    cfg = _cfg(tmp_path / "state", [watched])
    journal = Journal(str(tmp_path / "state"), cfg)
    bid = journal.take_baseline([str(watched)])
    (watched / "keep.txt").write_bytes(b"ENCRYPTED")
    (outside / "precious.txt").write_bytes(b"CHANGED BY ATTACKER")
    (outside / "HOW_TO_RECOVER.txt").write_text("pay me")
    iid = journal.create_incident({"baseline_id": bid, "reasons": ["test"]})

    stats = journal.rollback(iid)
    assert stats["failed"] == []
    assert (watched / "keep.txt").read_bytes() == b"original"
    # outside the protected dir: completely untouched by rollback
    assert (outside / "precious.txt").read_bytes() == b"CHANGED BY ATTACKER"
    assert (outside / "HOW_TO_RECOVER.txt").exists()
