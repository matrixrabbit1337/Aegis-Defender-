"""Regression tests for the bugs found in the Phase-1 review."""
import json
import os
import time

import pytest

from aegis.canary import CanaryManager
from aegis.config import default_config, _finalize
from aegis.heuristics import (DetectionEngine, FileEvent, ProcessAttributor,
                              looks_like_aegis_agent)
from aegis.journal import Journal
from aegis.response import Responder


def _cfg(state, dirs, **over):
    cfg = default_config()
    cfg["state_dir"] = str(state)
    cfg["protected_dirs"] = [str(d) for d in dirs]
    for k, v in over.items():
        cfg[k].update(v)
    return cfg


def _incident(journal, bid):
    return journal.create_incident({"baseline_id": bid, "reasons": ["t"]})


# --- bug 1: files not in the baseline must never be deleted -----------------

def test_rollback_never_deletes_files_over_size_cap(tmp_path):
    d = tmp_path / "docs"
    d.mkdir()
    (d / "small.txt").write_bytes(b"small original")
    big = d / "big.bin"
    big.write_bytes(os.urandom(300 * 1024))
    cfg = _cfg(tmp_path / "st", [d], journal={"max_file_mb": 0.1})
    j = Journal(tmp_path / "st", cfg)
    bid = j.take_baseline([str(d)])
    manifest = json.loads(
        (j.baseline_dir / bid / "manifest.json").read_text())
    assert any("big.bin" in k for k in manifest["skipped"])

    (d / "small.txt").write_bytes(b"ENCRYPTED")
    stats = j.rollback(_incident(j, bid))
    assert big.exists(), "rollback deleted a file it never backed up!"
    assert (d / "small.txt").read_bytes() == b"small original"
    assert any("big.bin" in p for p, _ in stats["not_backed_up"])


def test_rollback_never_deletes_symlinks_or_unreadable(tmp_path):
    if os.name == "nt":
        pytest.skip("symlink creation needs privileges on Windows")
    d = tmp_path / "docs"
    d.mkdir()
    (d / "a.txt").write_bytes(b"a")
    os.symlink(str(d / "a.txt"), str(d / "link.txt"))
    j = Journal(tmp_path / "st", _cfg(tmp_path / "st", [d]))
    bid = j.take_baseline([str(d)])
    j.rollback(_incident(j, bid))
    assert os.path.islink(d / "link.txt")


# --- bug 2: dry run changes nothing ------------------------------------------

def test_dry_run_changes_nothing(tmp_path):
    d = tmp_path / "docs"
    d.mkdir()
    (d / "a.txt").write_bytes(b"original")
    j = Journal(tmp_path / "st", _cfg(tmp_path / "st", [d]))
    bid = j.take_baseline([str(d)])
    (d / "a.txt").write_bytes(b"ENCRYPTED")
    (d / "note.txt").write_bytes(b"ransom")
    iid = _incident(j, bid)
    plan = j.rollback(iid, dry_run=True)
    assert plan["dry_run"] and str(d / "a.txt") in plan["restored"]
    assert str(d / "note.txt") in plan["deleted"]
    assert (d / "a.txt").read_bytes() == b"ENCRYPTED"
    assert (d / "note.txt").exists()
    assert not j.load_incident(iid).get("rolled_back")


# --- hash verification --------------------------------------------------------

def test_corrupt_backup_is_not_restored(tmp_path):
    d = tmp_path / "docs"
    d.mkdir()
    (d / "a.txt").write_bytes(b"original")
    j = Journal(tmp_path / "st", _cfg(tmp_path / "st", [d]))
    bid = j.take_baseline([str(d)])
    backup = next((j.baseline_dir / bid).rglob("a.txt"))
    backup.write_bytes(b"tampered backup")
    (d / "a.txt").write_bytes(b"ENCRYPTED")
    stats = j.rollback(_incident(j, bid))
    assert stats["failed"], "corrupt backup must be reported"
    assert (d / "a.txt").read_bytes() == b"ENCRYPTED"  # left alone


# --- canaries survive rollback ----------------------------------------------------

def test_canaries_not_deleted_and_rearmed(tmp_path):
    d = tmp_path / "docs"
    d.mkdir()
    (d / "a.txt").write_bytes(b"x")
    cfg = _cfg(tmp_path / "st", [d])
    j = Journal(tmp_path / "st", cfg)
    bid = j.take_baseline([str(d)])           # baseline BEFORE canaries
    cm = CanaryManager(tmp_path / "st")
    seeded = cm.seed([str(d)], ["2024_tax_return.pdf", "w2_forms_backup.zip"])
    assert seeded
    for p in seeded:
        open(p, "wb").write(b"ENCRYPTED")
    stats = j.rollback(_incident(j, bid))
    for p in seeded:
        assert os.path.exists(p), "canary was deleted by rollback"
    cm2 = CanaryManager(tmp_path / "st")
    assert all(s is None for _, s in cm2.verify_all())
    assert stats["canaries_restored"]


def test_zip_canary_is_deterministic():
    a = CanaryManager._decoy_bytes("w2_forms_backup.zip")
    time.sleep(1.1)
    assert a == CanaryManager._decoy_bytes("w2_forms_backup.zip")


def test_canary_seeded_after_start_is_noticed(tmp_path):
    d = tmp_path / "docs"
    d.mkdir()
    watcher_side = CanaryManager(tmp_path / "st")
    assert watcher_side.count == 0
    CanaryManager(tmp_path / "st").seed([str(d)], ["2024_tax_return.pdf"])
    watcher_side._last_check = 0
    assert watcher_side.is_canary(str(d / "2024_tax_return.pdf"))


# --- baseline rotation safety -----------------------------------------------------

def test_newest_and_incident_baselines_are_pinned(tmp_path):
    d = tmp_path / "docs"
    d.mkdir()
    (d / "a.bin").write_bytes(os.urandom(8192))
    cfg = _cfg(tmp_path / "st", [d], journal={"max_total_mb": 0.001})
    j = Journal(tmp_path / "st", cfg)
    first = j.take_baseline([str(d)])
    iid = _incident(j, first)               # unresolved incident pins `first`
    second = j.take_baseline([str(d)])
    names = {p.name for p in j.baseline_dir.iterdir()}
    assert first in names and second in names
    j.rollback(iid)                           # resolves -> unpinned
    third = j.take_baseline([str(d)])
    names = {p.name for p in j.baseline_dir.iterdir()}
    assert first not in names and third in names


def test_baseline_ids_unique_within_one_second(tmp_path):
    d = tmp_path / "docs"
    d.mkdir()
    j = Journal(tmp_path / "st", _cfg(tmp_path / "st", [d]))
    assert j.take_baseline([str(d)]) != j.take_baseline([str(d)])


# --- bug 3: no guessing for canary trips ------------------------------------------

class _FakeAttributor(ProcessAttributor):
    def __init__(self, cfg, top):
        super().__init__(cfg)
        self._top = top

    def top_writer(self):
        return self._top

    def _valid_target(self, pid):
        return bool(pid)


def test_canary_trip_never_uses_top_writer_guess(tmp_path):
    cfg = _cfg(tmp_path / "st", [tmp_path])
    att = _FakeAttributor(cfg, top=4242)
    assert att.resolve(preferred=None, allow_fallback=False) is None
    assert att.resolve(preferred=None, allow_fallback=True) == 4242
    assert att.resolve(preferred=77, allow_fallback=False) == 77


def test_top_writer_fallback_can_be_disabled(tmp_path):
    cfg = _cfg(tmp_path / "st", [tmp_path],
               attribution={"top_writer_fallback": False})
    assert _FakeAttributor(cfg, top=4242).resolve(None) is None


def test_engine_canary_fire_uses_language_agnostic_fallback(tmp_path):
    # A canary trip is high-confidence, so when open-file attribution misses
    # (fast attacker in any language), Aegis falls back to the write-volume
    # guess rather than giving up. This lets it KILL bash/Go/Rust/compiled
    # encryptors, not just Python ones.
    cfg = _cfg(tmp_path / "st", [tmp_path])
    att = _FakeAttributor(cfg, top=4242)
    eng = DetectionEngine(cfg, att)
    got = []
    eng.on_trigger = lambda pid, r, s, c: got.append(pid)
    eng.handle_event(FileEvent(kind="modified", src="x", canary=True))
    assert got == [4242]  # fallback attributed the top writer


# --- bug 4: one attack = one incident ---------------------------------------------

def test_triggers_merge_into_one_incident_and_late_pid_is_acted_on(tmp_path):
    cfg = _cfg(tmp_path / "st", [tmp_path])
    j = Journal(tmp_path / "st", cfg)
    j.last_baseline_id = "base-x"
    r = Responder(cfg, j)
    killed = []
    r.containment.contain = lambda pid: (killed.append(pid) or
        {"suspended": [pid], "killed": True, "latency_ms": 0.1})
    r._describe = lambda pid: {"pid": pid, "name": "evil", "exe": None,
                               "cmdline": []}
    r._alert = lambda *a, **k: None
    first = r.handle_trigger(None, ["canary"], 1e6)
    second = r.handle_trigger(None, ["canary again"], 1e6)
    third = r.handle_trigger(555, ["entropy burst"], 60)
    assert first == second == third
    assert len(j.list_incidents()) == 1
    info = j.load_incident(first)
    assert killed == [555] and info["killed"] and info["pid"] == 555
    assert {"canary", "entropy burst"} <= set(info["reasons"])


def test_unattributed_trigger_records_note_and_kills_nothing(tmp_path):
    cfg = _cfg(tmp_path / "st", [tmp_path])
    j = Journal(tmp_path / "st", cfg)
    r = Responder(cfg, j)
    r.containment.contain = lambda pid: pytest.fail("must not contain")
    r._alert = lambda *a, **k: None
    iid = r.handle_trigger(None, ["canary"], 1e6)
    info = j.load_incident(iid)
    assert info["killed"] is False and "attributed" in info["note"]


def test_os_critical_process_not_killed(tmp_path):
    cfg = _cfg(tmp_path / "st", [tmp_path])
    r = Responder(cfg, Journal(tmp_path / "st", cfg))
    r.containment.contain = lambda pid: pytest.fail("must not contain")
    r._alert = lambda *a, **k: None
    r._describe = lambda pid: {"pid": pid, "name": r.plat.never_kill_names
                               and sorted(r.plat.never_kill_names)[0]}
    iid = r.handle_trigger(4242, ["x"], 100)
    assert "OS-critical" in r.journal.load_incident(iid)["note"]


# --- bug 6: quarantine the script, not the interpreter -----------------------------

def test_quarantine_prefers_script_over_interpreter(tmp_path):
    cfg = _cfg(tmp_path / "st", [tmp_path])
    r = Responder(cfg, Journal(tmp_path / "st", cfg))
    script = tmp_path / "evil.py"
    script.write_text("print('x')")
    src = r._quarantine_source({"exe": "/usr/bin/python3.12",
                                "cmdline": ["python3", str(script)]})
    assert src == str(script)
    assert r._quarantine_source({"exe": "/usr/bin/python3",
                                 "cmdline": ["python3", "-c", "x"]}) is None
    binary = tmp_path / "evil_bin"
    binary.write_bytes(b"\x7fELF")
    assert r._quarantine_source({"exe": str(binary),
                                 "cmdline": [str(binary)]}) == str(binary)


# --- misc -----------------------------------------------------------------------------

def test_windows_style_agent_names_recognised():
    assert looks_like_aegis_agent("aegis.exe watch")
    assert looks_like_aegis_agent(r'"C:\x\Scripts\aegis.exe" launch')
    assert not looks_like_aegis_agent("python myaegis_tool.py")


def test_config_validation(tmp_path):
    with pytest.raises(RuntimeError):
        _finalize({"protected_dirs": [1, 2], "state_dir": "x",
                   "journal": {"max_file_mb": 1, "max_total_mb": 1}})
    with pytest.raises(RuntimeError):
        _finalize({"protected_dirs": [], "state_dir": "x",
                   "journal": {"max_file_mb": 0, "max_total_mb": 1}})
    cfg = _finalize({"protected_dirs": None, "state_dir": None,
                     "journal": {"max_file_mb": 1, "max_total_mb": 1}})
    assert cfg["protected_dirs"] == [] and cfg["state_dir"]


def test_agent_refuses_home_when_not_allowed(tmp_path):
    from aegis.agent import AegisAgent
    cfg = _cfg(tmp_path / "st", [os.path.expanduser("~")])
    cfg["allow_dangerous_dirs"] = False
    with pytest.raises(RuntimeError, match="refusing"):
        AegisAgent(cfg).start()


def test_agent_allows_home_when_full_drive(tmp_path):
    from aegis.agent import AegisAgent
    cfg = _cfg(tmp_path / "st", [os.path.expanduser("~")])
    cfg["allow_dangerous_dirs"] = True
    # should not raise — full drive mode
    agent = AegisAgent(cfg)
    assert os.path.expanduser("~") in [os.path.realpath(d)
                                        for d in agent.protected_dirs]


# --- research-driven: recovery-inhibition guard (T1490) ----------------------

def test_recovery_guard_flags_shadow_deletion(tmp_path):
    from aegis.recovery_guard import RecoveryGuard
    cfg = default_config()
    cfg["state_dir"] = str(tmp_path / "st")
    cfg["protected_dirs"] = [str(tmp_path)]

    class _Agent:
        def __init__(self):
            self.hits = []
        def on_recovery_inhibit(self, ev, reason):
            self.hits.append(reason)

    a = _Agent()
    g = RecoveryGuard(cfg, a)

    class _P:
        def __init__(self, pid, cmd):
            self.info = {"pid": pid, "name": "x", "cmdline": cmd, "ppid": 1}
    import aegis.recovery_guard as rg
    procs = [_P(999, ["vssadmin.exe", "Delete", "Shadows", "/all", "/quiet"]),
             _P(1000, ["python", "train.py"])]
    rg.psutil = type("M", (), {"process_iter": staticmethod(
        lambda f=None: procs)})
    g._scan()
    assert any("T1490" in h or "recovery-inhibition" in h for h in a.hits)
    assert len(a.hits) == 1  # only the vssadmin proc


# --- user-space containment (all OSes, no certificate) ----------------------

def test_containment_suspends_and_kills(tmp_path):
    import subprocess
    import psutil
    from aegis.containment import Containment
    from aegis.platforms import get_platform
    c = Containment(get_platform(), {"response": {}})
    victim = subprocess.Popen(["sleep", "30"])
    try:
        import time as _t
        _t.sleep(0.2)
        res = c.contain(victim.pid)
        assert victim.pid in res["suspended"]
        assert res["killed"] is True
        _t.sleep(0.3)
        assert not (psutil.pid_exists(victim.pid)
                    and psutil.Process(victim.pid).status()
                    != psutil.STATUS_ZOMBIE)
    finally:
        if victim.poll() is None:
            victim.kill()
        victim.wait()


def test_containment_refuses_self_and_pid1():
    from aegis.containment import Containment
    from aegis.platforms import get_platform
    import os
    c = Containment(get_platform(), {"response": {}})
    # never suspend ourselves or init
    assert c.suspend(os.getpid()) == []
    assert c.suspend(1) == []


def test_suspend_is_reversible():
    import subprocess
    import psutil
    import time as _t
    from aegis.containment import Containment
    from aegis.platforms import get_platform
    c = Containment(get_platform(), {"response": {}})
    victim = subprocess.Popen(["sleep", "30"])
    try:
        _t.sleep(0.2)
        sus = c.suspend(victim.pid)
        assert victim.pid in sus
        _t.sleep(0.1)
        assert psutil.Process(victim.pid).status() == psutil.STATUS_STOPPED
        c.resume(sus)  # false-positive recovery
        _t.sleep(0.1)
        assert psutil.Process(victim.pid).status() != psutil.STATUS_STOPPED
    finally:
        victim.kill()
        victim.wait()


def test_kernel_events_are_not_double_counted(tmp_path):
    """Regression: evaluate() must score each event once, not twice."""
    from aegis.events import Event, EventKind
    cfg = _cfg(tmp_path / "st", [tmp_path])
    eng = DetectionEngine(cfg, None)
    eng.on_trigger = lambda *a: None
    eng.evaluate(Event(EventKind.FILE_RENAME, path="/x/a.txt",
                       dest="/x/a.xyz", pid=4242))
    total = sum(p for _, p, _ in eng._buckets[4242])
    assert total == cfg["detection"]["weights"]["rename_ext_change"]


# --- cross-platform containment (suspend-first) ----------------------------

def test_containment_suspend_then_kill(tmp_path):
    from aegis.config import default_config as _dc
    from aegis.platforms import get_platform as _gp
    """Containment freezes the process instantly, then kills."""
    import subprocess, time, psutil
    from aegis.containment import Containment
    cfg = _dc()
    cont = Containment(_gp(), cfg)
    p = subprocess.Popen(["sleep", "60"])
    time.sleep(0.1)
    result = cont.contain(p.pid)
    p.wait()
    assert result["killed"]
    assert result["suspended"]
    assert result["latency_ms"] >= 0


def test_containment_never_kills_init():
    from aegis.containment import Containment
    from aegis.config import default_config as _dc
    from aegis.platforms import get_platform as _gp
    import unittest.mock as mock
    cfg = _dc()
    cont = Containment(_gp(), cfg)
    # pid 1 (init/launchd/SCM) must never be touched
    import psutil
    with mock.patch.object(psutil, "Process") as MockProc:
        MockProc.return_value.pid = 1
        MockProc.return_value.children.return_value = []
        suspended = cont.suspend(1)
        assert suspended == []


def test_containment_skips_aegis_itself():
    from aegis.containment import Containment
    from aegis.config import default_config as _dc
    from aegis.platforms import get_platform as _gp
    cfg = _dc()
    cont = Containment(_gp(), cfg)
    import os
    # The agent's own pid must never be suspended
    suspended = cont.suspend(os.getpid())
    assert suspended == []


# --- full-drive usability: normal reads must NOT be blocked -----------------

def test_quick_verdict_allows_normal_file_reads(tmp_path):
    """Regression: root/kernel mode must not block reading ordinary files,
    even high-entropy ones (photos, zips). Only canaries are denied."""
    from aegis.agent import AegisAgent
    from aegis.events import Decision
    cfg = _cfg(tmp_path / "st", [str(tmp_path)])
    cfg["sensor"]["mode"] = "userspace"  # don't actually start fanotify
    agent = AegisAgent(cfg)
    # a high-entropy, large, non-canary file (like a JPEG or ZIP) being read
    v = agent.quick_verdict(path=str(tmp_path / "photo.jpg"), pid=123,
                            exe="/usr/bin/eog", entropy=7.99, size=5_000_000,
                            canary=False)
    assert v == Decision.ALLOW, "normal high-entropy read must be allowed"
    # a canary touch is always denied
    v2 = agent.quick_verdict(path=str(tmp_path / "2024_tax_return.pdf"),
                             pid=123, exe="/x", entropy=0.0, size=100,
                             canary=True)
    assert v2 == Decision.DENY, "canary must be denied"


# --- language-agnostic: non-Python attacker is attributed + killed ----------

def test_bash_attacker_is_attributed_and_contained(tmp_path):
    """Ransomware in ANY language (here bash) that trips a canary must be
    attributed and contained, not just detected. Regression for the gap where
    only Python attackers were killed."""
    import subprocess, time, glob
    from aegis.agent import AegisAgent
    from aegis.canary import CanaryManager
    import uuid, os as _os
    sb = f"/tmp/aegis-sim-bashtest-{uuid.uuid4().hex[:6]}"
    _os.makedirs(sb)
    try:
        cfg = default_config()
        cfg["protected_dirs"] = [sb]
        cfg["state_dir"] = str(tmp_path / "st")
        cfg["sensor"]["mode"] = "userspace"
        cfg["recovery_guard"]["enabled"] = False
        cfg["egress"]["enabled"] = False
        seeded = CanaryManager(str(tmp_path / "st")).seed(
            [sb], cfg["canaries"]["filenames"])
        agent = AegisAgent(cfg)
        agent.start()
        time.sleep(0.4)
        # pure bash, no python — touch a canary
        canary = seeded[0]
        p = subprocess.Popen(["/bin/bash", "-c",
                              f'echo x >> "{canary}"; sleep 5'])
        time.sleep(2.5)
        incidents = agent.journal.list_incidents()
        agent.stop()
        try:
            p.kill()
        except Exception:
            pass
        assert incidents, "bash attacker was not detected"
        info = agent.journal.load_incident(incidents[0])
        assert info.get("pid"), "bash attacker was not attributed"
    finally:
        import shutil
        shutil.rmtree(sb, ignore_errors=True)
