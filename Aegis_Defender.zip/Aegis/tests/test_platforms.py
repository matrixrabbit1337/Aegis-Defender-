"""Per-OS adapters: every adapter must load and behave on ANY host OS."""
import os
import sys

import pytest

from aegis.platforms import (ADAPTERS, WindowsAdapter, detect_name,
                             get_platform)

NAMES = ["linux", "macos", "windows"]


@pytest.mark.parametrize("name", NAMES)
def test_adapter_interface(name):
    a = get_platform(name)
    assert a.name == name
    assert isinstance(a.default_state_dir(), str) and a.default_state_dir()
    assert a.default_config_path().endswith("config.yaml")
    assert isinstance(a.never_kill_names, frozenset) and a.never_kill_names
    assert a.attribution_note
    a.harden_state_dir(os.devnull) if name != "windows" else None


def test_default_locations_differ_per_os():
    assert get_platform("macos").default_state_dir().endswith(
        os.path.join("Library", "Application Support", "Aegis"))
    assert get_platform("windows").default_state_dir().endswith("Aegis")
    assert get_platform("linux").default_state_dir().endswith(".aegis")


def test_detect_name():
    assert detect_name("win32") == "windows"
    assert detect_name("darwin") == "macos"
    assert detect_name("linux") == "linux"
    assert detect_name("freebsd13") == "linux"


def test_case_insensitive_paths():
    assert get_platform("windows").normcase(r"C:\Docs\A.TXT") == \
        get_platform("windows").normcase(r"c:\docs\a.txt")
    assert get_platform("macos").normcase("/Users/x/A.txt") == \
        get_platform("macos").normcase("/users/x/a.txt")
    assert get_platform("linux").normcase("/home/x/A.txt") != \
        get_platform("linux").normcase("/home/x/a.txt")


def test_macos_has_no_io_counters_others_do():
    assert get_platform("macos").supports_io_counters is False
    assert get_platform("linux").supports_io_counters is True
    assert get_platform("windows").supports_io_counters is True


@pytest.mark.parametrize("name,proc", [
    ("linux", "systemd"), ("linux", "sshd"),
    ("macos", "launchd"), ("macos", "WindowServer"),
    ("windows", "lsass.exe"), ("windows", "Explorer.EXE"),
])
def test_os_critical_processes_never_killed(name, proc):
    assert get_platform(name).is_protected_process(proc, 4242)


def test_low_pids_always_protected():
    for n in NAMES:
        assert get_platform(n).is_protected_process("whatever", 1)
        assert get_platform(n).is_protected_process("whatever", 0)
    assert not get_platform("linux").is_protected_process("evil", 4242)


def test_interpreter_detection():
    a = get_platform("linux")
    assert a.is_interpreter("/usr/bin/python3.12")
    assert a.is_interpreter("/bin/bash")
    assert get_platform("windows").is_interpreter(
        r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe")
    assert not a.is_interpreter("/tmp/evil_binary")
    assert not get_platform("windows").is_interpreter(r"C:\x\evil.exe")


def test_home_and_system_dirs_are_dangerous(tmp_path):
    a = get_platform()
    assert a.is_dangerous(os.path.expanduser("~"))
    assert a.is_dangerous(os.path.dirname(os.path.expanduser("~")))
    assert not a.is_dangerous(str(tmp_path))


def test_windows_adapter_importable_here():
    # no ctypes.windll at import time: constructing must work on Linux/macOS
    assert WindowsAdapter().is_admin() in (True, False)


def test_every_adapter_registered():
    assert set(ADAPTERS) == set(NAMES)


def test_current_host_adapter_matches_sys_platform():
    expected = {"win32": "windows", "darwin": "macos"}.get(
        sys.platform, "linux")
    assert get_platform().name == expected
