"""Tests for baseline snapshots and rollback."""
import os
from pathlib import Path

from aegis.config import default_config
from aegis.journal import Journal


def _make_tree(root: Path):
    (root / "a.txt").write_bytes(b"hello")
    sub = root / "sub"
    sub.mkdir()
    (sub / "b.txt").write_bytes(b"world")


def test_baseline_and_rollback(tmp_path):
    protected = tmp_path / "docs"
    protected.mkdir()
    _make_tree(protected)

    cfg = default_config()
    cfg["state_dir"] = str(tmp_path / "state")
    journal = Journal(str(tmp_path / "state"), cfg)
    baseline_id = journal.take_baseline([str(protected)])
    assert baseline_id.startswith("base-")

    # simulate an attack: modify, add ransom note, rename to ciphertext
    (protected / "a.txt").write_bytes(b"ENCRYPTEDBLOB")
    (protected / "HOW_TO_RECOVER.txt").write_text("pay me")
    os.replace(protected / "sub" / "b.txt", protected / "sub" / "b.txt.locked")

    incident_id = journal.create_incident(
        {"baseline_id": baseline_id, "reasons": ["test"]})
    stats = journal.rollback(incident_id)

    assert stats["failed"] == []
    assert (protected / "a.txt").read_bytes() == b"hello"
    assert (protected / "sub" / "b.txt").read_bytes() == b"world"
    assert not (protected / "HOW_TO_RECOVER.txt").exists()
    assert not (protected / "sub" / "b.txt.locked").exists()
    assert len(stats["restored"]) == 2
    assert len(stats["deleted"]) == 2  # note + renamed ciphertext


def test_rollback_unknown_incident_raises(tmp_path):
    cfg = default_config()
    cfg["state_dir"] = str(tmp_path / "state")
    journal = Journal(str(tmp_path / "state"), cfg)
    try:
        journal.rollback("inc-does-not-exist")
    except (RuntimeError, FileNotFoundError, OSError):
        pass
    else:
        raise AssertionError("expected rollback of unknown incident to fail")
