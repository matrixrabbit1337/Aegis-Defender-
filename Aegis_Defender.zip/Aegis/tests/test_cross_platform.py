"""Run the real agent + simulator with each OS adapter forced.

We can only execute on the CI host, but forcing the Windows / macOS adapters
exercises their code paths (case-insensitive paths, protected-process lists,
no-io-counter attribution on macOS, notifications, state-dir hardening) end to
end against a real attack. The 3-OS CI matrix then runs this on real hosts.
"""
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

import pytest

import aegis.platforms as platforms
from aegis.platforms import get_platform

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from simulator import SANDBOX_PREFIX  # noqa: E402


@pytest.fixture
def forced(request, monkeypatch):
    adapter = get_platform(request.param)
    adapter.notify = lambda *a, **k: None          # no popups in tests
    adapter.harden_state_dir = lambda *a, **k: None  # no icacls on Linux
    monkeypatch.setattr(platforms, "_cached", adapter)
    return adapter


def _wait(pred, timeout=30):
    end = time.time() + timeout
    while time.time() < end:
        r = pred()
        if r:
            return r
        time.sleep(0.25)
    return None


@pytest.mark.parametrize("forced", ["linux", "windows", "macos"],
                         indirect=True)
def test_attack_stopped_and_rolled_back_per_os(forced, tmp_path):
    from aegis.agent import AegisAgent
    from aegis.canary import CanaryManager
    from aegis.config import default_config
    from aegis.journal import Journal

    sandbox = Path(f"{SANDBOX_PREFIX}xos-{forced.name}-{uuid.uuid4().hex[:6]}")
    sandbox.mkdir(parents=True)
    state = tmp_path / "state"
    originals = {}
    for i in range(20):
        p = sandbox / f"Doc_{i}.TXT"            # mixed case on purpose
        data = (f"document {i} " * 800).encode()
        p.write_bytes(data)
        originals[p.name] = data
    cfg = default_config()
    cfg["protected_dirs"] = [str(sandbox)]
    cfg["state_dir"] = str(state)
    cfg["sensor"]["mode"] = "userspace"   # the cert-free path every OS gets
    for _k in ("egress", "recovery_guard", "integrity"):
        cfg[_k]["enabled"] = False
    CanaryManager(state).seed([str(sandbox)], cfg["canaries"]["filenames"])
    agent = AegisAgent(cfg)
    agent.start()
    proc = None
    try:
        assert agent.sensor_mode.startswith("userspace")
        proc = subprocess.Popen(
            [sys.executable, str(ROOT / "simulator.py"), "--target",
             str(sandbox)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        def incident():
            inc_dir = state / "incidents"
            if not inc_dir.is_dir():
                return None
            for d in inc_dir.iterdir():
                r = d / "report.json"
                if r.exists():
                    return d.name
            return None

        iid = _wait(incident)
        assert iid, f"[{forced.name}] attack was not detected"

        if forced.supports_io_counters:
            assert _wait(lambda: proc.poll() is not None, 20) is not None, \
                f"[{forced.name}] attacker was not stopped"
        else:  # macOS: kill only when positively attributed
            if proc.poll() is None:
                proc.kill()
        proc.wait(timeout=10)
        time.sleep(0.5)
    finally:
        agent.stop()
        if proc and proc.poll() is None:
            proc.kill()

    stats = Journal(state, cfg).rollback(iid)
    assert not stats["failed"], stats["failed"]
    for name, data in originals.items():
        assert (sandbox / name).read_bytes() == data, \
            f"[{forced.name}] {name} not restored"
    assert not list(sandbox.glob("*.locked")), "ciphertext left behind"
    import shutil
    shutil.rmtree(sandbox, ignore_errors=True)


@pytest.mark.parametrize("name", ["linux", "windows", "macos"])
def test_containment_freezes_then_kills_per_os(name):
    """Suspend-first containment works with each adapter's safety rules."""
    from aegis.containment import Containment
    import psutil
    c = Containment(get_platform(name), {"response": {}})
    victim = subprocess.Popen([sys.executable, "-c",
                               "import time; time.sleep(60)"])
    try:
        time.sleep(0.3)
        res = c.contain(victim.pid)
        assert victim.pid in res["suspended"]
        assert res["killed"]
        victim.wait(timeout=5)
    finally:
        if victim.poll() is None:
            victim.kill()


@pytest.mark.parametrize("name", ["linux", "windows", "macos"])
def test_containment_refuses_os_critical(name):
    from aegis.containment import Containment
    a = get_platform(name)
    c = Containment(a, {"response": {}})

    class P:
        pid = 4242
        def cmdline(self): return ["x"]
        def name(self): return sorted(a.never_kill_names)[0]
    assert c._safe_target(P()) is False
