"""Run the full agent pipeline under each OS adapter (Linux, macOS, Windows).

We can only execute on the CI host's real OS, but forcing each adapter catches
the class of bugs where a code path assumes one OS's paths, case rules, process
names or capabilities. Real-OS coverage comes from the 3-OS CI matrix."""
import os
import time

import pytest

import aegis.platforms as platforms
from aegis.config import default_config
from aegis.events import Event, EventKind, Decision


@pytest.fixture(params=["linux", "macos", "windows"])
def forced_os(request, monkeypatch):
    adapter = platforms.get_platform(request.param)
    monkeypatch.setattr(platforms, "_cached", adapter)
    # don't pop real dialogs / run icacls during tests
    monkeypatch.setattr(adapter, "notify", lambda *a, **k: None)
    monkeypatch.setattr(adapter, "harden_state_dir", lambda *a, **k: None)
    return adapter


def _agent(tmp_path):
    from aegis.agent import AegisAgent
    docs = tmp_path / "Docs"
    docs.mkdir()
    for i in range(5):
        (docs / f"f{i}.txt").write_text("hello " * 400)
    cfg = default_config()
    cfg["state_dir"] = str(tmp_path / "state")
    cfg["protected_dirs"] = [str(docs)]
    cfg["sensor"]["mode"] = "userspace"
    for k in ("egress", "recovery_guard", "integrity"):
        cfg[k]["enabled"] = False
    cfg["response"]["kill_process"] = False
    return AegisAgent(cfg), docs


def test_agent_start_stop_every_os(forced_os, tmp_path):
    agent, docs = _agent(tmp_path)
    agent.start()
    try:
        assert agent.journal.last_baseline_id
        assert "userspace" in agent.sensor_mode
    finally:
        agent.stop()


def test_scope_rules_every_os(forced_os, tmp_path):
    agent, docs = _agent(tmp_path)
    inside = str(docs / "f0.txt")
    assert agent._in_scope(inside)
    assert not agent._in_scope(str(tmp_path / "elsewhere.txt"))
    assert not agent._in_scope(os.path.join(agent.state_dir, "x"))
    if forced_os.case_insensitive:
        assert agent._in_scope(inside.replace("Docs", "DOCS"))


def test_detection_pipeline_every_os(forced_os, tmp_path):
    agent, docs = _agent(tmp_path)
    agent.start()
    try:
        fired = []
        agent.responder.handle_trigger = (
            lambda pid, reasons, score, ctx=None: fired.append(reasons))
        for i in range(3):
            agent.on_event(Event(EventKind.FILE_RENAME,
                                 path=str(docs / f"f{i}.txt"),
                                 dest=str(docs / f"f{i}.txt.akira"),
                                 pid=4242))
        assert fired, "known-extension renames should trigger on every OS"
        # a WRITE to a known ransomware-extension file is blocked; a read is not
        d = agent.quick_verdict(str(docs / "x.lockbit"), 4242, None,
                                None, None, False, is_write=True)
        assert d == Decision.DENY
        d_read = agent.quick_verdict(str(docs / "x.lockbit"), 4242, None,
                                     None, None, False, is_write=False)
        assert d_read == Decision.ALLOW  # reads never blocked
    finally:
        agent.stop()


def test_rollback_every_os(forced_os, tmp_path):
    agent, docs = _agent(tmp_path)
    agent.start()
    agent.stop()
    (docs / "f0.txt").write_bytes(b"ENCRYPTED")
    (docs / "README_DECRYPT.txt").write_text("pay")
    iid = agent.journal.create_incident(
        {"baseline_id": agent.journal.last_baseline_id, "reasons": ["t"]})
    stats = agent.journal.rollback(iid)
    assert not stats["failed"]
    assert (docs / "f0.txt").read_text().startswith("hello")
    assert not (docs / "README_DECRYPT.txt").exists()


def test_os_specific_safety_lists(forced_os):
    critical = {"linux": "systemd", "macos": "launchd",
                "windows": "lsass.exe"}[forced_os.name]
    assert forced_os.is_protected_process(critical, 5000)
    assert forced_os.is_interpreter("python3")


def test_persistence_locations_every_os(forced_os):
    from aegis.integrity import persistence_locations
    locs = persistence_locations()
    assert isinstance(locs, list)
