"""End-to-end test: agent vs. fake ransomware in a sandbox.

Spins up the full AegisAgent watching a throwaway sandbox, runs
simulator.py against it, and asserts:
  1. the agent detects the attack (incident report written),
  2. the offending process is killed,
  3. rollback restores every file byte-for-byte and removes attack artifacts.

The simulator's own guard guarantees it can only touch /tmp/aegis-sim-*.
"""
import json
import shutil
import subprocess
import sys
import time
import uuid
from pathlib import Path

import pytest

import psutil

from aegis.agent import AegisAgent
from aegis.canary import CanaryManager
from aegis.config import default_config
from aegis.journal import Journal

import sys as _sys
_sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from simulator import SANDBOX_PREFIX  # noqa: E402

SIM = Path(__file__).resolve().parent.parent / "simulator.py"


def _wait_for_incident(state_dir: Path, timeout: float = 60):
    inc = state_dir / "incidents"
    deadline = time.time() + timeout
    while time.time() < deadline:
        if inc.is_dir():
            for entry in inc.iterdir():
                report = entry / "report.json"
                if entry.is_dir() and report.exists():
                    return json.loads(report.read_text(encoding="utf-8"))
        time.sleep(0.5)
    return None


def _pid_dead(pid: int, expected: str = "simulator") -> bool:
    """True if the process is gone (guarding against PID reuse)."""
    try:
        proc = psutil.Process(pid)
        return expected not in " ".join(proc.cmdline())
    except psutil.NoSuchProcess:
        return True


def test_end_to_end_detection_kill_rollback(tmp_path):
    sandbox = Path(f"{SANDBOX_PREFIX}e2e-{uuid.uuid4().hex[:8]}")
    sandbox.mkdir(parents=True)
    state = tmp_path / "state"
    try:
        # --- victim files -------------------------------------------------
        originals: dict[str, bytes] = {}
        for i in range(24):
            p = sandbox / f"doc_{i:02d}.txt"
            data = (f"Document {i}: the quick brown fox jumps over "
                    f"the lazy dog. " * 1500).encode()
            p.write_bytes(data)
            originals[str(p)] = data
        sub = sandbox / "projects"
        sub.mkdir()
        for i in range(6):
            p = sub / f"notes_{i}.md"
            data = (f"# Notes {i}\nSome mildly repetitive markdown. " * 800) \
                .encode()
            p.write_bytes(data)
            originals[str(p)] = data

        # --- agent ---------------------------------------------------------
        cfg = default_config()
        cfg["protected_dirs"] = [str(sandbox)]
        cfg["state_dir"] = str(state)
        # Deterministic sensor for the generic e2e; the kernel blocking sensor
        # has its own dedicated test (test_kernel_sensor.py).
        cfg["sensor"]["mode"] = "userspace"
        cfg["recovery_guard"]["enabled"] = False
        cfg["egress"]["enabled"] = False
        canaries = CanaryManager(str(state))
        seeded = canaries.seed([str(sandbox)], cfg["canaries"]["filenames"])
        assert seeded, "expected canaries to be seeded"

        agent = AegisAgent(cfg)
        agent.start()
        time.sleep(2)  # let the attributor collect baseline I/O samples

        # --- attack ---------------------------------------------------------
        started = time.time()
        proc = subprocess.Popen(
            [sys.executable, str(SIM), "--target", str(sandbox)],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            report = _wait_for_incident(state, timeout=60)
            assert report is not None, "agent never detected the attack"
            latency = report["detected_at"] - started
            print(f"\ndetection latency: {latency:.2f}s | "
                  f"pid={report['pid']} | killed={report.get('killed')} | "
                  f"reasons={report['reasons'][:2]}")

            # The offending process must actually die. NOTE: we check via
            # pid_exists/cmdline, NOT via proc.returncode — the responder's
            # psutil.wait_procs reaps the child (the test is its parent),
            # which makes Popen.returncode read 0 even after SIGTERM.
            from aegis.platforms import get_platform
            if get_platform().supports_io_counters:
                deadline = time.time() + 30
                while time.time() < deadline:
                    if _pid_dead(proc.pid):
                        break
                    time.sleep(0.5)
                else:
                    proc.kill()
                    pytest.fail("simulator was NOT killed by the agent")
                print("simulator process is dead (killed by agent)")
            else:
                # kernel sensor blocks writes pre-encryption and kills by the
                # exact PID; or (macOS) attribution may be open-file only.
                # Either way detection + rollback are the hard requirement.
                deadline = time.time() + 15
                while time.time() < deadline and not _pid_dead(proc.pid):
                    time.sleep(0.5)
                if proc.poll() is None:
                    proc.kill()
                    proc.wait()
            incident_id = report["id"]
        finally:
            agent.stop()
            if proc.poll() is None:
                proc.kill()
                proc.wait()

        # --- rollback ---------------------------------------------------------
        journal = Journal(str(state), cfg)
        stats = journal.rollback(incident_id)
        assert stats["failed"] == [], f"rollback failures: {stats['failed']}"
        for path, data in originals.items():
            assert Path(path).read_bytes() == data, f"not restored: {path}"
        assert not list(sandbox.rglob("HOW_TO_RECOVER.txt")), \
            "ransom notes remain"
        assert not list(sandbox.rglob("*.locked")), "ciphertext remains"
        for path, status in canaries.verify_all():
            assert status is None, f"canary not restored: {path} ({status})"
        print(f"rollback: {len(stats['restored'])} restored, "
              f"{len(stats['deleted'])} attack artifacts deleted")
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)


def test_refuses_filesystem_root(tmp_path):
    from aegis.agent import AegisAgent
    cfg = default_config()
    cfg["protected_dirs"] = ["/"]
    cfg["state_dir"] = str(tmp_path / "state")
    agent = AegisAgent(cfg)
    try:
        agent.start()
    except RuntimeError as exc:
        assert "filesystem root" in str(exc)
    else:
        raise AssertionError("expected RuntimeError for '/'")
