"""Phase-A event contract."""
from aegis.events import Event, EventKind, Decision


def test_event_roundtrip():
    e = Event(EventKind.FILE_MODIFY, path="/x/a", entropy=7.9, size=4096,
              pid=10, source="fanotify", blockable=True)
    d = e.to_json()
    assert d["kind"] == "file.modify" and d["blockable"] is True
    assert e.target() == "/x/a"
    e2 = Event(EventKind.FILE_RENAME, path="/x/a", dest="/x/a.locked")
    assert e2.target() == "/x/a.locked"


def test_decisions_exist():
    for d in ("ALLOW", "AUDIT", "THROTTLE", "SUSPEND", "CONTAIN", "DENY"):
        assert hasattr(Decision, d)
