"""Tests for canary seeding, integrity checks, and the no-overwrite rule."""
import os
from pathlib import Path

from aegis.canary import CanaryManager


def test_seed_and_trip(tmp_path):
    docs = tmp_path / "docs"
    docs.mkdir()
    manager = CanaryManager(tmp_path / "state")

    seeded = manager.seed([str(docs)],
                          ["2024_tax_return.pdf", "passwords_backup.xlsx"])
    assert len(seeded) == 2
    assert all(manager.is_canary(p) for p in seeded)
    assert all(os.path.exists(p) for p in seeded)

    # healthy canaries verify clean
    assert manager.check(seeded[0]) is None
    assert all(s is None for _, s in manager.verify_all())

    # modification trips
    Path(seeded[0]).write_bytes(b"tampered!")
    assert manager.check(seeded[0]) == "modified"

    # deletion trips
    os.remove(seeded[1])
    assert manager.check(seeded[1]) == "deleted"

    tripped = {p: s for p, s in manager.verify_all() if s}
    assert len(tripped) == 2


def test_seed_never_overwrites_real_files(tmp_path):
    docs = tmp_path / "docs"
    docs.mkdir()
    real = docs / "2024_tax_return.pdf"
    real.write_bytes(b"my actual tax return - do not touch")

    manager = CanaryManager(tmp_path / "state")
    seeded = manager.seed([str(docs)], ["2024_tax_return.pdf"])

    assert seeded == []
    assert real.read_bytes() == b"my actual tax return - do not touch"
    assert not manager.is_canary(str(real))


def test_seed_is_idempotent(tmp_path):
    docs = tmp_path / "docs"
    docs.mkdir()
    manager = CanaryManager(tmp_path / "state")
    first = manager.seed([str(docs)], ["Q3_financials.docx"])
    second = manager.seed([str(docs)], ["Q3_financials.docx"])
    assert len(first) == 1 and second == []
    assert manager.count == 1
