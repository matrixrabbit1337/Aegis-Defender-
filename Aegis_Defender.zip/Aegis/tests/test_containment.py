"""User-space containment — works on all three OSes without any certificate."""
import subprocess
import sys
import time

import pytest

import psutil

from aegis.containment import Containment
from aegis.platforms import get_platform


def _spawn():
    # a harmless long-lived child to stand in for "the ransomware process"
    return subprocess.Popen([sys.executable, "-c",
                             "import time; time.sleep(60)"])


def test_suspend_then_resume_is_reversible():
    p = _spawn()
    time.sleep(0.3)
    c = Containment(get_platform(), {"response": {}})
    try:
        suspended = c.suspend(p.pid)
        assert p.pid in suspended
        # status should be 'stopped' on POSIX; just assert it's still alive
        assert psutil.pid_exists(p.pid)
        c.resume(suspended)
        assert psutil.pid_exists(p.pid)
    finally:
        p.kill()
        p.wait()


def test_contain_kills_the_tree():
    p = _spawn()
    time.sleep(0.3)
    c = Containment(get_platform(), {"response": {}})
    result = c.contain(p.pid)
    assert result["killed"] is True
    time.sleep(0.3)
    gone = (not psutil.pid_exists(p.pid)
            or psutil.Process(p.pid).status() == psutil.STATUS_ZOMBIE)
    assert gone
    p.wait()


def test_never_contains_self_or_init():
    c = Containment(get_platform(), {"response": {}})
    import os
    assert c.suspend(os.getpid()) == []   # never freeze ourselves
    assert c.suspend(1) == []             # never touch init


def test_contain_missing_pid_is_safe():
    c = Containment(get_platform(), {"response": {}})
    # a pid that doesn't exist must not raise and must report killed/neutralized
    result = c.contain(2_000_000_000)
    assert "killed" in result
