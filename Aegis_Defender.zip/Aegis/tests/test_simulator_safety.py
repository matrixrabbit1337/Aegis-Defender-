"""Tests for the simulator's hard sandbox guard.

The simulator must REFUSE to run against anything that is not a directory
under /tmp/aegis-sim-*. These tests prove the guard aborts (SystemExit)
instead of touching real files.
"""
import shutil
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from simulator import SANDBOX_PREFIX, require_sandbox  # noqa: E402


def _sandbox(name: str) -> Path:
    return Path(SANDBOX_PREFIX + name)


def test_refuses_tmp_itself():
    import os
    with pytest.raises(SystemExit):
        import tempfile
        require_sandbox(os.path.realpath(tempfile.gettempdir()))


def test_refuses_prefix_without_sandbox_id():
    with pytest.raises(SystemExit):
        require_sandbox(SANDBOX_PREFIX)


def test_refuses_root():
    import os
    with pytest.raises(SystemExit):
        require_sandbox(os.path.abspath(os.sep))


def test_refuses_home_like_dirs(tmp_path):
    with pytest.raises(SystemExit):
        require_sandbox(str(tmp_path))


def test_refuses_nonexistent_sandbox():
    with pytest.raises(SystemExit):
        require_sandbox(SANDBOX_PREFIX + "nope-not-here")


def test_refuses_symlink_escape(tmp_path):
    victim = tmp_path / "victim"
    victim.mkdir()
    sandbox = _sandbox("linktest")
    sandbox.mkdir(exist_ok=True)
    try:
        link = sandbox / "escape"
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(victim)
        with pytest.raises(SystemExit):
            require_sandbox(str(link))
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)


def test_accepts_real_sandbox():
    sandbox = _sandbox("accepttest")
    sandbox.mkdir(exist_ok=True)
    try:
        assert require_sandbox(str(sandbox)) == str(sandbox)
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)
