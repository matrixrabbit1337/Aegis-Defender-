"""Egress guard helpers (Phase E)."""
from aegis.egress import is_transfer_tool, is_public_ip


def test_transfer_tools():
    for t in ("rclone", "ngrok", "curl", "winscp.exe", "megacmd", "rsync"):
        assert is_transfer_tool(t)
    for t in ("chrome", "python", "code", "slack"):
        assert not is_transfer_tool(t)


def test_public_vs_private_ip():
    assert is_public_ip("8.8.8.8")
    assert is_public_ip("203.0.113.5")
    for p in ("10.0.0.1", "192.168.1.5", "127.0.0.1", "172.16.0.1",
              "169.254.1.1", "::1"):
        assert not is_public_ip(p)
