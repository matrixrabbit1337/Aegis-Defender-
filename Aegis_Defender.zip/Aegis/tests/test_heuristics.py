"""Unit tests for the detection engine: entropy, renames, notes, canaries."""
import os
import time

import pytest

from aegis.config import default_config
from aegis.heuristics import DetectionEngine, FileEvent, shannon_entropy


def make_engine(**detection_overrides):
    cfg = default_config()
    cfg["detection"].update(detection_overrides)
    engine = DetectionEngine(cfg, attributor=None)
    fired = []
    engine.on_trigger = lambda pid, reasons, score, ctx: fired.append(
        {"pid": pid, "reasons": reasons, "score": score})
    engine.fired = fired
    return engine


def ev(kind, src, dest=None, entropy=None, size=None, canary=False, ts=None):
    return FileEvent(kind=kind, src=src, dest=dest, entropy=entropy,
                     size=size, canary=canary,
                     ts=time.time() if ts is None else ts)


# -- entropy ---------------------------------------------------------------

def test_entropy_plain_text_is_low():
    assert shannon_entropy(b"a" * 4096) == 0.0
    text = (b"The quick brown fox jumps over the lazy dog. " * 200)
    assert shannon_entropy(text) < 5.0


def test_entropy_random_is_high():
    assert shannon_entropy(os.urandom(4096)) > 7.9


def test_entropy_fernet_ciphertext_is_high():
    # Fernet output is base64-wrapped, so it lands ~6.0 bits/byte —
    # clearly above plaintext (~4-5), below raw binary (~8.0).
    from cryptography.fernet import Fernet
    token = Fernet(Fernet.generate_key()).encrypt(b"sensitive data" * 100)
    entropy = shannon_entropy(token)
    assert entropy > 5.5, entropy
    assert entropy < 7.0, entropy


# -- mass renames ------------------------------------------------------------

def test_mass_rename_with_extension_change_triggers():
    # a neutral (non-ransomware) extension uses the generic weight (5)
    engine = make_engine(trigger_score=50)
    t = 1000.0
    for i in range(12):  # 12 x weight 5 = 60 >= 50
        engine.handle_event(ev("moved", f"/x/f{i}.txt", f"/x/f{i}.xyz",
                               ts=t + i * 0.5))
    assert len(engine.fired) == 1
    assert any("extension change" in r for r in engine.fired[0]["reasons"])


def test_rename_to_known_ransomware_extension_triggers_fast():
    # research-driven: a rename to a KNOWN family extension is high-signal,
    # so only two such events should cross the threshold (30 + 30 = 60).
    engine = make_engine(trigger_score=50)
    t = 1000.0
    for i in range(2):
        engine.handle_event(ev("moved", f"/x/f{i}.txt", f"/x/f{i}.txt.akira",
                               ts=t + i * 0.5))
    assert len(engine.fired) == 1
    assert any("KNOWN ransomware extension" in r
               for r in engine.fired[0]["reasons"])


def test_rename_without_extension_change_does_not_score():
    engine = make_engine(trigger_score=50)
    t = 1000.0
    for i in range(30):
        engine.handle_event(ev("moved", f"/x/f{i}.txt", f"/x/g{i}.txt",
                               ts=t + i * 0.5))
    assert engine.fired == []


# -- ransom notes ------------------------------------------------------------

@pytest.mark.parametrize("name", [
    "HOW_TO_RECOVER.txt", "README_DECRYPT.html", "Decrypt_Instructions.txt",
])
def test_ransom_note_filenames_score(name):
    engine = make_engine(trigger_score=50)
    t = 2000.0
    engine.handle_event(ev("created", f"/x/{name}", ts=t))
    engine.handle_event(ev("created", f"/x/sub/{name}", ts=t + 1))
    assert len(engine.fired) == 1
    assert any("ransom-note" in r for r in engine.fired[0]["reasons"])


def test_innocent_filename_does_not_score():
    engine = make_engine(trigger_score=10)
    engine.handle_event(ev("created", "/x/meeting_notes.txt", ts=3000.0))
    assert engine.fired == []


# -- canary -------------------------------------------------------------------

def test_canary_trip_fires_instantly():
    engine = make_engine(trigger_score=10 ** 9)  # unreachable otherwise
    engine.handle_event(ev("modified", "/x/2024_tax_return.pdf",
                            canary=True, ts=4000.0))
    assert len(engine.fired) == 1
    assert "CANARY" in engine.fired[0]["reasons"][0]


def test_canary_cooldown_suppresses_repeat_trips():
    engine = make_engine(trigger_score=10 ** 9)
    engine.handle_event(ev("modified", "/x/a.pdf", canary=True, ts=4000.0))
    engine.handle_event(ev("modified", "/x/b.pdf", canary=True, ts=4001.0))
    engine.handle_event(ev("deleted", "/x/c.pdf", canary=True, ts=4002.0))
    assert len(engine.fired) == 1  # one incident per attack, not per file


# -- benign traffic -------------------------------------------------------------

def test_benign_low_entropy_writes_do_not_trigger():
    engine = make_engine(trigger_score=50)
    t = 5000.0
    for i in range(40):
        engine.handle_event(ev("modified", f"/x/doc{i}.txt",
                               entropy=4.2, size=2048, ts=t + i * 0.2))
    assert engine.fired == []


def test_cooldown_prevents_refire_storm():
    engine = make_engine(trigger_score=20)
    t = 6000.0
    for i in range(8):
        engine.handle_event(ev("moved", f"/x/f{i}.txt", f"/x/f{i}.txt.locked",
                               ts=t + i * 0.5))
    first = len(engine.fired)
    assert first == 1
    for i in range(8, 16):
        engine.handle_event(ev("moved", f"/x/f{i}.txt", f"/x/f{i}.txt.locked",
                               ts=t + i * 0.5))
    assert len(engine.fired) == first  # still 1: cooldown active
