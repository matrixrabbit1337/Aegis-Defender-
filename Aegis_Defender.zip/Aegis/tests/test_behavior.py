"""Content-independent spread detection (anti-polymorphic / anti-AI-evasion)."""
from aegis.behavior import SpreadTracker


def _tracker(**over):
    cfg = {"behavior": {"distinct_file_threshold": 5,
                        "distinct_dir_threshold": 2, "spread_points": 20}}
    cfg["behavior"].update(over)
    return SpreadTracker(cfg)


def test_spread_across_dirs_flags_regardless_of_content():
    st = _tracker()
    pts = 0
    for i in range(5):
        pts, why = st.record(42, f"/docs/sub{i % 2}/f{i}.txt", ts=1000.0 + i)
    assert pts >= 20 and "spread" in (why or "")


def test_single_file_edits_do_not_flag():
    st = _tracker()
    last = (0, None)
    for i in range(10):
        last = st.record(42, "/docs/one.txt", ts=1000.0 + i)  # same file
    assert last[0] == 0  # one file touched repeatedly is not spread


def test_no_pid_no_signal():
    st = _tracker()
    for i in range(10):
        pts, _ = st.record(None, f"/docs/f{i}.txt", ts=1000.0 + i)
        assert pts == 0


def test_low_entropy_mass_touch_still_caught():
    # the key anti-evasion property: even if every write is plaintext (entropy
    # evasion), touching many distinct files fast still raises the signal.
    st = _tracker(distinct_file_threshold=8, distinct_dir_threshold=1)
    pts = 0
    for i in range(8):
        pts, why = st.record(99, f"/docs/f{i}.txt", ts=2000.0 + i * 0.1)
    assert pts > 0


def test_window_expiry():
    st = _tracker(window_s=5)
    for i in range(4):
        st.record(7, f"/docs/f{i}.txt", ts=1000.0 + i)
    # long gap: old touches expire, so the next few don't accumulate to flag
    pts, _ = st.record(7, "/docs/late.txt", ts=2000.0)
    assert pts == 0
