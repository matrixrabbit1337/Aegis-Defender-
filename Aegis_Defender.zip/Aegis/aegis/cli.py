"""`aegis` command line interface.

Commands:
  aegis setup [--dirs D [D ...]] [--yes]
                        choose protected folders, write config, plant canaries
  aegis launch          what the desktop icon runs: first-run setup if needed,
                        then watch; the window stays open on errors
  aegis watch           start the protection daemon (Ctrl+C to stop)
  aegis status          show config, canary health, journal, recent incidents
  aegis seed-canaries   plant canary tripwires in the protected dirs
  aegis rollback --since <incident-id> [--dry-run] [--yes]
                        restore protected files to pre-attack state
"""
from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .canary import CanaryManager
from .config import load_config, write_default_config
from .journal import Journal
from .platforms import get_platform


def _config_path(args) -> str:
    return args.config or get_platform().default_config_path()


def _load_config(args, create: bool = True) -> dict:
    path = _config_path(args)
    try:
        cfg = load_config(path)
    except FileNotFoundError:
        if not create:
            raise
        path = write_default_config(path)
        print(f"wrote starter config to {path}")
        print("run `aegis setup` to choose folders to protect "
              "(or edit protected_dirs in it), then re-run.")
        sys.exit(1)
    if args.state_dir:
        cfg["state_dir"] = os.path.expanduser(args.state_dir)
    return cfg


def _require_dirs(cfg: dict) -> list[str]:
    dirs = [os.path.realpath(d) for d in cfg.get("protected_dirs", [])]
    if not dirs:
        sys.exit("no protected_dirs configured — run `aegis setup` or edit "
                 "your config file first.")
    missing = [d for d in dirs if not os.path.isdir(d)]
    if missing:
        sys.exit(f"protected dir(s) do not exist: {', '.join(missing)}")
    return dirs


# -- setup / launch -----------------------------------------------------------

def _write_dirs_to_config(path: str, dirs: list[str]) -> None:
    import yaml
    path = write_default_config(path)
    with open(path, "r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    data["protected_dirs"] = dirs
    with open(path, "w", encoding="utf-8") as fh:
        yaml.safe_dump(data, fh, sort_keys=False)


def cmd_setup(args) -> None:
    plat = get_platform()
    path = _config_path(args)
    if getattr(args, "full_drive", False):
        home = os.path.realpath(os.path.expanduser("~"))
        chosen = [home]
        if plat.name == "windows":
            import string
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if os.path.isdir(drive):
                    chosen.append(drive)
        print(f"Full-drive protection: {chosen}")
    elif args.dirs:
        chosen = [os.path.realpath(os.path.expanduser(d)) for d in args.dirs]
    else:
        suggestions = plat.user_folders()
        if not suggestions:
            sys.exit("no standard folders found; pass them explicitly: "
                     "aegis setup --dirs <folder> [<folder> ...]")
        print("Folders Aegis can protect (it will snapshot them, watch "
              "them, and plant decoy files):")
        for i, d in enumerate(suggestions, 1):
            print(f"  [{i}] {d}")
        if args.yes:
            chosen = suggestions
        else:
            ans = input("Protect which? numbers separated by spaces, "
                        "or Enter for all: ").strip()
            if ans:
                try:
                    chosen = [suggestions[int(n) - 1] for n in ans.split()]
                except (ValueError, IndexError):
                    sys.exit("invalid selection")
            else:
                chosen = suggestions
    bad = [d for d in chosen if not os.path.isdir(d)]
    if bad:
        sys.exit(f"not a directory: {', '.join(bad)}")
    danger = [d for d in chosen if plat.is_dangerous(d)]
    if danger and not getattr(args, "full_drive", False):
        print(f"WARNING: protecting {', '.join(danger)} includes your home "
              "or system directories. Use --full-drive to confirm.")
        if not args.yes:
            ans = input("Continue? [y/N] ").strip()
            if not ans.lower().startswith("y"):
                sys.exit("Aborted.")
    _write_dirs_to_config(path, chosen)
    cfg = load_config(path)
    if args.state_dir:
        cfg["state_dir"] = os.path.expanduser(args.state_dir)
    seeded = CanaryManager(cfg["state_dir"]).seed(
        chosen, cfg["canaries"]["filenames"])
    print(f"config written: {path}")
    print(f"protecting {len(chosen)} folder(s); planted {len(seeded)} "
          "canary file(s).")


def cmd_launch(args) -> None:
    """Desktop-icon entry point: never closes the window on a failure."""
    code = 0
    try:
        path = _config_path(args)
        if not os.path.exists(path):
            print("First run — let's pick the folders to protect.\n")
            args.dirs, args.yes = None, False
            cmd_setup(args)
            print()
        cmd_watch(args)
    except SystemExit as exc:
        code = 0 if exc.code in (None, 0) else 1
        if exc.code not in (None, 0):
            print(f"\n{exc.code}")
    except KeyboardInterrupt:
        pass
    except Exception as exc:  # pragma: no cover
        print(f"\nerror: {exc}")
        code = 1
    if code and sys.stdin and sys.stdin.isatty():
        try:
            input("\nPress Enter to close this window...")
        except EOFError:
            pass
    sys.exit(code)


# -- core commands ----------------------------------------------------------------

def cmd_watch(args) -> None:
    from .agent import AegisAgent
    cfg = _load_config(args)
    _require_dirs(cfg)
    AegisAgent(cfg).run_forever()


def cmd_seed_canaries(args) -> None:
    cfg = _load_config(args)
    dirs = _require_dirs(cfg)
    manager = CanaryManager(cfg["state_dir"])
    seeded = manager.seed(dirs, cfg["canaries"]["filenames"])
    if seeded:
        print(f"seeded {len(seeded)} canary file(s):")
        for path in seeded:
            print(f"  {path}")
        print("(a running watcher picks these up automatically)")
    else:
        print("nothing new to seed (canaries already present).")


def cmd_status(args) -> None:
    plat = get_platform()
    cfg = _load_config(args)
    print(f"platform: {plat.name}"
          f"{' (admin)' if plat.is_admin() else ''}")
    print(f"attribution: {plat.attribution_note}")
    print(f"state dir: {cfg['state_dir']}")
    dirs = cfg.get("protected_dirs", [])
    print(f"\nprotected dirs ({len(dirs)}):")
    for d in dirs:
        print(f"  {d}  {'[MISSING]' if not os.path.isdir(d) else ''}")
    manager = CanaryManager(cfg["state_dir"])
    print(f"\ncanaries armed: {manager.count}")
    tripped = [(p, s) for p, s in manager.verify_all() if s]
    if tripped:
        print("TRIPPED canaries (investigate!):")
        for path, status in tripped:
            print(f"  [{status}] {path}")
    else:
        print("canary health: all intact")
    journal = Journal(cfg["state_dir"], cfg)
    mib = journal.disk_usage() / (1024 * 1024)
    print(f"\njournal disk usage: {mib:.1f} MiB")
    incidents = journal.list_incidents()
    open_inc = []
    for inc in incidents:
        try:
            if not journal.load_incident(inc).get("rolled_back"):
                open_inc.append(inc)
        except (OSError, ValueError):
            pass
    print(f"incidents on record: {len(incidents)} "
          f"({len(open_inc)} not rolled back)")
    for inc in incidents[-5:]:
        print(f"  {inc}{'  [open]' if inc in open_inc else ''}")


def _print_rollback_plan(stats: dict) -> None:
    print(f"  files to restore : {len(stats['restored'])}")
    print(f"  already correct  : {len(stats['unchanged'])}")
    print(f"  files to delete  : {len(stats['deleted'])} "
          "(created after the snapshot: ransom notes, ciphertext, new work)")
    for path in stats["deleted"][:10]:
        print(f"      - {path}")
    if len(stats["deleted"]) > 10:
        print(f"      ... and {len(stats['deleted']) - 10} more")
    if stats["not_backed_up"]:
        print(f"  NOT backed up    : {len(stats['not_backed_up'])} "
              "(left untouched; if the attack hit them they cannot be "
              "restored)")
        for path, why in stats["not_backed_up"][:5]:
            print(f"      ! {path}  [{why}]")
    if stats["failed"]:
        print(f"  FAILED           : {len(stats['failed'])}")
        for path, err in stats["failed"][:10]:
            print(f"      x {path}: {err}")


def cmd_rollback(args) -> None:
    cfg = _load_config(args)
    journal = Journal(cfg["state_dir"], cfg)
    print(f"rollback plan for {args.since} (restores the state as of the "
          "snapshot taken when the agent started):")
    plan = journal.rollback(args.since, dry_run=True)
    _print_rollback_plan(plan)
    if args.dry_run:
        print("\n--dry-run: nothing was changed.")
        return
    if not args.yes:
        if not (sys.stdin and sys.stdin.isatty()):
            sys.exit("refusing to roll back non-interactively without --yes "
                     "(use --dry-run to preview).")
        if input("\nProceed? type 'yes': ").strip().lower() != "yes":
            sys.exit("aborted; nothing was changed.")
    stats = journal.rollback(args.since)
    print(f"\nrestored: {len(stats['restored'])} file(s)")
    print(f"deleted (post-snapshot): {len(stats['deleted'])} file(s)")
    if stats["canaries_restored"]:
        print(f"canaries re-armed: {len(stats['canaries_restored'])}")
    if stats["failed"]:
        print(f"FAILED: {len(stats['failed'])}")
        for path, err in stats["failed"][:10]:
            print(f"  {path}: {err}")
        sys.exit(1)


def cmd_gui(args) -> None:
    from .gui import main as gui_main
    gui_main(_config_path(args))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aegis",
        description="Aegis anti-ransomware agent — Phase 1 user-space MVP")
    parser.add_argument("--version", action="version",
                        version=f"aegis {__version__}")
    parser.add_argument("--config", default=None,
                        help="path to YAML config (default: per-OS location)")
    parser.add_argument("--state-dir", default=None,
                        help="override state directory (journal, quarantine…)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    st = sub.add_parser("setup", help="choose folders, write config, plant canaries")
    st.add_argument("--dirs", nargs="+", default=None)
    st.add_argument("--full-drive", action="store_true",
                    help="protect the entire user drive (home folder + data drives)")
    st.add_argument("--yes", action="store_true",
                    help="accept all suggested folders without prompting")
    sub.add_parser("launch", help="desktop-icon entry (setup if needed, then watch)")
    sub.add_parser("watch", help="start the protection daemon")
    sub.add_parser("status", help="show agent status")
    sub.add_parser("seed-canaries", help="plant canary tripwires")
    rb = sub.add_parser("rollback", help="restore files to pre-attack state")
    rb.add_argument("--since", required=True,
                    help="incident id, e.g. inc-20261008-070101-a1b2c3")
    rb.add_argument("--dry-run", action="store_true",
                    help="show what would change; change nothing")
    rb.add_argument("--yes", action="store_true",
                    help="do not ask for confirmation")
    sub.add_parser("gui", help="launch the graphical dashboard")
    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    commands = {
        "setup": cmd_setup, "launch": cmd_launch, "watch": cmd_watch,
        "status": cmd_status, "seed-canaries": cmd_seed_canaries,
        "rollback": cmd_rollback, "gui": cmd_gui,
    }
    try:
        commands[args.cmd](args)
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
