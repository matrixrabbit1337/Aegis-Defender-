"""Aegis Shield — professional desktop GUI.

Industry-grade dashboard: real-time threat feed, system status, folder
management, incident viewer, canary health, and settings. Built with
CustomTkinter for a modern dark look on Linux, macOS, and Windows.

Launch:  aegis gui
         python -m aegis.gui
"""
from __future__ import annotations

import os
import threading
import time
import tkinter as tk
from datetime import datetime, timezone

import customtkinter as ctk

from . import __version__
from .canary import CanaryManager
from .config import load_config, write_default_config
from .journal import Journal
from .platforms import get_platform

# ── theming ─────────────────────────────────────────────────────────────────
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

# brand colours
C_BG = "#0d1117"
C_CARD = "#161b22"
C_BORDER = "#30363d"
C_TEXT = "#e6edf3"
C_DIM = "#8b949e"
C_GREEN = "#2ea043"
C_RED = "#f85149"
C_AMBER = "#d29922"
C_BLUE = "#58a6ff"
C_CYAN = "#39d2c0"

FONT_TITLE = ("Segoe UI Semibold", 22)
FONT_HEAD = ("Segoe UI Semibold", 14)
FONT_BODY = ("Segoe UI", 12)
FONT_MONO = ("Cascadia Code", 11)
FONT_SMALL = ("Segoe UI", 10)
FONT_BADGE = ("Segoe UI Semibold", 11)


def _ts(epoch: float | None = None) -> str:
    return datetime.fromtimestamp(epoch or time.time(),
                                 tz=timezone.utc).strftime("%H:%M:%S")


# ── reusable widgets ────────────────────────────────────────────────────────

class StatusBadge(ctk.CTkFrame):
    def __init__(self, master, label: str, initial: str = "—", color=C_DIM,
                 **kw):
        super().__init__(master, fg_color=C_CARD, corner_radius=10,
                         border_width=1, border_color=C_BORDER, **kw)
        self._label = ctk.CTkLabel(self, text=label, font=FONT_SMALL,
                                   text_color=C_DIM, anchor="w")
        self._label.pack(padx=14, pady=(10, 0), anchor="w")
        self._value = ctk.CTkLabel(self, text=initial, font=FONT_HEAD,
                                   text_color=color, anchor="w")
        self._value.pack(padx=14, pady=(0, 10), anchor="w")

    def set(self, text: str, color: str | None = None):
        self._value.configure(text=text)
        if color:
            self._value.configure(text_color=color)


class EventFeed(ctk.CTkFrame):
    """Scrollable real-time event log."""

    def __init__(self, master, **kw):
        super().__init__(master, fg_color=C_CARD, corner_radius=10,
                         border_width=1, border_color=C_BORDER, **kw)
        head = ctk.CTkLabel(self, text="  LIVE THREAT FEED", font=FONT_HEAD,
                            text_color=C_CYAN, anchor="w")
        head.pack(fill="x", padx=10, pady=(10, 4))
        self._text = ctk.CTkTextbox(self, font=FONT_MONO, fg_color=C_BG,
                                    text_color=C_TEXT, corner_radius=6,
                                    activate_scrollbars=True, wrap="word",
                                    state="disabled")
        self._text.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self._max = 500

    def append(self, line: str, color: str | None = None):
        self._text.configure(state="normal")
        tag = None
        if color:
            tag = f"c{id(line)}"
            self._text.tag_config(tag, foreground=color)
        self._text.insert("end", line + "\n", tag)
        # trim
        count = int(self._text.index("end-1c").split(".")[0])
        if count > self._max:
            self._text.delete("1.0", f"{count - self._max}.0")
        self._text.see("end")
        self._text.configure(state="disabled")


class IncidentCard(ctk.CTkFrame):
    def __init__(self, master, info: dict, **kw):
        super().__init__(master, fg_color=C_CARD, corner_radius=10,
                         border_width=1, border_color=C_BORDER, **kw)
        iid = info.get("id", "?")
        ts = info.get("detected_at_iso", "")[:19]
        rolled = info.get("rolled_back", False)
        killed = info.get("killed", False)
        reason = (info.get("reasons") or ["—"])[0][:80]

        status_color = C_GREEN if rolled else (C_RED if not killed else C_AMBER)
        status_text = "ROLLED BACK" if rolled else (
            "KILLED" if killed else "OPEN")

        row = ctk.CTkFrame(self, fg_color="transparent")
        row.pack(fill="x", padx=12, pady=8)
        ctk.CTkLabel(row, text=f"● {status_text}", font=FONT_BADGE,
                     text_color=status_color).pack(side="left")
        ctk.CTkLabel(row, text=ts, font=FONT_SMALL,
                     text_color=C_DIM).pack(side="right")
        ctk.CTkLabel(self, text=iid, font=FONT_MONO, text_color=C_DIM,
                     anchor="w").pack(fill="x", padx=12)
        ctk.CTkLabel(self, text=reason, font=FONT_BODY,
                     text_color=C_TEXT, anchor="w",
                     wraplength=420).pack(fill="x", padx=12, pady=(2, 10))


# ── main application ────────────────────────────────────────────────────────

class AegisApp(ctk.CTk):
    def __init__(self, config_path: str | None = None):
        super().__init__()
        self.title("Aegis Shield")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self.configure(fg_color=C_BG)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.plat = get_platform()
        self._config_path = config_path or self.plat.default_config_path()
        self._agent = None
        self._agent_thread = None
        self._running = False

        self._load_config()
        self._build_ui()
        self._refresh_status()

    # ── config ──────────────────────────────────────────────────────────
    def _load_config(self):
        try:
            self.cfg = load_config(self._config_path)
        except FileNotFoundError:
            self._config_path = write_default_config(self._config_path)
            self.cfg = load_config(self._config_path)

    # ── layout ──────────────────────────────────────────────────────────
    def _build_ui(self):
        # sidebar
        self._sidebar = ctk.CTkFrame(self, width=220, fg_color="#010409",
                                     corner_radius=0)
        self._sidebar.pack(side="left", fill="y")
        self._sidebar.pack_propagate(False)

        # logo area
        logo_frame = ctk.CTkFrame(self._sidebar, fg_color="transparent")
        logo_frame.pack(fill="x", padx=16, pady=(20, 8))
        ctk.CTkLabel(logo_frame, text="🛡", font=("Segoe UI", 32)).pack(
            side="left")
        title_col = ctk.CTkFrame(logo_frame, fg_color="transparent")
        title_col.pack(side="left", padx=8)
        ctk.CTkLabel(title_col, text="AEGIS", font=("Segoe UI Black", 18),
                     text_color=C_CYAN).pack(anchor="w")
        ctk.CTkLabel(title_col, text="SHIELD", font=("Segoe UI Light", 12),
                     text_color=C_DIM).pack(anchor="w")

        ctk.CTkFrame(self._sidebar, height=1, fg_color=C_BORDER).pack(
            fill="x", padx=12, pady=8)

        # nav buttons
        self._pages: dict[str, ctk.CTkFrame] = {}
        self._nav_btns: dict[str, ctk.CTkButton] = {}
        nav = [("dashboard", "📊  Dashboard"), ("folders", "📁  Folders"),
               ("incidents", "🚨  Incidents"), ("canaries", "🐦  Canaries"),
               ("settings", "⚙️  Settings")]
        for key, label in nav:
            btn = ctk.CTkButton(self._sidebar, text=label, font=FONT_BODY,
                                anchor="w", fg_color="transparent",
                                hover_color="#21262d", text_color=C_TEXT,
                                height=38, corner_radius=8,
                                command=lambda k=key: self._show_page(k))
            btn.pack(fill="x", padx=10, pady=2)
            self._nav_btns[key] = btn

        # version at bottom
        ctk.CTkLabel(self._sidebar, text=f"v{__version__}", font=FONT_SMALL,
                     text_color="#484f58").pack(side="bottom", pady=10)

        # main area
        self._main = ctk.CTkFrame(self, fg_color=C_BG, corner_radius=0)
        self._main.pack(side="left", fill="both", expand=True)

        self._build_dashboard()
        self._build_folders()
        self._build_incidents()
        self._build_canaries()
        self._build_settings()
        self._show_page("dashboard")

    def _show_page(self, name: str):
        for key, frame in self._pages.items():
            frame.pack_forget()
            self._nav_btns[key].configure(fg_color="transparent")
        self._pages[name].pack(fill="both", expand=True, padx=16, pady=12)
        self._nav_btns[name].configure(fg_color="#21262d")
        if name == "incidents":
            self._refresh_incidents()
        elif name == "canaries":
            self._refresh_canaries()

    # ── dashboard ───────────────────────────────────────────────────────
    def _build_dashboard(self):
        page = ctk.CTkFrame(self._main, fg_color="transparent")
        self._pages["dashboard"] = page

        # header
        hdr = ctk.CTkFrame(page, fg_color="transparent")
        hdr.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(hdr, text="System Protection Dashboard",
                     font=FONT_TITLE, text_color=C_TEXT).pack(side="left")
        self._start_btn = ctk.CTkButton(
            hdr, text="▶  START PROTECTION", font=FONT_BADGE, width=200,
            height=40, corner_radius=8, fg_color=C_GREEN,
            hover_color="#238636", command=self._toggle_agent)
        self._start_btn.pack(side="right")

        # status badges row
        badges = ctk.CTkFrame(page, fg_color="transparent")
        badges.pack(fill="x", pady=(0, 12))
        badges.columnconfigure((0, 1, 2, 3, 4), weight=1)
        self._b_status = StatusBadge(badges, "STATUS", "Idle", C_DIM)
        self._b_status.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self._b_sensor = StatusBadge(badges, "SENSOR", "—", C_DIM)
        self._b_sensor.grid(row=0, column=1, sticky="ew", padx=6)
        self._b_dirs = StatusBadge(badges, "PROTECTED DIRS", "0", C_DIM)
        self._b_dirs.grid(row=0, column=2, sticky="ew", padx=6)
        self._b_canaries = StatusBadge(badges, "CANARIES", "0", C_DIM)
        self._b_canaries.grid(row=0, column=3, sticky="ew", padx=6)
        self._b_incidents = StatusBadge(badges, "INCIDENTS", "0", C_DIM)
        self._b_incidents.grid(row=0, column=4, sticky="ew", padx=(6, 0))

        # event feed
        self._feed = EventFeed(page)
        self._feed.pack(fill="both", expand=True)

    # ── folders ─────────────────────────────────────────────────────────
    def _build_folders(self):
        page = ctk.CTkFrame(self._main, fg_color="transparent")
        self._pages["folders"] = page
        ctk.CTkLabel(page, text="Protected Folders", font=FONT_TITLE,
                     text_color=C_TEXT).pack(anchor="w", pady=(0, 12))

        self._folder_list = ctk.CTkFrame(page, fg_color=C_CARD,
                                         corner_radius=10, border_width=1,
                                         border_color=C_BORDER)
        self._folder_list.pack(fill="both", expand=True, pady=(0, 10))
        self._folder_items: list[ctk.CTkFrame] = []
        self._refresh_folder_list()

        btn_row = ctk.CTkFrame(page, fg_color="transparent")
        btn_row.pack(fill="x")
        ctk.CTkButton(btn_row, text="＋ Add Folder", font=FONT_BADGE,
                      width=160, height=36, corner_radius=8,
                      fg_color=C_BLUE, hover_color="#388bfd",
                      command=self._add_folder).pack(side="left")
        ctk.CTkButton(btn_row, text="＋ Add Suggested", font=FONT_BADGE,
                      width=180, height=36, corner_radius=8,
                      fg_color="#30363d", hover_color="#484f58",
                      command=self._add_suggested).pack(side="left", padx=8)
        ctk.CTkButton(btn_row, text="🔒 Protect Entire Drive", font=FONT_BADGE,
                      width=200, height=36, corner_radius=8,
                      fg_color="#8957e5", hover_color="#6e40c9",
                      command=self._protect_drive).pack(side="left", padx=8)

    def _refresh_folder_list(self):
        for w in self._folder_items:
            w.destroy()
        self._folder_items.clear()
        dirs = self.cfg.get("protected_dirs", [])
        if not dirs:
            lbl = ctk.CTkLabel(self._folder_list,
                               text="No folders protected yet. Add one below.",
                               font=FONT_BODY, text_color=C_DIM)
            lbl.pack(pady=30)
            self._folder_items.append(lbl)
            return
        for d in dirs:
            row = ctk.CTkFrame(self._folder_list, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=4)
            exists = os.path.isdir(d)
            icon = "✓" if exists else "✗"
            color = C_GREEN if exists else C_RED
            ctk.CTkLabel(row, text=icon, font=FONT_BADGE,
                         text_color=color, width=24).pack(side="left")
            ctk.CTkLabel(row, text=d, font=FONT_MONO,
                         text_color=C_TEXT).pack(side="left", padx=8)
            ctk.CTkButton(row, text="Remove", font=FONT_SMALL, width=70,
                          height=26, corner_radius=6, fg_color="#da3633",
                          hover_color="#b62324",
                          command=lambda p=d: self._remove_folder(p)).pack(
                side="right")
            self._folder_items.append(row)

    def _add_folder(self):
        path = tk.filedialog.askdirectory(title="Select folder to protect")
        if path and path not in self.cfg.get("protected_dirs", []):
            if self.plat.is_dangerous(path):
                tk.messagebox.showerror(
                    "Unsafe folder",
                    f"{path} is your home folder or a system directory.\n"
                    "Choose a specific subfolder (Documents, Desktop, …).")
                return
            self.cfg.setdefault("protected_dirs", []).append(path)
            self._save_config()
            self._refresh_folder_list()
            self._refresh_status()

    def _add_suggested(self):
        added = 0
        for d in self.plat.user_folders():
            if d not in self.cfg.get("protected_dirs", []):
                self.cfg.setdefault("protected_dirs", []).append(d)
                added += 1
        if added:
            self._save_config()
            self._refresh_folder_list()
            self._refresh_status()
        else:
            tk.messagebox.showinfo("Aegis", "All suggested folders are "
                                   "already added.")

    def _protect_drive(self):
        home = os.path.expanduser("~")
        if home not in self.cfg.get("protected_dirs", []):
            self.cfg.setdefault("protected_dirs", []).append(home)
        # Windows: add data drives
        if self.plat.name == "windows":
            import string
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if (os.path.isdir(drive)
                        and drive not in self.cfg["protected_dirs"]):
                    self.cfg["protected_dirs"].append(drive)
        self.cfg["allow_dangerous_dirs"] = True
        self._save_config()
        self._refresh_folder_list()
        self._refresh_status()
        self._feed.append(f"[{_ts()}] Full drive protection enabled", C_GREEN)
        tk.messagebox.showinfo(
            "Full Drive Protection",
            "Your home folder is now protected.\n\n"
            "Note: the first start will snapshot your files into ~/.aegis for "
            "rollback. On a large home folder this can take time and disk "
            "space. Files over 100 MB (videos, VM images) are watched but not "
            "snapshotted. You can raise that limit in Settings.")

    def _remove_folder(self, path):
        dirs = self.cfg.get("protected_dirs", [])
        if path in dirs:
            dirs.remove(path)
            self._save_config()
            self._refresh_folder_list()
            self._refresh_status()

    # ── incidents ───────────────────────────────────────────────────────
    def _build_incidents(self):
        page = ctk.CTkFrame(self._main, fg_color="transparent")
        self._pages["incidents"] = page
        hdr = ctk.CTkFrame(page, fg_color="transparent")
        hdr.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(hdr, text="Incident History", font=FONT_TITLE,
                     text_color=C_TEXT).pack(side="left")
        ctk.CTkButton(hdr, text="↻ Refresh", font=FONT_BADGE, width=100,
                      height=32, corner_radius=8, fg_color="#30363d",
                      command=self._refresh_incidents).pack(side="right")
        self._inc_scroll = ctk.CTkScrollableFrame(
            page, fg_color="transparent", corner_radius=0)
        self._inc_scroll.pack(fill="both", expand=True)
        self._inc_cards: list[ctk.CTkFrame] = []

    def _refresh_incidents(self):
        for w in self._inc_cards:
            w.destroy()
        self._inc_cards.clear()
        try:
            j = Journal(self.cfg["state_dir"], self.cfg)
            ids = j.list_incidents()
        except Exception:
            ids = []
        if not ids:
            lbl = ctk.CTkLabel(self._inc_scroll, text="No incidents recorded.",
                               font=FONT_BODY, text_color=C_DIM)
            lbl.pack(pady=30)
            self._inc_cards.append(lbl)
            return
        for iid in reversed(ids[-50:]):
            try:
                info = j.load_incident(iid)
            except Exception:
                continue
            card = IncidentCard(self._inc_scroll, info)
            card.pack(fill="x", pady=4)
            self._inc_cards.append(card)
        self._b_incidents.set(str(len(ids)),
                              C_RED if ids else C_GREEN)

    # ── canaries ────────────────────────────────────────────────────────
    def _build_canaries(self):
        page = ctk.CTkFrame(self._main, fg_color="transparent")
        self._pages["canaries"] = page
        hdr = ctk.CTkFrame(page, fg_color="transparent")
        hdr.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(hdr, text="Canary Tripwires", font=FONT_TITLE,
                     text_color=C_TEXT).pack(side="left")
        ctk.CTkButton(hdr, text="Plant Canaries", font=FONT_BADGE, width=140,
                      height=32, corner_radius=8, fg_color=C_GREEN,
                      hover_color="#238636",
                      command=self._seed_canaries).pack(side="right", padx=8)
        ctk.CTkButton(hdr, text="↻ Refresh", font=FONT_BADGE, width=100,
                      height=32, corner_radius=8, fg_color="#30363d",
                      command=self._refresh_canaries).pack(side="right")
        self._canary_scroll = ctk.CTkScrollableFrame(
            page, fg_color="transparent", corner_radius=0)
        self._canary_scroll.pack(fill="both", expand=True)
        self._canary_rows: list[ctk.CTkFrame] = []

    def _refresh_canaries(self):
        for w in self._canary_rows:
            w.destroy()
        self._canary_rows.clear()
        try:
            cm = CanaryManager(self.cfg["state_dir"])
            checks = cm.verify_all()
        except Exception:
            checks = []
        if not checks:
            lbl = ctk.CTkLabel(self._canary_scroll,
                               text="No canaries planted. Click 'Plant "
                                    "Canaries' after adding folders.",
                               font=FONT_BODY, text_color=C_DIM)
            lbl.pack(pady=30)
            self._canary_rows.append(lbl)
            return
        for path, status in checks:
            row = ctk.CTkFrame(self._canary_scroll, fg_color=C_CARD,
                               corner_radius=8, border_width=1,
                               border_color=C_BORDER)
            row.pack(fill="x", pady=3)
            if status is None:
                icon, color, label = "✓", C_GREEN, "INTACT"
            else:
                icon, color, label = "⚠", C_RED, status.upper()
            ctk.CTkLabel(row, text=f" {icon} {label}", font=FONT_BADGE,
                         text_color=color, width=100).pack(side="left",
                                                            padx=8, pady=6)
            ctk.CTkLabel(row, text=path, font=FONT_MONO,
                         text_color=C_TEXT).pack(side="left", padx=4)
            self._canary_rows.append(row)
        armed = sum(1 for _, s in checks if s is None)
        tripped = len(checks) - armed
        self._b_canaries.set(f"{armed} armed" +
                             (f"  ⚠ {tripped} TRIPPED" if tripped else ""),
                             C_GREEN if not tripped else C_RED)

    def _seed_canaries(self):
        dirs = self.cfg.get("protected_dirs", [])
        if not dirs:
            tk.messagebox.showwarning("Aegis",
                                      "Add protected folders first.")
            return
        cm = CanaryManager(self.cfg["state_dir"])
        seeded = cm.seed(dirs, self.cfg["canaries"]["filenames"])
        self._refresh_canaries()
        if seeded:
            self._feed.append(
                f"[{_ts()}] Planted {len(seeded)} canary file(s)", C_GREEN)

    # ── settings ────────────────────────────────────────────────────────
    def _build_settings(self):
        page = ctk.CTkFrame(self._main, fg_color="transparent")
        self._pages["settings"] = page
        ctk.CTkLabel(page, text="Settings", font=FONT_TITLE,
                     text_color=C_TEXT).pack(anchor="w", pady=(0, 16))

        grid = ctk.CTkFrame(page, fg_color=C_CARD, corner_radius=10,
                            border_width=1, border_color=C_BORDER)
        grid.pack(fill="x")
        r = 0

        def _row(label, var, tooltip=""):
            nonlocal r
            ctk.CTkLabel(grid, text=label, font=FONT_BODY,
                         text_color=C_TEXT).grid(row=r, column=0,
                                                 sticky="w", padx=16, pady=8)
            sw = ctk.CTkSwitch(grid, text="", variable=var,
                               onvalue=True, offvalue=False)
            sw.grid(row=r, column=1, padx=16, pady=8, sticky="e")
            if tooltip:
                ctk.CTkLabel(grid, text=tooltip, font=FONT_SMALL,
                             text_color=C_DIM).grid(row=r, column=2,
                                                     sticky="w", padx=8)
            r += 1

        self._v_kill = tk.BooleanVar(value=self.cfg.get("response", {})
                                     .get("kill_process", True))
        self._v_suspend = tk.BooleanVar(value=self.cfg.get("response", {})
                                        .get("suspend_first", True))
        self._v_egress = tk.BooleanVar(value=self.cfg.get("egress", {})
                                       .get("enabled", True))
        self._v_recovery = tk.BooleanVar(value=self.cfg.get(
            "recovery_guard", {}).get("enabled", True))

        _row("Kill attacking process", self._v_kill,
             "Terminate the process tree on detection")
        _row("Suspend-first (freeze before kill)", self._v_suspend,
             "Freeze instantly, then kill — prevents additional damage")
        _row("Egress / exfiltration guard", self._v_egress,
             "Flag bulk data uploads via transfer tools")
        _row("Recovery-inhibition guard", self._v_recovery,
             "Detect shadow-copy deletion, backup wiping (T1490)")
        grid.columnconfigure(2, weight=1)

        ctk.CTkButton(page, text="Save Settings", font=FONT_BADGE,
                      width=160, height=36, corner_radius=8,
                      fg_color=C_BLUE, hover_color="#388bfd",
                      command=self._save_settings).pack(anchor="w", pady=16)

        # info
        info = ctk.CTkFrame(page, fg_color=C_CARD, corner_radius=10,
                            border_width=1, border_color=C_BORDER)
        info.pack(fill="x", pady=(8, 0))
        lines = [
            f"Platform: {self.plat.name}",
            f"State dir: {self.cfg.get('state_dir', '—')}",
            f"Config: {self._config_path}",
            f"Version: {__version__}",
        ]
        for line in lines:
            ctk.CTkLabel(info, text=line, font=FONT_MONO,
                         text_color=C_DIM, anchor="w").pack(fill="x",
                                                             padx=16, pady=2)

    def _save_settings(self):
        self.cfg.setdefault("response", {})["kill_process"] = self._v_kill.get()
        self.cfg["response"]["suspend_first"] = self._v_suspend.get()
        self.cfg.setdefault("egress", {})["enabled"] = self._v_egress.get()
        self.cfg.setdefault("recovery_guard", {})["enabled"] = self._v_recovery.get()
        self._save_config()
        self._feed.append(f"[{_ts()}] Settings saved", C_BLUE)

    # ── agent control ───────────────────────────────────────────────────
    def _toggle_agent(self):
        if self._running:
            self._stop_agent()
        else:
            self._start_agent()

    def _start_agent(self):
        dirs = self.cfg.get("protected_dirs", [])
        if not dirs:
            tk.messagebox.showwarning(
                "Aegis", "Add at least one protected folder first.")
            self._show_page("folders")
            return
        missing = [d for d in dirs if not os.path.isdir(d)]
        if missing:
            tk.messagebox.showerror(
                "Aegis", "Folder(s) do not exist:\n" +
                         "\n".join(missing))
            return
        self._load_config()
        self._feed.append(f"[{_ts()}] Starting Aegis agent…", C_CYAN)
        self._start_btn.configure(text="⏹  STOP PROTECTION",
                                  fg_color=C_RED, hover_color="#b62324")

        def _run():
            try:
                from .agent import AegisAgent
                self._agent = AegisAgent(self.cfg)
                # seed canaries if not already present
                cm = CanaryManager(self.cfg["state_dir"])
                seeded = cm.seed(
                    self._agent.protected_dirs,
                    self.cfg["canaries"]["filenames"])
                if seeded:
                    self.after(0, lambda: self._feed.append(
                        f"[{_ts()}] Planted {len(seeded)} canaries", C_GREEN))
                baseline = self._agent.start()
                self._running = True
                self.after(0, lambda: self._on_agent_started(baseline))
                # poll for incidents
                while self._running:
                    self._poll_incidents()
                    time.sleep(1.0)
            except Exception as e:
                msg = str(e)
                self._running = False
                self.after(0, lambda m=msg: self._on_agent_error(m))

        self._agent_thread = threading.Thread(target=_run, daemon=True,
                                              name="aegis-gui-agent")
        self._agent_thread.start()

    def _on_agent_started(self, baseline_id: str):
        self._b_status.set("PROTECTED", C_GREEN)
        sensor = getattr(self._agent, "sensor_mode", "userspace")
        self._b_sensor.set(sensor.split("(")[0].strip(), C_CYAN)
        self._feed.append(f"[{_ts()}] Agent running — baseline {baseline_id}",
                          C_GREEN)
        self._feed.append(f"[{_ts()}] Sensor: {sensor}", C_CYAN)
        self._refresh_status()

    def _on_agent_error(self, msg: str):
        self._b_status.set("ERROR", C_RED)
        self._feed.append(f"[{_ts()}] Agent error: {msg}", C_RED)
        self._start_btn.configure(text="▶  START PROTECTION",
                                  fg_color=C_GREEN, hover_color="#238636")

    def _stop_agent(self):
        self._running = False
        if self._agent:
            try:
                self._agent.stop()
            except Exception:
                pass
            self._agent = None
        self._b_status.set("Stopped", C_AMBER)
        self._feed.append(f"[{_ts()}] Agent stopped", C_AMBER)
        self._start_btn.configure(text="▶  START PROTECTION",
                                  fg_color=C_GREEN, hover_color="#238636")

    def _poll_incidents(self):
        """Check for new incidents while agent runs."""
        try:
            j = Journal(self.cfg["state_dir"], self.cfg)
            ids = j.list_incidents()
            count = len(ids)
            if count > 0:
                latest = j.load_incident(ids[-1])
                reason = (latest.get("reasons") or ["—"])[0][:60]
                killed = latest.get("killed", False)
                self.after(0, lambda: self._b_incidents.set(
                    str(count), C_RED))
                self.after(0, lambda: self._feed.append(
                    f"[{_ts()}] ⚠ INCIDENT: {reason} "
                    f"{'[KILLED]' if killed else '[ALERT]'}", C_RED))
        except Exception:
            pass

    # ── helpers ─────────────────────────────────────────────────────────
    def _refresh_status(self):
        dirs = self.cfg.get("protected_dirs", [])
        self._b_dirs.set(str(len(dirs)), C_GREEN if dirs else C_DIM)
        try:
            cm = CanaryManager(self.cfg["state_dir"])
            self._b_canaries.set(str(cm.count),
                                 C_GREEN if cm.count else C_DIM)
        except Exception:
            self._b_canaries.set("0", C_DIM)
        try:
            j = Journal(self.cfg["state_dir"], self.cfg)
            n = len(j.list_incidents())
            self._b_incidents.set(str(n), C_RED if n else C_GREEN)
        except Exception:
            pass

    def _save_config(self):
        import yaml
        with open(self._config_path, "w", encoding="utf-8") as fh:
            yaml.safe_dump(self.cfg, fh, sort_keys=False)

    def _on_close(self):
        if self._running:
            self._stop_agent()
        self.destroy()


def main(config_path: str | None = None):
    app = AegisApp(config_path)
    app.mainloop()


if __name__ == "__main__":
    main()
