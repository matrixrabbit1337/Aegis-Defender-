"""Recovery-inhibition guard (MITRE T1490) — cross-platform process monitor.

Research finding (2023–2026): almost every ransomware family destroys the
victim's ability to recover *seconds to minutes before* the encryption burst —
deleting shadow copies, wiping free space, removing the recovery partition,
clearing logs, killing ESXi VMs, loading a vulnerable driver to disable EDR.
Catching that step is the single best "before encryption" trip we can add,
because it is loud, near-universal, and gives the defender a head start.

This guard polls the process table (psutil) and matches each command line
against aegis.intel.matches_recovery_inhibit(). A hit is HIGH confidence:
it suspends/kills the offender and raises an incident, before the encryptor
runs. Works on Windows (vssadmin/wmic/reagentc/cipher/diskpart/bcdedit/BYOVD),
Linux & ESXi (esxcli vm kill, vmdk deletion), and macOS (tmutil/log erase)."""
from __future__ import annotations

import threading

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None

from .events import Event, EventKind
from .intel import matches_recovery_inhibit


class RecoveryGuard:
    def __init__(self, config: dict, agent):
        c = config.get("recovery_guard", {}) or {}
        self.enabled = bool(c.get("enabled", True))
        self.agent = agent
        self._interval = float(c.get("poll_s", 0.5))  # fast: this is the race
        self._seen: set[int] = set()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self):
        if not (self.enabled and psutil):
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="aegis-recovery")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def _loop(self):
        while not self._stop.wait(self._interval):
            try:
                self._scan()
            except Exception:
                pass

    def _scan(self):
        for proc in psutil.process_iter(["pid", "name", "cmdline", "ppid"]):
            pid = proc.info["pid"]
            if pid in self._seen or pid == __import__("os").getpid():
                continue
            cmd = " ".join(proc.info.get("cmdline") or [])
            if not cmd:
                continue
            reason = matches_recovery_inhibit(cmd)
            if reason:
                self._seen.add(pid)
                ev = Event(kind=EventKind.PERSISTENCE, pid=pid,
                           exe=proc.info.get("name"), source="recovery_guard",
                           extra={"cmdline": cmd[:200], "reason": reason})
                self.agent.on_recovery_inhibit(ev, reason)
        if len(self._seen) > 4096:
            self._seen = set(list(self._seen)[-1024:])
