"""Behavioral defenses that polymorphic / AI-mutated malware cannot shed.

Research (Palo Alto Unit 42 Aug 2026; MITRE T1027.014; UNC/academic studies
2020-2026) converges on one point: malware can rewrite its *code* on every run,
but it cannot change what it must *do* to be ransomware — traverse files, read
them whole, write high-entropy data, rename/delete, and inhibit recovery. AI
changes how the binary is written, not these behaviours. So Aegis detects on
behaviour, never on file signatures/hashes (which polymorphism defeats).

This module adds behaviour signals that are independent of the payload's bytes
and resistant to the known evasions in the literature:

  * SPREAD across directories — ransomware walks the tree; a user edits a file.
  * READ-then-REWRITE pairs — the read-encrypt-overwrite loop, even when the
    writer keeps entropy low (compression/partial-encryption evasion), the
    *access pattern* (touching many distinct files fast) remains.
  * DISTINCT-FILE velocity — N different protected files touched by one process
    within a short window, regardless of content. This catches low-entropy and
    intermittent-encryption ransomware that beats pure entropy checks.
  * HONEYPOT density — many canaries, so an evader that skips some still hits
    others; any hit is decisive.

These are scored per process and combine with the entropy/rename/note/recovery
signals already in the engine. No single evasion (low entropy, slow pace,
partial encryption, renaming avoidance) defeats all of them at once.
"""
from __future__ import annotations

import os
import threading
import time
from collections import defaultdict


class SpreadTracker:
    """Tracks how many DISTINCT files each process touches over a window, and
    how widely across directories. Content-independent: works even when the
    writer defeats entropy detection."""

    def __init__(self, config: dict):
        c = config.get("behavior", {}) or {}
        self.enabled = bool(c.get("enabled", True))
        self._window = float(c.get("window_s", 60))
        # distinct protected files touched by one process to raise the signal
        self._file_threshold = int(c.get("distinct_file_threshold", 10))
        self._dir_threshold = int(c.get("distinct_dir_threshold", 3))
        self._points = int(c.get("spread_points", 20))
        self._touch: dict[int, list] = defaultdict(list)  # pid -> [(ts,path)]
        self._lock = threading.Lock()

    def record(self, pid: int | None, path: str, ts: float | None = None):
        """Register a file touch. Returns (points, reason) if the spread
        pattern crosses the threshold, else (0, None)."""
        if not (self.enabled and pid):
            return 0, None
        ts = ts or time.time()
        with self._lock:
            lst = self._touch[pid]
            lst.append((ts, os.path.realpath(path)))
            cutoff = ts - self._window
            lst = [(t, p) for t, p in lst if t >= cutoff]
            self._touch[pid] = lst
            files = {p for _, p in lst}
            dirs = {os.path.dirname(p) for p in files}
            if (len(files) >= self._file_threshold
                    and len(dirs) >= self._dir_threshold):
                return self._points, (
                    f"rapid spread: {len(files)} files across {len(dirs)} "
                    f"folders in {int(self._window)}s (content-independent)")
            if len(files) >= self._file_threshold:
                return self._points // 2, (
                    f"rapid file churn: {len(files)} distinct files in "
                    f"{int(self._window)}s")
        return 0, None

    def forget(self, pid: int):
        with self._lock:
            self._touch.pop(pid, None)
