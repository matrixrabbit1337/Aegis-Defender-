"""AegisAgent — wires config → sensors → engine → response → recovery.

Sensor selection (Phase D): on Linux as root it uses the fanotify kernel sensor
with REAL pre-write blocking; otherwise the cross-platform user-space watchdog
sensor (detect + kill + rollback). Egress guard (Phase E) and integrity/
persistence tripwires run alongside. Every action is written to the evidence
log with a reason code (Phase A).
"""
from __future__ import annotations

import os
import time

from .canary import CanaryManager
from .egress import EgressGuard
from .events import Event, EventKind, Decision
from .evidence import EvidenceLog
from .heuristics import DetectionEngine, ProcessAttributor
from .integrity import IntegrityMonitor
from .recovery_guard import RecoveryGuard
from .journal import Journal
from .platforms import get_platform
from .response import Responder
from .sensors import build_sensor
from .hardening import IntegrityVerifier, ProcessGuard, StateEncryptor


class AegisAgent:
    def __init__(self, config: dict):
        self.config = config
        self.plat = get_platform()
        self.state_dir = os.path.realpath(
            os.path.expanduser(config["state_dir"]))
        raw_dirs = config["protected_dirs"]
        if not raw_dirs or raw_dirs == ["auto"]:
            raw_dirs = self._auto_protect_dirs()
        seen: set = set()
        self.protected_dirs = []
        for d in raw_dirs:
            rp = os.path.realpath(d)
            if rp not in seen and os.path.isdir(rp):
                seen.add(rp)
                self.protected_dirs.append(rp)
        self.canaries = CanaryManager(self.state_dir)
        self.journal = Journal(self.state_dir, config)
        self.journal.agent = self  # back-ref for containment scope checks
        self.evidence = EvidenceLog(self.state_dir)
        self.attributor = ProcessAttributor(config)
        self.engine = DetectionEngine(config, self.attributor)
        self.responder = Responder(config, self.journal, evidence=self.evidence)
        self.engine.on_trigger = self._on_trigger
        self.egress = EgressGuard(config, self)
        self.integrity_mon = IntegrityMonitor(config, self)
        self.recovery_guard = RecoveryGuard(config, self)
        self.sensor = None
        self.sensor_mode = "n/a"
        self.encryptor = StateEncryptor(self.state_dir)
        self.integrity = IntegrityVerifier()
        self.proc_guard = ProcessGuard(
            on_tamper=lambda msg: self._on_tamper(msg))
        self.dry_run = bool(config.get("response", {}).get("dry_run"))

    def _auto_protect_dirs(self) -> list[str]:
        """Auto-detect directories to protect: the user's home folder and
        any additional data drives. Excludes system dirs the OS needs."""
        home = os.path.expanduser("~")
        dirs = [home]
        # On Windows, also check for D:\, E:\ etc. data drives
        if self.plat.name == "windows":
            import string
            for letter in string.ascii_uppercase:
                drive = f"{letter}:\\"
                if os.path.isdir(drive) and drive.upper() not in ("C:\\",):
                    dirs.append(drive)
        return dirs

    # -- scope -------------------------------------------------------------
    def _in_scope(self, path: str) -> bool:
        n = self.plat.normcase
        rp = n(os.path.realpath(path))
        state = n(self.state_dir)
        if rp == state or rp.startswith(state + os.sep):
            return False
        return any(rp == n(d) or rp.startswith(n(d) + os.sep)
                   for d in self.protected_dirs)

    # -- event sinks (called by sensors) -----------------------------------
    def on_event(self, event: "Event") -> "Decision":
        """File event from a sensor. Returns a Decision (blocking sensors
        enforce it; detect-only sensors ignore the return)."""
        try:
            if event.canary:
                self.evidence.record("canary.touch", event)
            return self.engine.evaluate(event)
        except Exception as exc:
            print(f"[aegis] on_event failed: {exc!r}", flush=True)
            return Decision.ALLOW

    def freeze_attacker(self, pid: int) -> None:
        """Instantly suspend a process tree the kernel sensor flagged, before
        the full incident is built. Microsecond syscall, reversible. The
        responder later kills it (or a human resumes it if it was a false
        positive)."""
        try:
            self.responder.containment.suspend(pid)
        except Exception:
            pass

    def quick_verdict(self, path, pid, exe, entropy, size, canary,
                      is_write=False) -> "Decision":
        """Fast, side-effect-free allow/deny for the kernel sensor. No kill, no
        incident, no I/O beyond what the caller already did. A canary or an
        obvious encryption signature denies the write immediately; everything
        else is allowed (fail-open) and judged by the full engine afterwards."""
        if self.dry_run:
            return Decision.ALLOW
        # A canary should never be touched by any legitimate program, so a
        # canary open is always denied. For every OTHER file we must NOT block
        # on open/read — reading a photo, zip, or encrypted archive is normal
        # and blocking it would make the system unusable. Encryption is caught
        # on the WRITE path (watch of file modifications), not here.
        if canary:
            return Decision.DENY
        # Reads are ALWAYS allowed — only writes can harm your files.
        if not is_write:
            return Decision.ALLOW
        try:
            from .intel import is_ransom_extension
            if is_ransom_extension(path):
                return Decision.DENY  # writing a known ransomware-extension file
        except Exception:
            pass
        # A high-entropy WRITE to a protected file is encryption in progress —
        # block it. This is language-agnostic: C, Go, Rust, bash+openssl, or an
        # AI-generated encryptor all produce high-entropy ciphertext.
        d = self.config["detection"]
        if (entropy is not None and entropy >= d["entropy_threshold"]
                and (size or 0) >= max(512, d["entropy_min_bytes"])):
            return Decision.DENY
        return Decision.ALLOW

    def on_egress(self, event: "Event", signals) -> None:
        self.evidence.record("egress.suspected", event, signals=signals)
        reasons = ["EGRESS: " + s for s in signals]
        # Default alert-only: legitimate backup/sync tools (rclone, rsync,
        # cloud clients) look exactly like exfiltration. Opt in to containment
        # with egress.contain: true.
        contain = bool(self.config.get("egress", {}).get("contain", False))
        self.responder.handle_trigger(
            event.pid, reasons, score=60.0,
            context={"protected_dirs": self.protected_dirs,
                     "kind": "egress", "dry_run": self.dry_run,
                     "alert_only": not contain})

    def on_integrity(self, event: "Event", critical: bool) -> None:
        code = "store.attack" if event.kind == EventKind.STORE_ACCESS \
            else "persistence.change"
        self.evidence.record(code, event, critical=critical)
        detail = event.extra.get("detail", "")
        if critical:
            self.responder.handle_trigger(
                None, [f"PROTECTED STORE under attack: {detail}"],
                score=1e6,
                context={"protected_dirs": self.protected_dirs,
                         "kind": "store", "dry_run": self.dry_run})
        else:
            print(f"[aegis] persistence change noted: {detail}", flush=True)

    def on_recovery_inhibit(self, event: "Event", reason: str) -> None:
        """A process tried to destroy recovery (shadow copies, recovery
        partition, free-space wipe, ESXi VM kill, BYOVD). This is a loud,
        near-universal pre-encryption step — treat as high confidence and act
        immediately, before the encryptor runs."""
        self.evidence.record("recovery.inhibit", event, reason=reason)
        print(f"[aegis] RECOVERY-INHIBITION detected (pre-encryption): "
              f"{reason}", flush=True)
        self.responder.handle_trigger(
            event.pid, [f"T1490 {reason}"], score=90.0,
            context={"protected_dirs": self.protected_dirs,
                     "kind": "recovery_inhibit", "dry_run": self.dry_run})

    def _on_tamper(self, msg: str) -> None:
        print(f"[aegis] TAMPER DETECTED: {msg}", flush=True)
        self.evidence.record("tamper.detected", detail=msg)
        self.plat.notify("Aegis tamper alert", msg)

    def _on_trigger(self, pid, reasons, score, context) -> None:
        context = dict(context or {})
        context.pop("event", None)
        context["protected_dirs"] = self.protected_dirs
        context["dry_run"] = self.dry_run
        self.responder.handle_trigger(pid, reasons, score, context)

    # -- lifecycle ---------------------------------------------------------
    @staticmethod
    def _is_fs_root(path: str) -> bool:
        rp = os.path.realpath(path)
        if rp == os.path.abspath(os.sep):
            return True
        drive, rest = os.path.splitdrive(rp)
        return bool(drive) and rest in (os.sep, "/", "")

    def start(self) -> str:
        for d in self.protected_dirs:
            if self._is_fs_root(d):
                raise RuntimeError(
                    f"refusing to protect filesystem root {d}.")
            if not os.path.isdir(d):
                raise RuntimeError(f"protected dir does not exist: {d}")
            if (self.plat.is_dangerous(d)
                    and not self.config.get("allow_dangerous_dirs")):
                raise RuntimeError(
                    f"refusing to protect {d}: home/system directory. "
                    "Protect specific subfolders or set allow_dangerous_dirs.")
        baseline_id = self.journal.take_baseline(self.protected_dirs)
        stats = self.journal.last_baseline_stats
        if stats.get("not_backed_up"):
            print(f"[aegis] NOTE: {stats['not_backed_up']} file(s) not backed "
                  "up (over cap/symlink/locked). Watched, never deleted by "
                  "rollback.", flush=True)
        self.attributor.start()
        self.sensor, self.sensor_mode = build_sensor(self)
        self.sensor.start()
        self.egress.start()
        self.integrity_mon.start()
        self.proc_guard.start()
        # verify code integrity
        tampered = self.integrity.verify()
        if tampered:
            print(f"[aegis] WARNING: {len(tampered)} source file(s) modified "
                  "since install — possible tampering!", flush=True)
            self.evidence.record("integrity.code_tamper", files=tampered)
        self.recovery_guard.start()
        self.evidence.record("agent.start", baseline_id=baseline_id,
                             sensor=self.sensor_mode,
                             protected_dirs=self.protected_dirs,
                             dry_run=self.dry_run)
        return baseline_id

    def stop(self) -> None:
        for comp in (self.sensor, self.egress, self.integrity,
                     self.recovery_guard, self.attributor):
            try:
                if comp:
                    comp.stop()
            except Exception:
                pass
        self.evidence.record("agent.stop")

    def run_forever(self) -> None:
        baseline_id = self.start()
        mode = " [DRY-RUN: detect & log only, no kill/block]" if self.dry_run \
            else ""
        print(f"[aegis] platform: {self.plat.name}; sensor: "
              f"{self.sensor_mode}{mode}")
        print(f"[aegis] attribution: {self.plat.attribution_note}")
        print(f"[aegis] watching {len(self.protected_dirs)} dir(s); baseline "
              f"{baseline_id}; {self.canaries.count} canaries; egress "
              f"{'on' if self.egress.enabled else 'off'}. Ctrl+C to stop.")
        print(f"[aegis] evidence log: {self.evidence.path}")
        try:
            check_counter = 0
            while True:
                time.sleep(1)
                check_counter += 1
                self.proc_guard.beat()
                if check_counter % 30 == 0:  # every 30 seconds
                    tampered = self.integrity.verify()
                    if tampered:
                        self._on_tamper(
                            f"code modified: {', '.join(tampered[:3])}")
        except KeyboardInterrupt:
            print("\n[aegis] stopping…")
        finally:
            self.stop()
