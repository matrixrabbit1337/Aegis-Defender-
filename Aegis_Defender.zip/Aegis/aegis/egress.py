"""Phase E — pre-encryption egress guard (detection-first).

The plan's novel gap #2: spot bulk exfiltration *before* the encryption burst.
Pure user-space and cross-platform via psutil: it correlates three independent
signals and only flags when they stack, to avoid tripping on normal web use:

  1. a known transfer tool is running (rclone, mega, ngrok, curl, wget, scp,
     rsync, winscp, filezilla, 7z/zip/rar staging an archive),
  2. a new, recently-written archive is staged in a protected dir, and
  3. a process pushes an anomalous volume of bytes to a novel remote host.

It never blocks on volume alone (a cloud backup would be a false positive);
high confidence = tool + (staging OR novel destination) + volume over baseline.
Verdicts go through the same engine/responder as file events.
"""
from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass, field

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None

from .events import Event, EventKind

_TRANSFER_TOOLS = {
    "rclone", "mega-cmd", "megacmd", "megatools", "ngrok", "curl", "wget",
    "scp", "sftp", "rsync", "winscp.exe", "filezilla", "filezilla.exe",
    "ftp", "nc", "ncat", "socat", "aws", "gsutil", "azcopy", "b2",
}
_ARCHIVE_EXTS = {".zip", ".rar", ".7z", ".tar", ".gz", ".tgz", ".zst",
                 ".bz2", ".xz", ".iso"}
_PRIVATE_PREFIXES = ("10.", "192.168.", "127.", "169.254.", "::1", "fe80:",
                     "172.16.", "172.17.", "172.18.", "172.19.", "172.20.",
                     "172.21.", "172.22.", "172.23.", "172.24.", "172.25.",
                     "172.26.", "172.27.", "172.28.", "172.29.", "172.30.",
                     "172.31.")


def is_transfer_tool(name: str) -> bool:
    n = (name or "").lower()
    return n in _TRANSFER_TOOLS or os.path.splitext(n)[0] in _TRANSFER_TOOLS


def is_public_ip(ip: str) -> bool:
    return bool(ip) and not ip.startswith(_PRIVATE_PREFIXES)


@dataclass
class _ProcIO:
    last_bytes: int = 0
    seen_hosts: set = field(default_factory=set)


class EgressGuard:
    """Samples per-process network counters + connections in a background
    thread and raises a contract Event when exfiltration signals stack."""

    def __init__(self, config: dict, agent):
        c = config.get("egress", {}) or {}
        self.enabled = bool(c.get("enabled", True))
        self.agent = agent
        self._interval = float(c.get("sample_interval_s", 2.0))
        # bytes/sample over baseline that counts as "bulk" (default 20 MB)
        self._volume_threshold = int(c.get("volume_threshold_mb", 20)) \
            * 1024 * 1024
        self._stale = float(c.get("archive_fresh_s", 300))
        self._state: dict[int, _ProcIO] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self):
        if not (self.enabled and psutil):
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="aegis-egress")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def _loop(self):
        # per-process net counters need psutil on Linux (/proc) — on platforms
        # without them we fall back to connection + tool correlation only.
        while not self._stop.wait(self._interval):
            try:
                self._scan()
            except Exception:
                pass

    def _recent_archive_staged(self) -> str | None:
        now = time.time()
        for d in self.agent.protected_dirs:
            try:
                with os.scandir(d) as it:
                    for e in it:
                        if (e.is_file(follow_symlinks=False)
                                and os.path.splitext(e.name)[1].lower()
                                in _ARCHIVE_EXTS):
                            if now - e.stat().st_mtime < self._stale:
                                return e.path
            except OSError:
                continue
        return None

    def _scan(self):
        if psutil is None:
            return
        staged = self._recent_archive_staged()
        for proc in psutil.process_iter(["pid", "name"]):
            pid = proc.info["pid"]
            name = proc.info.get("name") or ""
            tool = is_transfer_tool(name)
            # novel public destination?
            novel = None
            try:
                # psutil >= 6: net_connections(); psutil 5.x: connections()
                get_conns = getattr(proc, "net_connections", None) \
                    or getattr(proc, "connections")
                for conn in get_conns(kind="inet"):
                    if conn.raddr and is_public_ip(conn.raddr.ip):
                        st = self._state.setdefault(pid, _ProcIO())
                        if conn.raddr.ip not in st.seen_hosts:
                            st.seen_hosts.add(conn.raddr.ip)
                            novel = conn.raddr.ip
            except (psutil.Error, AttributeError):
                pass
            # volume over last sample
            vol = 0
            try:
                io = proc.io_counters()
                wb = getattr(io, "write_chars", None)
                if wb is None:
                    wb = getattr(io, "other_bytes", 0)
                st = self._state.setdefault(pid, _ProcIO())
                if st.last_bytes:
                    vol = max(0, wb - st.last_bytes)
                st.last_bytes = wb
            except (psutil.Error, AttributeError, NotImplementedError):
                pass

            signals = []
            if tool:
                signals.append(f"transfer tool running: {name}")
            if staged:
                signals.append(f"fresh archive staged: {os.path.basename(staged)}")
            if novel:
                signals.append(f"new outbound destination: {novel}")
            if vol >= self._volume_threshold:
                signals.append(f"bulk outbound volume: {vol // (1024*1024)} MB")

            # high confidence: tool + (staging or novel dest), or
            # staging + novel dest + volume. Never volume alone.
            strong = (tool and (staged or novel)) or \
                     (staged and novel and vol >= self._volume_threshold)
            if strong and len(signals) >= 2:
                ev = Event(kind=EventKind.NET_UPLOAD, pid=pid, exe=name,
                           dest=novel, bytes_out=vol, source="egress",
                           extra={"signals": signals})
                self.agent.on_egress(ev, signals)
