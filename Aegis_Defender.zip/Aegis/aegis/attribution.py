"""Language-agnostic process attribution.

Ransomware can be written in ANYTHING — C, Rust, Go, bash, PowerShell, a
compiled binary, a living-off-the-land tool. Aegis never looks at the language;
it answers one question: "which process is touching this file right now?"

This module makes that answer fast and reliable across OSes by combining
several signals, strongest first:

  1. KERNEL-SUPPLIED PID — on Linux with the fanotify sensor the kernel hands
     us the exact writer. 100% accurate, any language. (handled upstream)
  2. OPEN-FILE LOOKUP — scan every process for an open handle to the touched
     file (psutil.open_files). Works on all OSes, any language, but only while
     the file is still open.
  3. RECENT-WRITER CACHE — a rolling record of which PID last wrote into each
     watched directory, so a fast attacker that already closed the file is
     still identified by its other writes in the same burst.
  4. WRITE-VOLUME / NEWEST-PROCESS fallback — the process doing the most disk
     writes, or the youngest non-system process, in the detection window.

None of these inspect code or language. A canary trip is high-confidence, so
we try all four and act on the best guess rather than giving up.
"""
from __future__ import annotations

import os
import time
from collections import deque

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


class RecentWriters:
    """Rolling cache: directory -> deque of (pid, ts) that recently wrote there.
    Populated by the detection engine on every file event, so even a process
    that already exited leaves a trace for the canary attributor to use."""

    def __init__(self, window_s: float = 30.0, maxlen: int = 256):
        self._window = window_s
        self._by_dir: dict[str, deque] = {}
        self._all: deque = deque(maxlen=maxlen)

    def record(self, path: str, pid: int | None, ts: float | None = None):
        if not pid:
            return
        ts = ts or time.time()
        d = os.path.dirname(os.path.realpath(path))
        dq = self._by_dir.setdefault(d, deque(maxlen=64))
        dq.append((pid, ts))
        self._all.append((pid, ts))

    def candidates(self, path: str, now: float | None = None) -> list[int]:
        """PIDs that recently wrote near `path`, newest first."""
        now = now or time.time()
        d = os.path.dirname(os.path.realpath(path))
        out: list[int] = []
        seen = set()
        for pid, ts in reversed(self._by_dir.get(d, ())):
            if now - ts <= self._window and pid not in seen:
                seen.add(pid)
                out.append(pid)
        # also consider any recent writer anywhere (attacker may hit many dirs)
        for pid, ts in reversed(self._all):
            if now - ts <= self._window and pid not in seen:
                seen.add(pid)
                out.append(pid)
        return out


def newest_suspect(exclude_pids, is_safe) -> int | None:
    """Fallback: the youngest non-system, non-safe process. A freshly spawned
    process writing during a canary trip is a strong ransomware suspect,
    whatever language it's written in."""
    if psutil is None:
        return None
    best_pid, best_age = None, 1e18
    now = time.time()
    for proc in psutil.process_iter(["pid", "create_time", "name"]):
        pid = proc.info["pid"]
        if pid in exclude_pids or pid <= 1:
            continue
        try:
            if not is_safe(proc):
                age = now - (proc.info.get("create_time") or 0)
                if 0 <= age < best_age:
                    best_age, best_pid = age, pid
        except Exception:
            continue
    # only trust it if it is genuinely young (spawned in the last 60s)
    return best_pid if best_age <= 60 else None
