"""Incident response: kill the offending process tree, quarantine the binary,
write a machine-readable incident report plus a human-readable log, and alert.

Safety rules (hard):
  * never touch PID <= 1, never kill our own process
  * never kill a process whose command line belongs to the Aegis agent itself
  * never kill OS-critical processes (per-OS list in aegis/platforms/)
  * a missing/unknown PID still produces an incident report and an alert —
    response degrades gracefully instead of failing (it never guesses)
  * one attack = one incident: triggers inside the merge window are folded
    into the open incident; a newly attributed PID is still acted on
"""
from __future__ import annotations

import os
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

from .heuristics import looks_like_aegis_agent
from .platforms import get_platform
from .containment import Containment

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None


class Responder:
    def __init__(self, config: dict, journal, evidence=None):
        self.cfg = config.get("response", {}) or {}
        self.journal = journal
        self.plat = get_platform()
        self.state_dir = Path(journal.state_dir)
        self.quarantine_dir = self.state_dir / "quarantine"
        self.quarantine_dir.mkdir(parents=True, exist_ok=True)
        self.containment = Containment(self.plat, config,
                                       agent=getattr(journal, 'agent', None))
        self._merge_window = float(self.cfg.get("merge_window_s", 300))
        self._open: tuple[str, float] | None = None  # (incident_id, ts)
        self.evidence = evidence

    # -- main entry --------------------------------------------------------
    def handle_trigger(self, pid: int | None, reasons: list[str],
                       score: float, context: dict | None = None) -> str:
        """Run the full response playbook. Returns the incident id."""
        context = context or {}
        self._dry_run = bool(self.cfg.get("dry_run")
                             or context.get("dry_run"))
        # Containment (freeze/kill) only for a CERTAIN culprit. A guessed PID
        # (top-writer fallback) or an alert-only source (egress) is named in
        # the report but never frozen: freezing the wrong process can hang a
        # backup tool, a cloud-drive mount, or the whole filesystem.
        if pid and (context.get("alert_only")
                    or context.get("attribution") == "guess"):
            why = ("alert-only source" if context.get("alert_only")
                   else "unconfirmed (best guess)")
            reasons = list(reasons) + [
                f"suspected pid {pid} — {why}; not contained"]
            pid = None
        now = time.time()
        if self.evidence:
            self.evidence.record("response.trigger", pid=pid, score=score,
                                 reasons=reasons[:5],
                                 kind=context.get("kind", "file"))
        if (self._open and now - self._open[1] <= self._merge_window
                and self._incident_exists(self._open[0])):
            return self._merge(self._open[0], pid, reasons, score, now)

        proc = self._describe(pid) if pid else None
        incident_id = self.journal.create_incident({
            "detected_at": now,
            "detected_at_iso": datetime.now(timezone.utc).isoformat(),
            "pid": pid,
            "process": proc,
            "score": score,
            "reasons": list(reasons),
            "baseline_id": self.journal.last_baseline_id,
            "protected_dirs": context.get("protected_dirs", []),
            "pids_handled": [],
        })
        self._open = (incident_id, now)

        killed, quarantined, note = self._act(incident_id, pid, proc)
        updates = {"killed": killed, "quarantined": quarantined,
                   "pids_handled": [pid] if pid else []}
        if note:
            updates["note"] = note
        self.journal.update_incident(incident_id, updates)
        self._write_human_log(incident_id, pid, proc, reasons, score,
                              killed, quarantined, note)
        self._alert(incident_id, pid, proc, reasons, killed, note)
        return incident_id

    def _incident_exists(self, incident_id: str) -> bool:
        return (self.state_dir / "incidents" / incident_id /
                "report.json").exists()

    def _act(self, incident_id: str, pid, proc):
        """Kill + quarantine one process. Returns (killed, quarantined, note)."""
        if not pid:
            return False, None, ("no process could be positively attributed; "
                                 "nothing was killed")
        if proc and self.plat.is_protected_process(proc.get("name"), pid):
            return False, None, (f"{proc.get('name')} is an OS-critical "
                                 "process; refusing to kill it")
        killed = False
        if self._dry_run:
            if self.evidence:
                self.evidence.record("response.audit", pid=pid,
                                     would="kill+quarantine")
            return False, None, ("DRY-RUN: would kill this process tree; "
                                 "no action taken")
        note = None
        if self.cfg.get("kill_process", True):
            # suspend-first containment: freeze the tree instantly (prevention
            # without a kernel driver), snapshot, then kill. Works on all OSes.
            result = self.containment.contain(pid)
            killed = result["killed"]
            if result["suspended"]:
                note = (f"frozen {len(result['suspended'])} process(es) on "
                        f"detection, then {'killed' if killed else 'kill failed'}")
            if self.evidence:
                self.evidence.record("response.contain", pid=pid, **result)
        quarantined = None
        if killed and self.cfg.get("quarantine", True) and proc:
            quarantined = self._quarantine(incident_id, proc)
        return killed, quarantined, note

    def _merge(self, incident_id: str, pid, reasons, score, now) -> str:
        """Fold a later trigger into the open incident."""
        info = self.journal.load_incident(incident_id)
        merged_reasons = list(info.get("reasons", []))
        for r in reasons:
            if r not in merged_reasons:
                merged_reasons.append(r)
        updates = {"reasons": merged_reasons[:200],
                   "score": max(float(info.get("score", 0)), float(score)),
                   "last_trigger_at": now}
        acted = False
        handled = list(info.get("pids_handled", []))
        proc = None
        if pid and pid not in handled:
            proc = self._describe(pid)
            killed, quarantined, note = self._act(incident_id, pid, proc)
            handled.append(pid)
            updates["pids_handled"] = handled
            if not info.get("pid"):
                updates["pid"] = pid
                updates["process"] = proc
            updates["killed"] = bool(info.get("killed")) or killed
            if quarantined:
                updates["quarantined"] = quarantined
            if note:
                updates["note"] = note
            acted = True
        self.journal.update_incident(incident_id, updates)
        if acted:
            full = self.journal.load_incident(incident_id)
            self._write_human_log(
                incident_id, full.get("pid"), full.get("process"),
                full["reasons"], full["score"], full.get("killed", False),
                full.get("quarantined"), full.get("note"))
            self._alert(incident_id, pid, proc, reasons,
                        updates["killed"], updates.get("note"), update=True)
        return incident_id

    # -- process handling ----------------------------------------------------
    @staticmethod
    def _describe(pid: int) -> dict | None:
        if psutil is None:
            return None
        try:
            p = psutil.Process(pid)
            with p.oneshot():
                return {
                    "pid": pid,
                    "name": p.name(),
                    "exe": p.exe(),
                    "cmdline": p.cmdline(),
                    "username": p.username(),
                    "create_time": p.create_time(),
                }
        except (psutil.NoSuchProcess, psutil.AccessDenied,
                psutil.ZombieProcess):
            return {"pid": pid, "name": "<exited/unreadable>"}

    def _kill_tree(self, pid: int) -> bool:
        """Terminate PID and its children (SIGTERM, then SIGKILL)."""
        if psutil is None:
            return False
        if pid <= 1 or pid == os.getpid():
            return False
        try:
            root = psutil.Process(pid)
            if looks_like_aegis_agent(" ".join(root.cmdline())):
                return False  # never kill the agent itself
            if self.plat.is_protected_process(root.name(), pid):
                return False
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return True  # already gone counts as neutralized
        try:
            targets = root.children(recursive=True) + [root]
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return True
        targets = [t for t in targets if not self._is_protected(t)]
        for proc in targets:
            try:
                proc.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        _, alive = psutil.wait_procs(targets, timeout=3)
        for proc in alive:
            try:
                proc.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        _, alive = psutil.wait_procs(alive, timeout=3)
        return len(alive) == 0

    def _is_protected(self, proc) -> bool:
        try:
            return self.plat.is_protected_process(proc.name(), proc.pid)
        except Exception:
            return False

    def _quarantine_source(self, proc: dict) -> str | None:
        """What to preserve as evidence: the binary — or, when the process
        is just an interpreter (python, powershell, node...), the SCRIPT it
        ran. Copying the interpreter itself would be useless."""
        exe = proc.get("exe")
        if exe and not self.plat.is_interpreter(exe):
            return exe
        for arg in (proc.get("cmdline") or [])[1:]:
            # strip surrounding quotes then skip switches/flags
            stripped = arg.strip('"').strip("'")
            if stripped.startswith("-"):
                continue
            # Windows /switch style: /nologo, /quiet — short, no ext, no path sep.
            # A POSIX abs path also starts with "/" but has separators inside.
            if (stripped.startswith("/") and ":" not in stripped
                    and os.path.sep not in stripped[1:]
                    and "/" not in stripped[1:]
                    and not os.path.splitext(stripped)[1]):
                continue
            has_ext = bool(os.path.splitext(stripped)[1])
            has_sep = os.sep in stripped or "/" in stripped or chr(92) in stripped
            if not (has_ext or has_sep):
                continue
            if chr(92) in stripped:        # Windows-style path on any host
                return stripped
            if os.path.isfile(stripped):
                return os.path.abspath(stripped)
        return None

    def _quarantine(self, incident_id: str, proc: dict) -> str | None:
        src = self._quarantine_source(proc)
        if not src:
            return None
        try:
            dest = self.quarantine_dir / f"{incident_id}_{os.path.basename(src)}"
            shutil.copy2(src, dest)
            # defang: strip execute bits so it cannot be run by accident
            try:
                os.chmod(dest, 0o600)
            except OSError:
                pass
            return str(dest)
        except OSError:
            return None

    # -- reporting -------------------------------------------------------------
    def _write_human_log(self, incident_id: str, pid, proc, reasons,
                         score, killed, quarantined, note=None) -> None:
        lines = [
            f"AEGIS INCIDENT {incident_id}",
            f"detected: {datetime.now(timezone.utc).isoformat()}",
            f"score: {score}",
            f"pid: {pid}",
        ]
        if proc:
            lines.append(f"process: {proc.get('name')} ({proc.get('exe')})")
            lines.append(f"cmdline: {' '.join(proc.get('cmdline') or [])}")
        lines.append("reasons:")
        lines += [f"  - {r}" for r in reasons]
        lines.append(f"process tree killed: {killed}")
        lines.append(f"binary quarantined: {quarantined}")
        if note:
            lines.append(f"note: {note}")
        lines.append(
            f"rollback: run `aegis rollback --since {incident_id}` "
            "to restore protected files to pre-attack state")
        (self.state_dir / "incidents" / incident_id / "INCIDENT.log") \
            .write_text("\n".join(lines) + "\n", encoding="utf-8")

    def _alert(self, incident_id: str, pid, proc, reasons, killed,
               note=None, update: bool = False) -> None:
        name = (proc or {}).get("name") or (f"pid {pid}" if pid
                                            else "unattributed")
        banner = (
            "\n" + "=" * 70 + "\n"
            f"  !!! AEGIS RANSOMWARE ALERT{' (UPDATE)' if update else ''} !!!\n"
            f"  incident: {incident_id}\n"
            f"  process:  {name}\n"
            f"  killed:   {killed}\n"
            f"  signal:   {reasons[0] if reasons else 'n/a'}\n"
            + (f"  note:     {note}\n" if note else "")
            +
            f"  rollback: aegis rollback --since {incident_id}\n"
            + "=" * 70 + "\n"
        )
        print(banner, flush=True)
        try:
            with open(self.state_dir / "alerts.log", "a",
                      encoding="utf-8") as fh:
                fh.write(banner + "\n")
        except OSError:
            pass
        # Best-effort desktop notification (per-OS adapter); never fatal.
        self.plat.notify(
            "Aegis ransomware alert",
            f"Incident {incident_id}: {name} "
            f"{'killed' if killed else 'NOT killed'}")
