"""Behavioral detection engine and (best-effort) process attribution.

Signals scored per process over a sliding window:
  * mass renames with extension changes (foo.txt -> foo.txt.locked)
  * high-entropy writes (Shannon entropy — ciphertext looks random)
  * ransom-note filenames appearing (HOW_TO_RECOVER.txt, ...)
  * canary tripwires (instant trigger, near-zero false positives)

Phase-1 attribution honesty note: watchdog tells us *what* changed, not
*which process* changed it. ProcessAttributor therefore works heuristically:
first it looks for a live process with the touched file open, then falls back
to the process with the largest recent write volume. True file->process
telemetry needs the Phase-2 kernel sensors (eBPF / EndpointSecurity /
minifilter) and is explicitly out of scope here.
"""
from __future__ import annotations

import math
import os
import re
import threading
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from .events import Event, EventKind, Decision
from .intel import note_patterns, is_ransom_extension
from .behavior import SpreadTracker
from .attribution import RecentWriters, newest_suspect

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None

from .platforms import get_platform


# ---------------------------------------------------------------------------
# primitives
# ---------------------------------------------------------------------------

def shannon_entropy(data: bytes) -> float:
    """Shannon entropy in bits/byte. Plain text is ~4-5; AES/Fernet output ~8."""
    if not data:
        return 0.0
    counts = Counter(data)
    n = len(data)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


@dataclass
class FileEvent:
    kind: str                    # "modified" | "created" | "moved" | "deleted"
    src: str
    dest: str | None = None      # set for "moved"
    entropy: float | None = None  # sampled write-buffer entropy
    size: int | None = None       # sampled bytes
    canary: bool = False          # event touched a canary tripwire
    known_pid: int | None = None  # kernel sensor gives us the exact writer
    ts: float = field(default_factory=time.time)


# ---------------------------------------------------------------------------
# agent self-identification (never nominate the agent itself as the attacker)
# ---------------------------------------------------------------------------

_AGENT_BASENAMES = {"aegis"}
_AGENT_CMDLINE_TOKENS = ("aegis.cli", "-m aegis")


def looks_like_aegis_agent(cmdline: str) -> bool:
    """True if this command line belongs to the Aegis agent/daemon itself.

    Matches the installed `aegis` entry point or `python -m aegis`, not merely
    any path that happens to contain the substring "aegis".
    """
    cmd = (cmdline or "").lower()
    if any(tok in cmd for tok in _AGENT_CMDLINE_TOKENS):
        return True
    parts = cmd.split()
    if not parts:
        return False
    # "aegis", "aegis.exe" (Windows entry-point shim), "aegis-script.py"
    first = parts[0].strip('"\'').replace("\\", "/")  # Windows-style paths
    base = os.path.splitext(first.rsplit("/", 1)[-1])[0]
    return base in _AGENT_BASENAMES


# ---------------------------------------------------------------------------
# attribution
# ---------------------------------------------------------------------------

class ProcessAttributor:
    """Best-effort user-space attribution (see module docstring)."""

    # Never nominate the agent itself (or a test harness) as the attacker.
    # NOTE: matching is deliberately specific — see looks_like_aegis_agent.
    # A process that merely has "aegis" somewhere in its path is NOT excluded.
    _EXCLUDED_CMDLINE = ("pytest",)

    def __init__(self, config: dict):
        c = config.get("attribution", {}) or {}
        self._interval = float(c.get("io_sample_interval_s", 1.0))
        self._window = float(c.get("io_window_s", 8.0))
        self._min_write = int(c.get("min_write_bytes", 65536))
        self._ttl = float(c.get("proc_cache_ttl_s", 2.0))
        self._self_pid = os.getpid()
        self._plat = get_platform()
        self._fallback_enabled = bool(c.get("top_writer_fallback", True))
        self._samples: list[tuple[float, dict[int, int]]] = []
        self._proc_cache: list = []
        self._proc_cache_ts = 0.0
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    # -- background I/O sampling ------------------------------------------
    def start(self) -> None:
        if self._thread is not None:
            return
        self._stop.clear()
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="aegis-attributor")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None

    def _loop(self) -> None:
        while not self._stop.wait(self._interval):
            try:
                self._sample()
            except Exception:
                pass  # never let the sampler kill the agent

    def _sample(self) -> None:
        if psutil is None:
            return
        now = time.time()
        snap: dict[int, int] = {}
        if not self._plat.supports_io_counters:
            return  # macOS: psutil has no io_counters(); nothing to sample
        for proc in self._iter_procs():
            try:
                snap[proc.pid] = proc.io_counters().write_bytes
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess, AttributeError, NotImplementedError):
                continue
        self._samples.append((now, snap))
        cutoff = now - self._window - self._interval
        self._samples = [(t, s) for t, s in self._samples if t >= cutoff]

    def _iter_procs(self) -> list:
        now = time.time()
        if not self._proc_cache or now - self._proc_cache_ts > self._ttl:
            if psutil is None:
                return []
            try:
                self._proc_cache = [
                    p for p in psutil.process_iter(["pid", "cmdline"])
                    if p.pid != self._self_pid
                ]
            except Exception:
                self._proc_cache = []
            self._proc_cache_ts = now
        return self._proc_cache

    @staticmethod
    def _cmdline(proc) -> str:
        try:
            return " ".join(proc.info.get("cmdline") or []).lower()
        except Exception:
            return ""

    def _excluded(self, proc) -> bool:
        cmd = self._cmdline(proc)
        if (any(k in cmd for k in self._EXCLUDED_CMDLINE)
                or looks_like_aegis_agent(cmd)):
            return True
        try:
            name = proc.name() if hasattr(proc, "name") else None
        except Exception:
            name = None
        return self._plat.is_protected_process(name, proc.pid)

    # -- attribution -------------------------------------------------------
    def attribute(self, event: FileEvent) -> int | None:
        """PID of the process currently holding the touched file open."""
        if psutil is None:
            return None
        target = os.path.realpath(event.dest or event.src)
        for proc in self._iter_procs():
            if self._excluded(proc):
                continue
            try:
                for handle in proc.open_files():
                    try:
                        if os.path.realpath(handle.path) == target:
                            return proc.pid
                    except OSError:
                        continue
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess):
                continue
        return None

    def top_writer(self) -> int | None:
        """PID with the largest write volume in the sampling window."""
        if not self._plat.supports_io_counters or len(self._samples) < 2:
            return None
        first_t, first = self._samples[0]
        last_t, last = self._samples[-1]
        if last_t - first_t < 1.0:
            return None
        best_pid, best_delta = None, 0
        for proc in self._iter_procs():
            if self._excluded(proc):
                continue
            delta = last.get(proc.pid, 0) - first.get(proc.pid, 0)
            if delta > best_delta:
                best_delta, best_pid = delta, proc.pid
        if best_pid is not None and best_delta >= self._min_write:
            return best_pid
        return None

    def _valid_target(self, pid: int | None) -> bool:
        if not pid or pid <= 1 or pid == self._self_pid:
            return False
        if psutil is None:
            return False
        try:
            proc = psutil.Process(pid)
            return (not self._excluded(proc) and proc.is_running())
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return False

    def resolve(self, preferred: int | None = None,
                path_hint: str | None = None,
                allow_fallback: bool = True) -> int | None:
        """Pick the process to act against.

        A positively attributed PID always wins. The "top writer" guess is a
        fallback ONLY for behavioural (score-based) triggers, and only when
        enabled: for a canary trip the touching process may be a user's file
        manager, so a guess there could kill an innocent program.
        """
        if self._valid_target(preferred):
            return preferred
        if not (allow_fallback and self._fallback_enabled):
            return None
        try:
            return self.top_writer()
        except Exception:
            return None


# ---------------------------------------------------------------------------
# engine
# ---------------------------------------------------------------------------

class DetectionEngine:
    """Scores FileEvents per process; fires on_trigger on threshold cross."""

    def __init__(self, config: dict, attributor: ProcessAttributor | None = None):
        self._d = config["detection"]
        self.attributor = attributor
        self.on_trigger = None  # fn(pid, reasons, score, context)
        self._buckets: dict[int | None, list] = defaultdict(list)
        self._cooldown_until: dict[int | None, float] = defaultdict(float)
        self._canary_cooldown_until: float = 0.0  # one incident per attack
        self._lock = threading.Lock()
        self.trigger_log: list[dict] = []  # every trigger, for tests/status
        patterns = list(self._d["ransom_note_patterns"]) + note_patterns()
        self._note_res = [re.compile(p, re.IGNORECASE)
                          for p in dict.fromkeys(patterns)]
        self._audit_mode = bool(config.get("response", {}).get("dry_run"))
        self._audit_log: list[dict] = []
        self._spread = SpreadTracker(config)
        self._recent = RecentWriters()

    # -- feature extraction ------------------------------------------------
    @staticmethod
    def _ext_changed(src: str, dest: str) -> bool:
        return (os.path.splitext(src)[1].lower()
                != os.path.splitext(dest)[1].lower())

    def _is_ransom_note(self, path: str) -> bool:
        base = os.path.basename(path)
        return any(rx.search(base) for rx in self._note_res)

    def _attribute(self, event: FileEvent) -> int | None:
        if getattr(event, "known_pid", None):
            return event.known_pid  # exact writer from the kernel sensor
        if self.attributor is None:
            return None
        try:
            return self.attributor.attribute(event)
        except Exception:
            return None

    def _attribute_canary(self, event: FileEvent) -> int | None:
        """Best-effort attribution when open-file lookup misses (fast attacker
        that already closed the file). Language-agnostic — looks only at who
        has been writing, not at what they are."""
        # 1. recent writers near this path
        for pid in self._recent.candidates(event.src, event.ts):
            if self.attributor and self.attributor._valid_target(pid):
                return pid
        # 2. write-volume top writer (if the OS exposes io counters)
        if self.attributor:
            try:
                tw = self.attributor.top_writer()
                if tw and self.attributor._valid_target(tw):
                    return tw
            except Exception:
                pass
        # 3. newest non-system process (a just-spawned encryptor)
        try:
            exclude = {os.getpid()}
            safe = (self.attributor._excluded if self.attributor
                    else (lambda p: False))
            cand = newest_suspect(exclude, safe)
            if cand and (not self.attributor
                         or self.attributor._valid_target(cand)):
                return cand
        except Exception:
            pass
        return None

    # -- main entry ---------------------------------------------------------
    def handle_event(self, event: FileEvent) -> None:
        # Canary tripwires fire immediately — legitimate software never
        # touches decoy files, so this is the highest-confidence signal.
        # One incident per attack: further trips are suppressed by cooldown.
        if event.canary:
            with self._lock:
                if event.ts < self._canary_cooldown_until:
                    return
                self._canary_cooldown_until = event.ts + 300
            # Language-agnostic attribution: kernel pid > open-file lookup >
            # recent-writer cache > newest-suspect. A canary trip is high
            # confidence, so we DO act on the best guess (fallback allowed) —
            # the attacker may be bash, Go, Rust, a compiled binary, anything.
            pid = self._attribute(event)
            if not pid:
                pid = self._attribute_canary(event)
            self._fire(pid,
                       [f"CANARY TRIPWIRE touched: {event.src}"],
                       10 ** 6, event, allow_fallback=True)
            return

        d = self._d
        pid = self._attribute(event)
        if pid and event.kind in ("modified", "created", "moved"):
            self._recent.record(event.dest or event.src, pid, event.ts)
        points, reasons = self._score_event(event, pid)
        if points <= 0:
            return

        fire = None
        with self._lock:
            bucket = self._buckets[pid]
            bucket.append((event.ts, points, "; ".join(reasons)))
            cutoff = event.ts - d["window_s"]
            bucket = [e for e in bucket if e[0] >= cutoff]
            if bucket:
                self._buckets[pid] = bucket
            else:
                self._buckets.pop(pid, None)  # don't leak empty buckets
            # Opportunistically prune stale cooldown entries.
            if len(self._cooldown_until) > 1000:
                stale = [k for k, v in self._cooldown_until.items()
                         if v < event.ts - 3600]
                for k in stale:
                    del self._cooldown_until[k]
            total = sum(p for _, p, _ in bucket)
            if (total >= d["trigger_score"]
                    and event.ts >= self._cooldown_until[pid]):
                self._cooldown_until[pid] = event.ts + 300  # 5-min cooldown
                why = [r for _, _, r in bucket]
                self._buckets.pop(pid, None)
                fire = (pid, why, total)
        if fire:
            self._fire(*fire, event)

    # -- blocking decision (kernel sensor) ---------------------------------
    def evaluate(self, event: "Event") -> "Decision":
        """Map a contract Event to an allow/deny Decision for a blocking sensor.

        Reuses the same per-process scoring as detect-only mode. Returns DENY
        only on a high-confidence signal (canary, or a score past the block
        threshold); otherwise ALLOW (fail-open — never freeze legit work).
        In dry-run/audit mode it records what it *would* do but returns ALLOW.
        """
        fe = _to_file_event(event)
        block_at = self._d.get("block_score", self._d["trigger_score"])
        deny = False
        reason = None
        # Score ONCE through the normal pipeline (incident/kill/rollback),
        # then read the resulting window total for the decision. Scoring here
        # as well would count every event twice and halve the threshold.
        self.handle_event(fe)
        if fe.canary:
            deny, reason = True, f"CANARY TRIPWIRE touched: {fe.src}"
        elif event.pid is not None:
            pts, why = self._score_event(fe)
            if pts > 0:
                with self._lock:
                    total = sum(p for _, p, _ in self._buckets.get(
                        event.pid, []))
                if total >= block_at:
                    deny, reason = True, "; ".join(why)
        if deny and reason:
            if self._audit_mode:
                self._audit_log.append({"ts": fe.ts, "pid": event.pid,
                                        "path": event.path, "reason": reason})
                return Decision.AUDIT
            return Decision.DENY
        return Decision.ALLOW

    def _score_event(self, event: FileEvent, pid=None):
        """Return (points, reasons) for one event — no state, no firing."""
        d = self._d
        points, reasons = 0, []
        base = os.path.basename(event.dest or event.src)
        # content-independent spread signal (beats polymorphism / low-entropy)
        if event.kind in ("modified", "created", "moved"):
            sp, why = self._spread.record(pid, event.dest or event.src, event.ts)
            if sp:
                points += sp
                reasons.append(why)
        if (event.kind == "moved" and event.dest
                and self._ext_changed(event.src, event.dest)):
            if is_ransom_extension(event.dest):
                points += d["weights"].get("known_ransom_ext", 30)
                reasons.append(f"renamed to KNOWN ransomware extension: {base}")
            else:
                points += d["weights"]["rename_ext_change"]
                reasons.append(
                    f"extension change: {os.path.basename(event.src)} -> {base}")
        if event.kind == "created" and is_ransom_extension(event.src):
            points += d["weights"].get("known_ransom_ext", 30)
            reasons.append(f"created KNOWN ransomware-extension file: {base}")
        if (event.kind in ("modified", "created")
                and event.entropy is not None
                and event.entropy >= d["entropy_threshold"]
                and (event.size or 0) >= d["entropy_min_bytes"]):
            points += d["weights"]["high_entropy_write"]
            reasons.append(
                f"high-entropy write ({event.entropy:.1f} bits/byte): {base}")
        if event.kind == "created" and self._is_ransom_note(event.src):
            points += d["weights"]["ransom_note"]
            reasons.append(f"ransom-note filename: {base}")
        return points, reasons

    def _accumulate(self, pid, ts, points, reason) -> float:
        """Add points to a pid's window and return the current total."""
        with self._lock:
            bucket = self._buckets[pid]
            bucket.append((ts, points, reason))
            cutoff = ts - self._d["window_s"]
            self._buckets[pid] = [e for e in bucket if e[0] >= cutoff]
            return sum(p for _, p, _ in self._buckets[pid])

    def _fire(self, pid: int | None, reasons: list[str],
              score: float, event: FileEvent,
              allow_fallback: bool = True) -> None:
        target = pid
        if self.attributor is not None:
            try:
                target = self.attributor.resolve(
                    preferred=pid, path_hint=event.dest or event.src,
                    allow_fallback=allow_fallback)
            except Exception:
                target = pid
        record = {"ts": event.ts, "pid": pid, "target": target,
                  "score": score, "reasons": reasons}
        self.trigger_log.append(record)
        if len(self.trigger_log) > 1000:  # bounded memory on long runs
            del self.trigger_log[:-1000]
        # "guess" = the PID came from the top-writer fallback, not from the
        # kernel or an open-file match. Guesses are reported, never contained.
        attribution = ("exact" if target is not None and target == pid
                       else "guess" if target is not None else "none")
        record["attribution"] = attribution
        if self.on_trigger is not None:
            try:
                self.on_trigger(target, reasons, score,
                                {"event": event, "attributed_pid": pid,
                                 "attribution": attribution})
            except Exception as exc:  # never let response kill the watcher
                print(f"[aegis] on_trigger raised: {exc!r}", flush=True)


def _to_file_event(event: "Event") -> "FileEvent":
    """Adapt a Phase-A contract Event to the internal FileEvent scorer input."""
    kmap = {
        EventKind.FILE_MODIFY: "modified",
        EventKind.FILE_CREATE: "created",
        EventKind.FILE_RENAME: "moved",
        EventKind.FILE_DELETE: "deleted",
        EventKind.FILE_OPEN: "modified",
        EventKind.CANARY_TOUCH: "modified",
    }
    return FileEvent(
        kind=kmap.get(event.kind, "modified"),
        src=event.path or "", dest=event.dest,
        entropy=event.entropy, size=event.size,
        canary=event.canary, known_pid=event.pid, ts=event.ts)
