"""Aegis — cross-platform behavioral anti-ransomware agent.

Phase 1 (user-space MVP): filesystem watching via watchdog, behavioral
heuristics, canary tripwires, copy-on-first-write journaling with rollback,
and automated incident response. Kernel sensors (eBPF / EndpointSecurity /
minifilter) and the exfiltration guard arrive in later phases.
"""

__version__ = "0.4.3"
__all__ = ["__version__"]
