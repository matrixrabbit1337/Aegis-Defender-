"""Phase A — the frozen cross-platform event contract.

Every sensor on every OS emits these and nothing else; the decision engine and
the evidence log consume only these. This is the "normalized event stream" and
"reason code + retained evidence" requirement from the plan: one schema that
keeps the policy language consistent without pretending the kernels are alike.

Nothing here imports an OS-specific module, so the contract loads on any host.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field, asdict
from enum import Enum


class EventKind(str, Enum):
    # file
    FILE_OPEN = "file.open"
    FILE_MODIFY = "file.modify"
    FILE_CREATE = "file.create"
    FILE_RENAME = "file.rename"
    FILE_DELETE = "file.delete"
    # process
    PROC_START = "proc.start"
    PROC_EXIT = "proc.exit"
    # network (egress guard)
    NET_CONNECT = "net.connect"
    NET_UPLOAD = "net.upload"
    # tripwires / integrity
    CANARY_TOUCH = "canary.touch"
    STORE_ACCESS = "store.access"        # someone touched the protected journal
    PERSISTENCE = "persistence.change"   # cron/systemd/run-key/launchd
    # decisions & recovery (for the evidence timeline)
    POLICY = "policy.verdict"
    RECOVERY = "recovery.action"


class Decision(str, Enum):
    ALLOW = "allow"
    AUDIT = "audit"        # dry-run: would have acted
    THROTTLE = "throttle"
    SUSPEND = "suspend"
    CONTAIN = "contain"    # kill tree + block + isolate
    DENY = "deny"          # pre-write block (kernel)


@dataclass
class Event:
    kind: EventKind
    path: str | None = None
    dest: str | None = None            # rename target / upload destination
    pid: int | None = None
    ppid: int | None = None
    exe: str | None = None
    # features filled in by sensors/engine
    entropy: float | None = None
    size: int | None = None
    bytes_out: int | None = None
    canary: bool = False
    # provenance
    source: str = "userspace"          # "fanotify" | "ebpf" | "watchdog" | ...
    blockable: bool = False            # True only for a kernel permission event
    ts: float = field(default_factory=time.time)
    extra: dict = field(default_factory=dict)

    def target(self) -> str | None:
        return self.dest or self.path

    def to_json(self) -> dict:
        d = asdict(self)
        d["kind"] = self.kind.value
        return d
