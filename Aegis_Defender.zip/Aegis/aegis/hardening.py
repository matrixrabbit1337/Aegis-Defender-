"""Self-hardening layer — protects Aegis itself from being tampered with.

Ransomware that knows an anti-ransomware tool is running will try to:
  1. Modify or delete the agent's own code
  2. Kill the agent process
  3. Corrupt or delete the journal/state so rollback fails
  4. Read the state to learn what's protected

This module counters each:
  1. CODE INTEGRITY — on startup, hash every .py file in the package and store
     the manifest. On each detection cycle, re-verify. If tampered: alert,
     log, and refuse to trust the detection results (fail-secure).
  2. PROCESS GUARD — a watchdog thread that restarts the agent if killed
     (only effective when launched as a service; the GUI/CLI parent respawns).
  3. STATE ENCRYPTION — the journal manifest, incident reports, canary
     records, and evidence logs are AES-256 encrypted at rest using a key
     derived from a machine-specific seed + a random salt. An attacker who
     reads the state dir learns nothing about what's protected.
  4. STATE DIR PERMISSIONS — locked to the current user (chmod 700 / icacls).

All of this is defence-in-depth: a kernel-level attacker can bypass anything
in user space. But it raises the bar significantly against commodity ransomware
that just tries to `taskkill /f /im aegis.exe` or `rm -rf ~/.aegis`.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from pathlib import Path

# AES via cryptography (pip) if available, else Fernet (stdlib-adjacent)
_HAS_CRYPTO = False
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _HAS_CRYPTO = True
except ImportError:
    pass

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    _HAS_FERNET = True
except ImportError:
    _HAS_FERNET = False


# ── machine-specific key derivation ─────────────────────────────────────────

def _machine_seed() -> bytes:
    """Collect machine-specific entropy that stays stable across reboots but
    differs between machines. Not a secret — just a binding."""
    parts = []
    # hostname
    import socket
    parts.append(socket.gethostname().encode())
    # machine-id (Linux/macOS)
    for path in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            parts.append(open(path, "rb").read().strip())
            break
        except OSError:
            pass
    # Windows: use SID of current user
    if os.name == "nt":
        try:
            import ctypes
            buf = ctypes.create_unicode_buffer(256)
            sz = ctypes.c_ulong(256)
            ctypes.windll.advapi32.GetUserNameW(buf, ctypes.byref(sz))
            parts.append(buf.value.encode())
        except Exception:
            pass
    # MAC address (fallback entropy)
    try:
        import uuid as _uuid
        parts.append(str(_uuid.getnode()).encode())
    except Exception:
        pass
    return b"|".join(parts)


def derive_key(salt: bytes, password: bytes | None = None) -> bytes:
    """Derive a 32-byte AES key from machine seed + optional password."""
    seed = (password or b"") + _machine_seed()
    if _HAS_FERNET:
        kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32,
                          salt=salt, iterations=480_000)
        return kdf.derive(seed)
    else:
        # fallback: PBKDF2 via hashlib (always available)
        return hashlib.pbkdf2_hmac("sha256", seed, salt, 480_000, dklen=32)


# ── state encryption ────────────────────────────────────────────────────────

class StateEncryptor:
    """Encrypts/decrypts state files at rest (journal manifests, incidents,
    canary records, evidence). Transparent to callers."""

    def __init__(self, state_dir: str):
        self.state_dir = Path(state_dir)
        self._key_file = self.state_dir / ".aegis-key-salt"
        self._salt, self._key = self._load_or_create_key()

    def _load_or_create_key(self) -> tuple[bytes, bytes]:
        if self._key_file.exists():
            salt = self._key_file.read_bytes()[:32]
        else:
            salt = os.urandom(32)
            self.state_dir.mkdir(parents=True, exist_ok=True)
            self._key_file.write_bytes(salt)
            try:
                os.chmod(self._key_file, 0o600)
            except OSError:
                pass
        return salt, derive_key(salt)

    def encrypt(self, data: bytes) -> bytes:
        """Encrypt data. Returns nonce + ciphertext."""
        if _HAS_CRYPTO:
            nonce = os.urandom(12)
            ct = AESGCM(self._key).encrypt(nonce, data, None)
            return nonce + ct
        elif _HAS_FERNET:
            import base64
            fkey = base64.urlsafe_b64encode(self._key)
            return Fernet(fkey).encrypt(data)
        else:
            # minimal XOR obfuscation as last resort (NOT cryptographic!)
            return self._xor(data)

    def decrypt(self, data: bytes) -> bytes:
        if _HAS_CRYPTO:
            nonce, ct = data[:12], data[12:]
            return AESGCM(self._key).decrypt(nonce, ct, None)
        elif _HAS_FERNET:
            import base64
            fkey = base64.urlsafe_b64encode(self._key)
            return Fernet(fkey).decrypt(data)
        else:
            return self._xor(data)

    def _xor(self, data: bytes) -> bytes:
        key_stream = (self._key * ((len(data) // 32) + 1))[:len(data)]
        return bytes(a ^ b for a, b in zip(data, key_stream))

    def encrypt_file(self, path: str) -> None:
        """Encrypt a file in-place."""
        p = Path(path)
        if not p.exists():
            return
        plain = p.read_bytes()
        p.write_bytes(b"AEGIS-ENC-V1\x00" + self.encrypt(plain))

    def decrypt_file(self, path: str) -> bytes | None:
        """Read and decrypt a file. Returns None if not encrypted or missing."""
        p = Path(path)
        if not p.exists():
            return None
        raw = p.read_bytes()
        if raw.startswith(b"AEGIS-ENC-V1\x00"):
            return self.decrypt(raw[13:])
        return raw  # not encrypted (legacy file)

    def encrypt_json(self, path: str, obj: dict) -> None:
        """Write a dict as encrypted JSON."""
        plain = json.dumps(obj, indent=2, default=str).encode("utf-8")
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(".tmp")
        tmp.write_bytes(b"AEGIS-ENC-V1\x00" + self.encrypt(plain))
        os.replace(tmp, p)

    def decrypt_json(self, path: str) -> dict | None:
        """Read encrypted JSON. Falls back to plain JSON for legacy files."""
        data = self.decrypt_file(path)
        if data is None:
            return None
        return json.loads(data.decode("utf-8"))


# ── code integrity ──────────────────────────────────────────────────────────

class IntegrityVerifier:
    """Hash every .py in the aegis package at startup; re-verify on demand."""

    def __init__(self):
        self._baseline: dict[str, str] = {}
        self._pkg_dir = str(Path(__file__).parent)
        self._take_baseline()

    def _take_baseline(self):
        for root, _, files in os.walk(self._pkg_dir):
            for f in files:
                if f.endswith(".py"):
                    path = os.path.join(root, f)
                    try:
                        self._baseline[path] = self._hash(path)
                    except OSError:
                        pass

    @staticmethod
    def _hash(path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()

    def verify(self) -> list[str]:
        """Returns list of tampered files (empty = clean)."""
        tampered = []
        for path, expected in self._baseline.items():
            try:
                if self._hash(path) != expected:
                    tampered.append(path)
            except OSError:
                tampered.append(path)  # deleted = tampered
        return tampered


# ── process guard ───────────────────────────────────────────────────────────

class ProcessGuard:
    """Watchdog that detects if the agent is being killed or suspended."""

    def __init__(self, on_tamper=None):
        self._on_tamper = on_tamper or (lambda msg: None)
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._heartbeat = time.time()

    def start(self):
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="aegis-procguard")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def beat(self):
        self._heartbeat = time.time()

    def _loop(self):
        import signal
        # Trap SIGTERM/SIGINT — log the attempt before dying
        def _handler(sig, frame):
            self._on_tamper(f"Aegis received signal {sig} — someone is "
                            "trying to kill the agent")
        try:
            signal.signal(signal.SIGTERM, _handler)
        except (OSError, ValueError):
            pass  # can't set handler in a thread on some OS; best effort

        while not self._stop.wait(2.0):
            # Check if our own process is being debugged (anti-debug)
            try:
                import psutil
                me = psutil.Process()
                parent = me.parent()
                if parent and parent.name().lower() in (
                        "gdb", "lldb", "strace", "ltrace", "x64dbg.exe",
                        "ollydbg.exe", "ida.exe", "ida64.exe", "windbg.exe"):
                    self._on_tamper(
                        f"Debugger detected: {parent.name()} (pid {parent.pid})")
            except Exception:
                pass
