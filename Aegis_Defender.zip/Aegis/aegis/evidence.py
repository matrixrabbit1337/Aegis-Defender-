"""Append-only evidence log — every automated action has a reason code and a
retained trail (Phase A exit gate). One JSONL file per run under the state dir;
the responder and sensors write to it so an incident can be reconstructed."""
from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


class EvidenceLog:
    def __init__(self, state_dir):
        self.dir = Path(state_dir) / "evidence"
        self.dir.mkdir(parents=True, exist_ok=True)
        self._path = self.dir / (datetime.now(timezone.utc)
                                 .strftime("run-%Y%m%d-%H%M%S.jsonl"))
        self._lock = threading.Lock()

    def record(self, reason_code: str, event=None, **fields):
        entry = {"ts": time.time(),
                 "iso": datetime.now(timezone.utc).isoformat(),
                 "reason_code": reason_code}
        if event is not None:
            entry["event"] = event.to_json() if hasattr(event, "to_json") \
                else event
        entry.update(fields)
        line = json.dumps(entry, default=str)
        with self._lock:
            try:
                with open(self._path, "a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
            except OSError:
                pass

    @property
    def path(self) -> str:
        return str(self._path)
