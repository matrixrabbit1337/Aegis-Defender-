"""Configuration for the Aegis agent.

Phase 1: a single YAML file with sensible defaults. All paths are expanded
(`~` and environment variables) when loaded. The agent only ever acts inside
the directories listed in ``protected_dirs`` — nothing else on the system is
touched.
"""
from __future__ import annotations

import copy
import os

try:
    import yaml
except ImportError:  # pragma: no cover - surfaced clearly at install time
    yaml = None


DEFAULT_CONFIG: dict = {
    # Directories the agent protects. THE AGENT ONLY EVER ACTS INSIDE THESE.
    "protected_dirs": [],
    # All agent state (journal, quarantine, incidents, canary records).
    # Default is per-OS (see aegis/platforms/*.py): ~/.aegis on Linux,
    # ~/Library/Application Support/Aegis on macOS, %LOCALAPPDATA%\\Aegis on
    # Windows.
    "state_dir": None,
    # Refuse home dir, system dirs and drive roots unless explicitly allowed.
    "allow_dangerous_dirs": True,
    "journal": {
        "max_file_mb": 100,    # files larger than this are not snapshotted
        "max_total_mb": 2048,  # oldest baselines are evicted past this cap
    },
    "detection": {
        "window_s": 120,       # sliding window for per-process scoring
        "trigger_score": 50,   # score at which incident response fires
        "weights": {
            "rename_ext_change": 5,   # renamed to a different extension
            "known_ransom_ext": 30,   # renamed to a KNOWN ransomware ext (.akira,.lockbit…)
            "high_entropy_write": 6,  # write buffer looks encrypted/random
            "ransom_note": 25,        # known ransom-note filename created
        },
        "entropy_threshold": 5.8,  # bits/byte: raw AES output ~8.0,
        # base64-wrapped ciphertext (Fernet) ~6.0, plaintext ~4-5
        "entropy_min_bytes": 512,  # ignore tiny writes for entropy scoring
        "ransom_note_patterns": [
            r"readme[_ \-]decrypt",
            r"how[_ \-]to[_ \-]recover",
            r"decrypt[_ \-]instruction",
            r"recover[_ \-]my[_ \-]files",
            r"how[_ \-]to[_ \-]decrypt",
            r"decrypt[_ \-]your[_ \-]files",
        ],
    },
    "attribution": {
        # Best-effort user-space process attribution (see heuristics.py).
        "io_sample_interval_s": 1.0,
        "io_window_s": 8.0,
        "min_write_bytes": 65536,  # top-writer fallback needs this much churn
        "proc_cache_ttl_s": 2.0,
        # Guess the attacker from write volume when no process can be tied
        # to the touched file. Never used for canary trips.
        "top_writer_fallback": True,
    },
    "response": {
        "kill_process": True,
        "quarantine": True,
        # Freeze (suspend) the attacker the instant it is detected, before
        # killing — stops damage immediately and is reversible. All OSes.
        "suspend_first": True,
        # Triggers within this many seconds of an open incident are merged
        # into it (one attack = one incident).
        "merge_window_s": 300,
    },
    "behavior": {          # content-independent spread detection (anti-polymorphic)
        "enabled": True,
        "window_s": 60,
        "distinct_file_threshold": 10,
        "distinct_dir_threshold": 3,
        "spread_points": 20,
    },
    # Processes never auto-killed (legitimate high-churn tools); still logged.
    # Reduces false positives from backup/sync/compression, per research.
    "trusted_processes": [
        "backupd", "timed", "rsync", "borg", "restic", "duplicati",
        "dropbox", "onedrive", "insync", "nextcloud", "megasync",
    ],
    "egress": {
        "enabled": True,
        "sample_interval_s": 2.0,
        "volume_threshold_mb": 20,
        "archive_fresh_s": 300,
        # Alert only by default: backup/sync tools look like exfiltration.
        "contain": False,
    },
    "recovery_guard": {    # T1490 recovery-inhibition process monitor
        "enabled": True,
        "poll_s": 0.5,
    },
    "integrity": {         # protected-store + persistence tripwires
        "enabled": True,
        "poll_s": 3.0,
    },
    "sensor": {            # auto: kernel (fanotify, Linux+root) else watchdog
        "mode": "auto",
        "answer_timeout_s": 2.0,
        "pre_modification_copy": True,
    },
    "canaries": {
        "filenames": [
            # Names chosen to sort FIRST in common filesystem walk orders
            # (leading !, 0, A) AND last (z, ~), so a tripwire is hit early no
            # matter which direction ransomware enumerates files.
            "!!!_READ_FIRST_aegis.txt",
            "0000_aegis_canary.pdf",
            "2024_tax_return.pdf",
            "AAA_important_do_not_delete.docx",
            "banking_details.xlsx",
            "family_photos_backup.zip",
            "insurance_claim_2024.pdf",
            "passwords_backup.xlsx",
            "private_keys.txt",
            "Q3_financials.docx",
            "w2_forms_backup.zip",
            "zzz_archive_2024.pdf",
            "~~~_aegis_canary_last.zip",
        ],
    },
}


def _expand(value):
    if isinstance(value, str):
        return os.path.expandvars(os.path.expanduser(value))
    if isinstance(value, list):
        return [_expand(v) for v in value]
    if isinstance(value, dict):
        return {k: _expand(v) for k, v in value.items()}
    return value


def deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge ``override`` over ``base`` (dicts merge, else replace)."""
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _finalize(cfg: dict) -> dict:
    """Fill per-OS defaults and validate. Raises RuntimeError on bad input."""
    from .platforms import get_platform
    cfg = _expand(cfg)
    if not cfg.get("state_dir"):
        cfg["state_dir"] = get_platform().default_state_dir()
    dirs = cfg.get("protected_dirs")
    if dirs is None:
        dirs = []
    if isinstance(dirs, str):
        dirs = [dirs]
    if not isinstance(dirs, list) or not all(isinstance(d, str) for d in dirs):
        raise RuntimeError("protected_dirs must be a list of directory paths")
    cfg["protected_dirs"] = dirs
    for key in ("max_file_mb", "max_total_mb"):
        try:
            if float(cfg["journal"][key]) <= 0:
                raise ValueError
        except (KeyError, TypeError, ValueError):
            raise RuntimeError(f"journal.{key} must be a positive number")
    return cfg


def default_config() -> dict:
    return _finalize(copy.deepcopy(DEFAULT_CONFIG))


def load_config(path: str | os.PathLike) -> dict:
    if yaml is None:
        raise RuntimeError("pyyaml is required — run: pip install pyyaml")
    path = os.path.expanduser(str(path))
    if not os.path.exists(path):
        raise FileNotFoundError(f"config not found: {path}")
    try:
        with open(path, "r", encoding="utf-8") as fh:
            user = yaml.safe_load(fh) or {}
    except yaml.YAMLError as exc:
        raise RuntimeError(f"invalid YAML in {path}: {exc}")
    if not isinstance(user, dict):
        raise RuntimeError(f"{path}: top level must be a YAML mapping")
    return _finalize(deep_merge(DEFAULT_CONFIG, user))


def write_default_config(path: str | os.PathLike) -> str:
    """Write a starter config if none exists; returns the path."""
    if yaml is None:
        raise RuntimeError("pyyaml is required — run: pip install pyyaml")
    path = os.path.expanduser(str(path))
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    if os.path.exists(path):
        return path
    with open(path, "w", encoding="utf-8") as fh:
        yaml.safe_dump(copy.deepcopy(DEFAULT_CONFIG), fh, sort_keys=False)
    return path
