"""Protected-store & persistence tripwires (Phase C/D deterministic signals).

Two high-signal, low-noise checks the plan calls for:

  * STORE_ACCESS — the journal/protected store is the attacker's target
    ("Recovery store becomes the target", a CRITICAL risk). We watch our own
    state dir for deletion/mutation by anything other than us and treat it as
    a critical signal.
  * PERSISTENCE — creation of autostart entries (cron, systemd user units,
    XDG autostart on Linux; Run keys / Startup on Windows; LaunchAgents on
    macOS). Not auto-contained, but recorded as evidence in the timeline.

Both are detect-only and cheap: a periodic poll, no kernel needed.
"""
from __future__ import annotations

import os
import threading

from .events import Event, EventKind
from .platforms import get_platform


def persistence_locations() -> list[str]:
    p = get_platform().name
    home = os.path.expanduser("~")
    if p == "windows":
        appdata = os.environ.get("APPDATA") or os.path.join(
            home, "AppData", "Roaming")
        return [os.path.join(appdata, "Microsoft", "Windows", "Start Menu",
                             "Programs", "Startup")]
    if p == "macos":
        return [os.path.join(home, "Library", "LaunchAgents")]
    return [os.path.join(home, ".config", "autostart"),
            os.path.join(home, ".config", "systemd", "user"),
            os.path.join(home, ".local", "share", "systemd", "user")]


class IntegrityMonitor:
    def __init__(self, config: dict, agent):
        c = config.get("integrity", {}) or {}
        self.enabled = bool(c.get("enabled", True))
        self.agent = agent
        self._interval = float(c.get("poll_s", 3.0))
        self._state_dir = os.path.realpath(agent.state_dir)
        self._persist = [d for d in persistence_locations()]
        self._known_persist: dict[str, set] = {}
        self._store_fingerprint: int | None = None
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self):
        if not self.enabled:
            return
        self._store_fingerprint = self._fingerprint_store()
        for d in self._persist:
            self._known_persist[d] = self._list(d)
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="aegis-integrity")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2)

    def _list(self, d) -> set:
        try:
            return set(os.listdir(d))
        except OSError:
            return set()

    def _fingerprint_store(self) -> int:
        """Cheap signature of the journal/incidents tree: count + newest mtime.
        A sudden drop in file count = someone deleting our recovery store."""
        n, newest = 0, 0.0
        for root, _, files in os.walk(os.path.join(self._state_dir,
                                                    "journal")):
            for f in files:
                n += 1
                try:
                    newest = max(newest, os.path.getmtime(
                        os.path.join(root, f)))
                except OSError:
                    pass
        return n

    def _loop(self):
        while not self._stop.wait(self._interval):
            try:
                self._check()
            except Exception:
                pass

    def _check(self):
        fp = self._fingerprint_store()
        if (self._store_fingerprint is not None
                and fp < self._store_fingerprint):
            self.agent.on_integrity(Event(
                kind=EventKind.STORE_ACCESS, path=self._state_dir,
                source="integrity",
                extra={"detail": "protected journal lost files "
                       f"({self._store_fingerprint} -> {fp})"}),
                critical=True)
        self._store_fingerprint = max(fp, self._store_fingerprint or 0)

        for d in self._persist:
            now = self._list(d)
            added = now - self._known_persist.get(d, set())
            for name in added:
                self.agent.on_integrity(Event(
                    kind=EventKind.PERSISTENCE, path=os.path.join(d, name),
                    source="integrity",
                    extra={"detail": f"new autostart entry in {d}"}),
                    critical=False)
            self._known_persist[d] = now
