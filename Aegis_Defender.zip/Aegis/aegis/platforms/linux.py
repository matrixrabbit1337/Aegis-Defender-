"""Linux adapter."""
from __future__ import annotations

import os
import shutil
import subprocess

from .base import PlatformAdapter


class LinuxAdapter(PlatformAdapter):
    name = "linux"
    case_insensitive = False
    supports_io_counters = True
    attribution_note = ("open-file lookup + per-process write volume "
                        "(run as root to see other users' processes)")
    never_kill_names = frozenset({
        "systemd", "init", "systemd-journald", "systemd-logind", "dbus-daemon",
        "dbus-broker", "sshd", "login", "agetty", "xorg", "xwayland",
        "gnome-shell", "gdm", "gdm3", "sddm", "lightdm", "kwin_x11",
        "kwin_wayland", "plasmashell", "mutter", "networkmanager", "udevd",
        "systemd-udevd", "cron", "crond", "polkitd", "pipewire", "pulseaudio",
        "wireplumber", "kthreadd",
    })

    def default_state_dir(self) -> str:
        return os.path.join(os.path.expanduser("~"), ".aegis")

    def dangerous_dirs(self) -> list[str]:
        return ["/bin", "/boot", "/dev", "/etc", "/lib", "/lib64", "/opt",
                "/proc", "/root", "/run", "/sbin", "/sys", "/usr", "/var",
                "/snap"]

    def notify(self, title: str, message: str) -> None:
        try:
            if shutil.which("notify-send"):
                subprocess.run(["notify-send", "-u", "critical", title,
                                message], timeout=5, check=False)
        except Exception:
            pass

    def is_admin(self) -> bool:
        return hasattr(os, "geteuid") and os.geteuid() == 0
