"""Windows adapter.

Notes:
  * Junctions are treated like symlinks (never followed/snapshotted).
  * psutil.open_files() can be slow/incomplete on Windows; attribution is
    best-effort and falls back to per-process write volume.
  * Paths longer than 260 chars may be skipped by the journal (reported as
    not-backed-up, never deleted).
"""
from __future__ import annotations

import os
import subprocess
import threading

from .base import PlatformAdapter


class WindowsAdapter(PlatformAdapter):
    name = "windows"
    case_insensitive = True
    supports_io_counters = True
    attribution_note = ("open-file lookup (best effort on Windows) + "
                        "per-process write volume")
    never_kill_names = frozenset({
        "system", "system idle process", "registry", "smss.exe", "csrss.exe",
        "wininit.exe", "winlogon.exe", "services.exe", "lsass.exe",
        "svchost.exe", "explorer.exe", "dwm.exe", "fontdrvhost.exe",
        "spoolsv.exe", "taskhostw.exe", "sihost.exe", "ctfmon.exe",
        "msmpeng.exe", "memory compression", "secure system",
    })

    def default_state_dir(self) -> str:
        base = os.environ.get("LOCALAPPDATA") or os.path.join(
            os.path.expanduser("~"), "AppData", "Local")
        return os.path.join(base, "Aegis")

    def user_folders(self) -> list[str]:
        home = os.path.expanduser("~")
        names = ("Documents", "Desktop", "Pictures")
        out = []
        for n in names:  # OneDrive "known folder move" relocates these
            for root in (os.path.join(home, "OneDrive"), home):
                p = os.path.join(root, n)
                if os.path.isdir(p) and p not in out:
                    out.append(p)
                    break
        return out

    def dangerous_dirs(self) -> list[str]:
        sysroot = os.environ.get("SystemRoot", r"C:\Windows")
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
        pd = os.environ.get("ProgramData", r"C:\ProgramData")
        return [sysroot, pf, pf86, pd]

    def is_link(self, path: str) -> bool:
        if os.path.islink(path):
            return True
        isjunction = getattr(os.path, "isjunction", None)
        if isjunction:
            return bool(isjunction(path))
        try:  # Python < 3.12: junction = reparse point that is not a symlink
            import stat
            attrs = os.lstat(path).st_file_attributes  # type: ignore[attr-defined]
            return bool(attrs & stat.FILE_ATTRIBUTE_REPARSE_POINT)  # type: ignore[attr-defined]
        except (AttributeError, OSError):
            return False

    def notify(self, title: str, message: str) -> None:
        def _box() -> None:
            try:
                import ctypes
                # MB_ICONERROR | MB_SYSTEMMODAL | MB_SETFOREGROUND
                ctypes.windll.user32.MessageBoxW(  # type: ignore[attr-defined]
                    0, message, title, 0x10 | 0x1000 | 0x10000)
            except Exception:
                pass
        threading.Thread(target=_box, daemon=True,
                         name="aegis-notify").start()

    def harden_state_dir(self, path: str) -> None:
        try:
            user = os.environ.get("USERNAME")
            if user:
                subprocess.run(
                    ["icacls", path, "/inheritance:r", "/grant:r",
                     f"{user}:(OI)(CI)F", "/grant:r", "SYSTEM:(OI)(CI)F"],
                    timeout=10, check=False,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def is_admin(self) -> bool:
        try:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())  # type: ignore[attr-defined]
        except Exception:
            return False
