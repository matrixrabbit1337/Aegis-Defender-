"""macOS adapter.

Known platform limits (documented honestly in the README):
  * psutil cannot read per-process I/O counters on macOS, so the
    "top writer" fallback is unavailable. Aegis only kills a process on
    macOS when it can positively attribute it (open-file lookup).
    Unattributed incidents still alert, report, and can be rolled back.
  * Protecting ~/Documents, ~/Desktop, ... may require granting the terminal
    "Full Disk Access" / Files-and-Folders permission (TCC).
"""
from __future__ import annotations

import os
import subprocess

from .base import PlatformAdapter


class MacOSAdapter(PlatformAdapter):
    name = "macos"
    case_insensitive = True  # default APFS/HFS+ volumes
    supports_io_counters = False
    attribution_note = ("open-file lookup + canary/recovery attribution (no "
                        "per-process I/O counters on macOS); attributed "
                        "incidents are suspended then killed — no certificate "
                        "needed for user-space containment")
    never_kill_names = frozenset({
        "launchd", "kernel_task", "windowserver", "loginwindow", "finder",
        "dock", "systemuiserver", "coreservicesd", "securityd", "opendirectoryd",
        "configd", "notifyd", "distnoted", "cfprefsd", "mds", "mds_stores",
        "diskarbitrationd", "powerd", "sshd", "logd", "syslogd", "tccd",
    })

    def default_state_dir(self) -> str:
        return os.path.join(os.path.expanduser("~"), "Library",
                            "Application Support", "Aegis")

    def dangerous_dirs(self) -> list[str]:
        return ["/System", "/Library", "/usr", "/bin", "/sbin", "/etc",
                "/var", "/private", "/Applications", "/Users"]

    def notify(self, title: str, message: str) -> None:
        try:
            # Values go in as argv, never interpolated into the script, so a
            # hostile process name cannot inject AppleScript.
            subprocess.run(
                ["osascript",
                 "-e", "on run argv",
                 "-e", "display notification (item 2 of argv) "
                       "with title (item 1 of argv)",
                 "-e", "end run", title, message],
                timeout=5, check=False,
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def is_admin(self) -> bool:
        return hasattr(os, "geteuid") and os.geteuid() == 0
