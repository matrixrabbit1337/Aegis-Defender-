"""Per-OS adapters. ``get_platform()`` returns the one for this machine.

    aegis/platforms/linux.py    LinuxAdapter
    aegis/platforms/macos.py    MacOSAdapter
    aegis/platforms/windows.py  WindowsAdapter
"""
from __future__ import annotations

import sys

from .base import PlatformAdapter
from .linux import LinuxAdapter
from .macos import MacOSAdapter
from .windows import WindowsAdapter

ADAPTERS = {"linux": LinuxAdapter, "macos": MacOSAdapter,
            "windows": WindowsAdapter}

_cached: PlatformAdapter | None = None


def detect_name(platform_str: str | None = None) -> str:
    p = (platform_str or sys.platform).lower()
    if p.startswith("win") or p.startswith("cygwin"):
        return "windows"
    if p == "darwin":
        return "macos"
    return "linux"  # linux, *bsd and anything POSIX-like


def get_platform(name: str | None = None) -> PlatformAdapter:
    global _cached
    if name:  # explicit request (tests) — never cached
        return ADAPTERS[name]()
    if _cached is None:
        _cached = ADAPTERS[detect_name()]()
    return _cached


__all__ = ["PlatformAdapter", "LinuxAdapter", "MacOSAdapter",
           "WindowsAdapter", "get_platform", "detect_name", "ADAPTERS"]
