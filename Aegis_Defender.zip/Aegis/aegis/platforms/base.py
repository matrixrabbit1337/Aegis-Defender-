"""Platform adapter interface.

Everything that differs between Linux, macOS and Windows lives in one of the
three sibling modules (linux.py, macos.py, windows.py). The rest of Aegis
talks only to this interface, so OS quirks never leak into detection logic.

Every adapter module must import cleanly on EVERY OS (no OS-only imports at
module level) so the full test-suite can exercise all three on any host.
"""
from __future__ import annotations

import os
import re


class PlatformAdapter:
    #: "linux" | "macos" | "windows"
    name = "base"
    #: filesystem is case-insensitive by default (APFS/NTFS)
    case_insensitive = False
    #: psutil.Process.io_counters() exists (it does NOT on macOS)
    supports_io_counters = True
    #: file->process attribution quality, shown to the user by `aegis status`
    attribution_note = ""

    #: lowercase process names Aegis must NEVER kill (OS-critical)
    never_kill_names: frozenset = frozenset()
    #: lowercase interpreter names: quarantine the *script*, not the runtime
    interpreter_names: frozenset = frozenset({
        "python", "python3", "pythonw", "node", "bash", "sh", "zsh", "dash",
        "perl", "ruby", "java", "javaw", "pwsh", "powershell", "wscript",
        "cscript", "php", "lua", "osascript",
    })

    # -- locations ------------------------------------------------------
    def default_state_dir(self) -> str:
        return os.path.join(os.path.expanduser("~"), ".aegis")

    def default_config_path(self) -> str:
        return os.path.join(self.default_state_dir(), "config.yaml")

    def user_folders(self) -> list[str]:
        """Candidate user-data folders offered during first-run setup."""
        home = os.path.expanduser("~")
        names = ("Documents", "Desktop", "Pictures")
        return [os.path.join(home, n) for n in names
                if os.path.isdir(os.path.join(home, n))]

    def dangerous_dirs(self) -> list[str]:
        """Dirs Aegis refuses to protect (a rollback there could be fatal)."""
        return []

    # -- paths ------------------------------------------------------------
    def normcase(self, path: str) -> str:
        """Canonical key for comparing paths on this OS's filesystem.
        Always normalise path separators so Windows paths with forward slashes
        compare equal to the same path with backslashes."""
        if self.case_insensitive:
            # Use the OS-native sep when running on Windows, otherwise keep
            # forward slashes (Linux/macOS); but for case-insensitive adapters
            # we always want a consistent separator so string comparison works.
            path = path.replace("\\", "/").replace("//", "/")
        path = os.path.normpath(path)
        return path.lower() if self.case_insensitive else path

    def is_link(self, path: str) -> bool:
        """Symlink (or Windows junction) — never followed or snapshotted."""
        if os.path.islink(path):
            return True
        isjunction = getattr(os.path, "isjunction", None)
        return bool(isjunction and isjunction(path))

    def is_dangerous(self, path: str) -> bool:
        real = self.normcase(os.path.realpath(path))
        home = self.normcase(os.path.realpath(os.path.expanduser("~")))
        if real == home:
            return True
        # an ancestor of home (e.g. /home, C:\Users) is just as bad
        if home.startswith(real.rstrip(os.sep) + os.sep):
            return True
        for bad in self.dangerous_dirs():
            bad_n = self.normcase(os.path.realpath(bad))
            if real == bad_n or real.startswith(bad_n.rstrip(os.sep) + os.sep):
                return True
        return False

    # -- process safety -----------------------------------------------------
    def is_protected_process(self, name: str | None, pid: int) -> bool:
        if pid <= 4:  # 0/1 init, 4 = Windows "System"
            return True
        base = (name or "").lower()
        return base in self.never_kill_names

    def is_interpreter(self, exe: str | None) -> bool:
        leaf = (exe or "").replace("\\", "/").rsplit("/", 1)[-1]  # any OS's path
        base = os.path.splitext(leaf)[0].lower()
        base = re.sub(r"[\d.]+$", "", base)  # python3.12 -> python
        return base in self.interpreter_names

    # -- OS integration (best effort, never fatal) ----------------------------
    def notify(self, title: str, message: str) -> None:  # pragma: no cover
        """Desktop notification. Default: no-op (console banner still shown)."""

    def harden_state_dir(self, path: str) -> None:
        """Restrict the state dir to the current user. Best effort."""
        try:
            os.chmod(path, 0o700)
        except OSError:
            pass

    def is_admin(self) -> bool:
        return False
