"""Canary tripwires: believable decoy files whose only job is to be touched.

A canary is seeded into each protected directory. Legitimate software never
opens them, so *any* modification, deletion, or rename is treated as an
attack with a near-zero false-positive rate. The manager records a SHA-256
baseline per canary and can verify integrity on demand.

Safety: seeding NEVER overwrites an existing file that is not already one of
ours — if a file with the same name exists, it is left alone.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import time
import zipfile
from pathlib import Path

from .platforms import get_platform


def _pdf_bytes(title: str, body_lines: list[str]) -> bytes:
    text = "\\n".join(
        [f"BT /F1 12 Tf 72 720 Td ({title}) Tj ET"] +
        [f"BT /F1 10 Tf 72 {700 - i * 14} Td ({l}) Tj ET"
         for i, l in enumerate(body_lines)]
    )
    return (
        "%PDF-1.4\n%\xe2\xe3\xcf\xd3\n"
        "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n"
        "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n"
        "3 0 obj\n<< /Type /Page /Parent 2 0 R /Contents 4 0 R >>\nendobj\n"
        f"4 0 obj\n<< /Length {len(text)} >>\nstream\n{text}\nendstream\nendobj\n"
        "trailer\n<< /Root 1 0 R >>\n%%EOF\n"
    ).encode("latin-1")


DECOY_TEXT = {
    "2024_tax_return.pdf": _pdf_bytes(
        "2024 Federal Tax Return - Form 1040",
        ["Taxpayer: J. Doe", "SSN: XXX-XX-1234 (redacted copy)",
         "Adjusted gross income: $84,210.00",
         "Total tax: $11,032.00", "Refund: $1,214.00",
         "*** CONFIDENTIAL - DO NOT DELETE ***"]),
    "insurance_claim_2024.pdf": _pdf_bytes(
        "Homeowners Insurance Claim #CL-2024-88112",
        ["Policy: HO-8844112", "Claim amount: $12,400.00",
         "Status: APPROVED - payment pending",
         "*** CONFIDENTIAL - DO NOT DELETE ***"]),
    "passwords_backup.xlsx": (
        "site,username,password,notes\n"
        "mail.example.com,jdoe,Tr0ub4dor&3x4mpl3,personal\n"
        "bank.example.com,jdoe92,C0rr3ct-H0rs3-B4tt3ry,banking\n"
        "cloud.example.com,j.doe,S3cur3!P4ssw0rd9,work\n"
        "*** EXPORTED PASSWORD VAULT - DO NOT DELETE ***\n"
    ).encode(),
    "Q3_financials.docx": (
        "Q3 2024 Financial Summary - CONFIDENTIAL\n"
        "========================================\n"
        "Revenue:        $1,240,000\n"
        "Operating cost: $   810,000\n"
        "Net profit:     $   430,000\n"
        "*** DO NOT DELETE ***\n"
    ).encode(),
}


def _zip_bytes() -> bytes:
    buf = io.BytesIO()
    # Fixed timestamp => byte-identical output every time, so a canary can be
    # re-created after a rollback and still match its recorded hash.
    info = zipfile.ZipInfo("w2_2024.txt", date_time=(2024, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr(
            info,
            "2024 W-2 Wage and Tax Statement\nEmployer: Example Corp\n"
            "Wages: $84,210.00\n*** CONFIDENTIAL - DO NOT DELETE ***\n")
    return buf.getvalue()


class CanaryManager:
    STATE_FILE = "canaries.json"

    def __init__(self, state_dir: str | os.PathLike):
        self.state_dir = Path(os.path.expanduser(str(state_dir)))
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self._path = self.state_dir / self.STATE_FILE
        self._plat = get_platform()
        self._mtime = 0.0
        self._last_check = 0.0
        self._canaries: dict[str, dict] = self._load()
        self._index: dict[str, str] = {}
        self._reindex()

    def _key(self, path: str) -> str:
        """Canonical lookup key (case-folded on Windows/macOS)."""
        return self._plat.normcase(os.path.realpath(path))

    def _reindex(self) -> None:
        self._index = {self._key(p): p for p in self._canaries}

    def refresh(self, min_interval: float = 1.0) -> None:
        """Pick up canaries seeded by another process (e.g. `aegis
        seed-canaries` while the watcher is already running)."""
        now = time.time()
        if now - self._last_check < min_interval:
            return
        self._last_check = now
        try:
            mtime = self._path.stat().st_mtime
        except OSError:
            return
        if mtime != self._mtime:
            self._canaries = self._load()
            self._reindex()

    # -- persistence ------------------------------------------------------
    def _load(self) -> dict:
        try:
            self._mtime = self._path.stat().st_mtime
            return json.loads(self._path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _save(self) -> None:
        tmp = self._path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self._canaries, indent=2), encoding="utf-8")
        os.replace(tmp, self._path)
        try:
            self._mtime = self._path.stat().st_mtime
        except OSError:
            pass
        self._reindex()

    # -- seeding -----------------------------------------------------------
    @staticmethod
    def _decoy_bytes(name: str) -> bytes:
        if name.endswith(".zip"):
            return _zip_bytes()
        if name in DECOY_TEXT:
            return DECOY_TEXT[name]
        return (f"Aegis canary tripwire file: {name}\n"
                "*** DO NOT DELETE ***\n").encode()

    @staticmethod
    def _sha256(path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as fh:
            for chunk in iter(lambda: fh.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()

    def seed(self, dirs: list[str], filenames: list[str]) -> list[str]:
        """Write decoy files into each dir. Returns paths actually seeded."""
        seeded = []
        for directory in dirs:
            directory = os.path.realpath(directory)
            for name in filenames:
                target = os.path.join(directory, name)
                record_key = os.path.realpath(target)
                if self._key(target) in self._index:
                    continue  # already ours
                if os.path.lexists(target):
                    continue  # NEVER overwrite a real user file
                data = self._decoy_bytes(name)
                with open(target, "wb") as fh:
                    fh.write(data)
                self._canaries[record_key] = {
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "size": len(data),
                    "seeded_at": time.time(),
                }
                seeded.append(target)
        self._save()
        return seeded

    # -- tripwire checks ----------------------------------------------------
    def is_canary(self, path: str) -> bool:
        self.refresh()
        return self._key(path) in self._index

    def check(self, path: str) -> str | None:
        """'modified' / 'deleted' if the canary was touched, else None."""
        record_key = self._index.get(self._key(path))
        record = self._canaries.get(record_key) if record_key else None
        if record is None:
            return None
        if not os.path.exists(record_key):
            return "deleted"
        try:
            current = self._sha256(record_key)
        except OSError:
            return "deleted"
        return "modified" if current != record["sha256"] else None

    def verify_all(self) -> list[tuple[str, str | None]]:
        """[(canary_path, status)] — status None means healthy."""
        return [(p, self.check(p)) for p in list(self._canaries)]

    @property
    def count(self) -> int:
        return len(self._canaries)

    def paths(self) -> list[str]:
        return list(self._canaries)

    def restore_all(self) -> list[str]:
        """Re-create any tripped canary (after a rollback). Returns the
        paths rewritten. Only ever touches files WE seeded."""
        restored = []
        for path in list(self._canaries):
            if self.check(path) is None:
                continue
            data = self._decoy_bytes(os.path.basename(path))
            try:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "wb") as fh:
                    fh.write(data)
            except OSError:
                continue
            self._canaries[path]["sha256"] = hashlib.sha256(data).hexdigest()
            self._canaries[path]["size"] = len(data)
            restored.append(path)
        if restored:
            self._save()
        return restored
