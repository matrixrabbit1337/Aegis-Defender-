"""Baseline snapshots and rollback ("time machine").

Phase-1 honesty note: without a kernel sensor there is no way to intercept a
write *before* it lands, so Phase 1 approximates copy-on-first-write with a
full snapshot taken at agent start. On incident, ``rollback`` restores files
from that baseline and removes files created after it (ransom notes, renamed
ciphertext, ...).

Safety rules (hard):
  * Rollback only ever deletes a file if it was *seen and walked* at baseline
    time as absent. Anything the baseline could not back up (over the size
    cap, symlink, unreadable, copy failure) is recorded in the manifest as
    ``skipped`` and is NEVER deleted or overwritten by rollback.
  * Every backup copy is hashed when written and re-verified before it is
    restored; a corrupt backup is reported and the live file is left alone.
  * Canary files are never deleted; tripped canaries are re-created.
  * Baselines referenced by an un-rolled-back incident are pinned: rotation
    never deletes them, and the newest baseline is never deleted.
  * ``dry_run=True`` reports exactly what would change and changes nothing.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from datetime import datetime, timezone
from pathlib import Path

from .platforms import get_platform


def _utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")


def _sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _copy_and_hash(src: str, dst: str) -> tuple[str, int]:
    """Copy src->dst, hashing the bytes actually written."""
    h = hashlib.sha256()
    n = 0
    with open(src, "rb") as fin, open(dst, "wb") as fout:
        for chunk in iter(lambda: fin.read(65536), b""):
            h.update(chunk)
            fout.write(chunk)
            n += len(chunk)
    try:
        shutil.copystat(src, dst)
    except OSError:
        pass
    return h.hexdigest(), n


def _dir_size(path: Path) -> int:
    total = 0
    for dirpath, _, filenames in os.walk(path):
        for fn in filenames:
            try:
                total += os.path.getsize(os.path.join(dirpath, fn))
            except OSError:
                pass
    return total


def _atomic_write_json(path: Path, obj: dict) -> None:
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")
    os.replace(tmp, path)


class Journal:
    def __init__(self, state_dir: str | os.PathLike, config: dict):
        self.state_dir = Path(os.path.expanduser(str(state_dir)))
        self.cfg = config.get("journal", {}) or {}
        self.plat = get_platform()
        self.baseline_dir = self.state_dir / "journal" / "baselines"
        self.incident_dir = self.state_dir / "incidents"
        self.baseline_dir.mkdir(parents=True, exist_ok=True)
        self.incident_dir.mkdir(parents=True, exist_ok=True)
        self.plat.harden_state_dir(str(self.state_dir))
        self.last_baseline_id: str | None = None
        self.last_baseline_stats: dict = {}

    # -- baselines ----------------------------------------------------------
    def take_baseline(self, protected_dirs: list[str]) -> str:
        """Snapshot every protected dir. Returns the baseline id."""
        baseline_id = "base-" + _utc_stamp() + "-" + os.urandom(3).hex()
        dest = self.baseline_dir / baseline_id
        dest.mkdir(parents=True, exist_ok=True)
        max_bytes = float(self.cfg.get("max_file_mb", 100)) * 1024 * 1024
        state_real = os.path.realpath(self.state_dir)
        files: dict[str, dict] = {}
        skipped: dict[str, str] = {}
        unreadable_dirs: list[str] = []
        real_dirs = [os.path.realpath(d) for d in protected_dirs]

        for i, root in enumerate(real_dirs):
            def _onerror(err, _i=i):
                rel = os.path.relpath(
                    getattr(err, "filename", root) or root, root)
                unreadable_dirs.append(
                    f"dir{_i}/" + ("" if rel == "." else rel))

            for dirpath, dirnames, filenames in os.walk(root,
                                                        onerror=_onerror):
                rp = os.path.realpath(dirpath)
                if rp == state_real or rp.startswith(state_real + os.sep):
                    dirnames[:] = []
                    continue
                # never descend into links/junctions
                dirnames[:] = [d for d in dirnames if not self.plat.is_link(
                    os.path.join(dirpath, d))]
                for fn in sorted(filenames):
                    src = os.path.join(dirpath, fn)
                    rel = os.path.relpath(src, root)
                    key = f"dir{i}/{rel}"
                    if self.plat.is_link(src):
                        skipped[key] = "symlink"
                        continue
                    try:
                        size = os.path.getsize(src)
                    except OSError:
                        skipped[key] = "unreadable"
                        continue
                    if size > max_bytes:
                        skipped[key] = "over size cap"
                        continue
                    target = dest / key
                    try:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        digest, n = _copy_and_hash(src, str(target))
                    except OSError as exc:
                        skipped[key] = f"copy failed: {exc.__class__.__name__}"
                        try:
                            target.unlink()
                        except OSError:
                            pass
                        continue
                    files[key] = {"sha256": digest, "size": n}

        _atomic_write_json(dest / "manifest.json", {
            "baseline_id": baseline_id,
            "taken_at": time.time(),
            "dirs": real_dirs,
            "files": files,
            "skipped": skipped,
            "unreadable_dirs": unreadable_dirs,
        })
        self.last_baseline_id = baseline_id
        self.last_baseline_stats = {
            "backed_up": len(files), "not_backed_up": len(skipped),
            "unreadable_dirs": len(unreadable_dirs)}
        self._enforce_cap()
        return baseline_id

    def _pinned_baselines(self) -> set[str]:
        """Baselines still needed to roll back an unresolved incident."""
        pinned = set()
        for inc in self.list_incidents():
            try:
                info = self.load_incident(inc)
            except (OSError, ValueError):
                continue
            if info.get("baseline_id") and not info.get("rolled_back"):
                pinned.add(info["baseline_id"])
        return pinned

    def _enforce_cap(self) -> None:
        cap = float(self.cfg.get("max_total_mb", 2048)) * 1024 * 1024
        keep = self._pinned_baselines()
        if self.last_baseline_id:
            keep.add(self.last_baseline_id)  # never evict the newest
        baselines = sorted(p for p in self.baseline_dir.iterdir()
                           if p.is_dir() and p.name not in keep)
        while baselines and _dir_size(self.baseline_dir) > cap:
            shutil.rmtree(baselines.pop(0), ignore_errors=True)
        if _dir_size(self.baseline_dir) > cap:
            print("[aegis] WARNING: journal exceeds max_total_mb but the "
                  "remaining baselines are pinned by unresolved incidents "
                  "or are the newest. Raise journal.max_total_mb or roll "
                  "back / clear old incidents.", flush=True)

    def disk_usage(self) -> int:
        return _dir_size(self.state_dir / "journal")

    # -- pre-modification copy (Phase C, kernel sensor) --------------------
    def capture_pre_modification(self, path: str, fd: int | None = None):
        """Snapshot the CURRENT (still-clean) bytes of a file the kernel is
        about to let a suspicious process modify. Stored under the newest
        baseline so rollback restores this exact pre-attack version.

        This is the real "capture a clean version before a suspicious writer
        changes it" primitive — only reachable from the blocking sensor, which
        hands us an fd opened before the write."""
        if not self.last_baseline_id:
            return None
        base = self.baseline_dir / self.last_baseline_id
        if not base.is_dir():
            return None
        for i, root in enumerate(self._baseline_dirs(base)):
            rp = os.path.realpath(path)
            if rp == root or rp.startswith(root + os.sep):
                key = f"dir{i}/" + os.path.relpath(rp, root)
                target = base / key
                if target.exists():
                    return str(target)  # already have a clean copy
                try:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    if fd is not None:
                        data = os.pread(fd, 1 << 30, 0)
                        with open(target, "wb") as fh:
                            fh.write(data)
                        digest = hashlib.sha256(data).hexdigest()
                        size = len(data)
                    else:
                        digest, size = _copy_and_hash(rp, str(target))
                except OSError:
                    return None
                self._append_manifest_entry(base, key, digest, size)
                return str(target)
        return None

    def _baseline_dirs(self, base) -> list[str]:
        try:
            m = json.loads((base / "manifest.json").read_text())
            return m.get("dirs", [])
        except (OSError, ValueError):
            return []

    def _append_manifest_entry(self, base, key, digest, size):
        path = base / "manifest.json"
        try:
            m = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        m.setdefault("files", {})[key] = {"sha256": digest, "size": size}
        m.setdefault("pre_mod", []).append(key)
        _atomic_write_json(path, m)

    # -- incidents ------------------------------------------------------------
    def create_incident(self, info: dict) -> str:
        incident_id = "inc-" + _utc_stamp() + "-" + os.urandom(3).hex()
        info = dict(info)
        info["id"] = incident_id
        dest = self.incident_dir / incident_id
        dest.mkdir(parents=True, exist_ok=True)
        _atomic_write_json(dest / "report.json", info)
        return incident_id

    def update_incident(self, incident_id: str, updates: dict) -> None:
        path = self.incident_dir / incident_id / "report.json"
        info = json.loads(path.read_text(encoding="utf-8"))
        info.update(updates)
        _atomic_write_json(path, info)

    def list_incidents(self) -> list[str]:
        return sorted(p.name for p in self.incident_dir.iterdir()
                      if p.is_dir())

    def load_incident(self, incident_id: str) -> dict:
        return json.loads(
            (self.incident_dir / incident_id / "report.json")
            .read_text(encoding="utf-8"))

    # -- rollback ---------------------------------------------------------------
    def rollback(self, incident_id: str, dry_run: bool = False) -> dict:
        """Restore baseline files; delete only files created after baseline.

        Returns {"restored", "unchanged", "deleted", "failed",
                 "not_backed_up", "canaries_restored", "dry_run"}.
        """
        report = self.load_incident(incident_id)
        baseline_id = report.get("baseline_id")
        if not baseline_id:
            raise RuntimeError(f"incident {incident_id} has no baseline ref")
        manifest_path = self.baseline_dir / baseline_id / "manifest.json"
        if not manifest_path.exists():
            raise RuntimeError(f"baseline {baseline_id} was rotated away")
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except ValueError as exc:
            raise RuntimeError(
                f"baseline {baseline_id} manifest is corrupt: {exc}")

        from .canary import CanaryManager  # local: avoid import cycle
        canaries = CanaryManager(self.state_dir)
        canary_keys = {self.plat.normcase(os.path.realpath(p))
                       for p in canaries.paths()}

        restored, unchanged, deleted, failed = [], [], [], []
        not_backed_up = []
        state_real = os.path.realpath(self.state_dir)
        skipped = manifest.get("skipped", {})
        bad_dirs = manifest.get("unreadable_dirs", [])

        for i, root in enumerate(manifest["dirs"]):
            prefix = f"dir{i}/"
            if not os.path.isdir(root):
                continue
            # 1. restore everything that existed (and was backed up)
            for key, meta in manifest["files"].items():
                if not key.startswith(prefix):
                    continue
                dst = os.path.join(root, key[len(prefix):])
                src = self.baseline_dir / baseline_id / key
                try:
                    if (os.path.isfile(dst) and not self.plat.is_link(dst)
                            and _sha256_file(dst) == meta["sha256"]):
                        unchanged.append(dst)
                        continue
                    if dry_run:
                        restored.append(dst)
                        continue
                    self._restore_one(src, dst, meta["sha256"])
                    restored.append(dst)
                except (OSError, RuntimeError) as exc:
                    failed.append((dst, str(exc)))

            # 2. delete only files that did not exist at baseline
            wanted = {self.plat.normcase(k[len(prefix):])
                      for k in list(manifest["files"]) + list(skipped)
                      if k.startswith(prefix)}
            for k, why in skipped.items():
                if k.startswith(prefix):
                    not_backed_up.append(
                        (os.path.join(root, k[len(prefix):]), why))
            for dirpath, dirnames, filenames in os.walk(root):
                rp = os.path.realpath(dirpath)
                if rp == state_real or rp.startswith(state_real + os.sep):
                    dirnames[:] = []
                    continue
                rel_dir = os.path.relpath(dirpath, root)
                dir_key = prefix + ("" if rel_dir == "." else rel_dir)
                if any(dir_key == b or dir_key.startswith(b + os.sep)
                       for b in bad_dirs):
                    dirnames[:] = []  # unreadable at baseline: don't guess
                    continue
                dirnames[:] = [d for d in dirnames if not self.plat.is_link(
                    os.path.join(dirpath, d))]
                for fn in filenames:
                    full = os.path.join(dirpath, fn)
                    rel = self.plat.normcase(os.path.relpath(full, root))
                    if rel in wanted:
                        continue
                    if self.plat.normcase(
                            os.path.realpath(full)) in canary_keys:
                        continue  # canaries are ours: never delete
                    if dry_run:
                        deleted.append(full)
                        continue
                    try:
                        os.remove(full)
                        deleted.append(full)
                    except OSError as exc:
                        failed.append((full, str(exc)))

        canaries_restored = []
        if not dry_run:
            canaries_restored = canaries.restore_all()
            if not failed:
                self.update_incident(incident_id, {
                    "rolled_back": True,
                    "rolled_back_at": time.time()})
        return {"restored": restored, "unchanged": unchanged,
                "deleted": deleted, "failed": failed,
                "not_backed_up": not_backed_up,
                "canaries_restored": canaries_restored,
                "dry_run": dry_run}

    @staticmethod
    def _restore_one(src: Path, dst: str, expected_sha: str) -> None:
        """Verify the backup, write atomically, verify the result."""
        if _sha256_file(str(src)) != expected_sha:
            raise RuntimeError("backup copy is corrupt (hash mismatch); "
                               "live file left untouched")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        tmp = os.path.join(os.path.dirname(dst),
                           f".aegis-restore-{os.urandom(4).hex()}")
        try:
            shutil.copyfile(src, tmp)
            try:
                shutil.copystat(src, tmp)
            except OSError:
                pass
            if _sha256_file(tmp) != expected_sha:
                raise RuntimeError("restored copy failed verification")
            os.replace(tmp, dst)
        finally:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
