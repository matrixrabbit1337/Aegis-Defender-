"""User-space rapid containment — prevention on ALL three OSes, NO certificate.

You do not need a signed kernel driver to PREVENT a ransomware attack. Real-time
file monitoring (watchdog: inotify / ReadDirectoryChangesW / FSEvents, all
cert-free) plus instant process control stops the attack after a file or two
instead of thousands. psutil gives suspend()/terminate()/kill() on Windows,
macOS and Linux with no entitlement.

Containment ladder (fastest, most reversible first):
  1. SUSPEND the offending process tree immediately — freezes the ransomware
     mid-run in microseconds and is fully reversible for a false positive.
  2. (caller snapshots evidence while it is frozen)
  3. TERMINATE, then KILL the tree if still alive.

Safety is paramount: this code can stop processes, so it refuses to touch
PID<=4, itself, the agent, OS-critical processes (per-OS list), and — for
system-path binaries — anything not positively attributed to a protected dir.
It will NEVER expand PID 1 into "all processes".
"""
from __future__ import annotations

import os
import time

try:
    import psutil
except ImportError:  # pragma: no cover
    psutil = None

from .heuristics import looks_like_aegis_agent

# exe-path prefixes we treat as system binaries (defense in depth)
_SYSTEM_PREFIXES = (
    "/usr/lib/", "/usr/libexec/", "/lib/", "/lib64/", "/sbin/", "/usr/sbin/",
    "/opt/", "/snap/", "/System/", "/Library/", "/usr/bin/dbus",
    "C:\\Windows\\", "C:\\Program Files\\", "C:\\Program Files (x86)\\",
)


class Containment:
    def __init__(self, platform, config: dict, agent=None):
        self.plat = platform
        self.agent = agent
        c = config.get("response", {}) or {}
        self._suspend_first = bool(c.get("suspend_first", True))
        self._self_pid = os.getpid()

    # -- safety ------------------------------------------------------------
    def _safe_target(self, proc) -> bool:
        """Never touch init, ourselves, the agent, OS-critical processes, or a
        system-path binary that isn't positively writing in a protected dir."""
        try:
            pid = proc.pid
            if pid <= 4 or pid == self._self_pid:
                return False
            if looks_like_aegis_agent(" ".join(proc.cmdline())):
                return False
            if self.plat.is_protected_process(proc.name(), pid):
                return False
            exe = proc.exe() or ""
            if any(exe.startswith(p) for p in _SYSTEM_PREFIXES):
                if not self._wrote_in_scope(proc):
                    return False
        except (psutil.NoSuchProcess, psutil.AccessDenied,
                psutil.ZombieProcess):
            return False
        return True

    def _wrote_in_scope(self, proc) -> bool:
        if self.agent is None:
            return True
        try:
            for f in proc.open_files():
                if self.agent._in_scope(f.path):
                    return True
        except (psutil.NoSuchProcess, psutil.AccessDenied,
                psutil.ZombieProcess, OSError):
            pass
        return False

    def _tree(self, pid: int) -> list:
        # NEVER expand init/system pids into a whole-system tree.
        if pid is None or pid <= 4:
            return []
        try:
            root = psutil.Process(pid)
            return [root] + root.children(recursive=True)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return []

    # -- step 1: freeze ----------------------------------------------------
    def suspend(self, pid: int) -> list[int]:
        if psutil is None:
            return []
        suspended = []
        for proc in self._tree(pid):
            if not self._safe_target(proc):
                continue
            try:
                proc.suspend()
                suspended.append(proc.pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied,
                    psutil.ZombieProcess):
                pass
        return suspended

    def resume(self, pids: list[int]) -> None:
        if psutil is None:
            return
        for pid in pids:
            try:
                psutil.Process(pid).resume()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

    # -- step 3: terminate -------------------------------------------------
    def kill(self, pid: int) -> bool:
        if psutil is None:
            return False
        if pid is None or pid <= 4:
            return False
        targets = [p for p in self._tree(pid) if self._safe_target(p)]
        if not targets:
            return not psutil.pid_exists(pid)
        for proc in targets:
            try:
                proc.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        _, alive = psutil.wait_procs(targets, timeout=3)
        for proc in alive:
            try:
                proc.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        _, alive = psutil.wait_procs(alive, timeout=3)
        return len(alive) == 0

    # -- combined ----------------------------------------------------------
    def contain(self, pid: int) -> dict:
        t0 = time.time()
        suspended = self.suspend(pid) if self._suspend_first else []
        killed = self.kill(pid)
        return {"suspended": suspended, "killed": killed,
                "latency_ms": round((time.time() - t0) * 1000, 1)}
