"""User-space sensor (cross-platform, no root). Detect-only: it observes and
reports, but cannot stop a write before it lands. Decisions are enforced after
the fact by the responder (kill + rollback)."""
from __future__ import annotations

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

from ..events import Event, EventKind

_SAMPLE = 32768


def sample_entropy(path, max_bytes=_SAMPLE):
    from ..heuristics import shannon_entropy
    try:
        with open(path, "rb") as fh:
            data = fh.read(max_bytes)
    except OSError:
        return None, None
    if not data:
        return 0.0, 0
    return shannon_entropy(data), len(data)


_KIND = {"modified": EventKind.FILE_MODIFY, "created": EventKind.FILE_CREATE,
         "moved": EventKind.FILE_RENAME, "deleted": EventKind.FILE_DELETE}


class _Handler(FileSystemEventHandler):
    def __init__(self, sensor):
        self.s = sensor

    def on_modified(self, e):
        if not e.is_directory:
            self.s._emit("modified", e.src_path)

    def on_created(self, e):
        if not e.is_directory:
            self.s._emit("created", e.src_path)

    def on_moved(self, e):
        if not e.is_directory:
            self.s._emit("moved", e.src_path, e.dest_path)

    def on_deleted(self, e):
        if not e.is_directory:
            self.s._emit("deleted", e.src_path)


class WatchdogSensor:
    blocking = False

    def __init__(self, agent):
        self.agent = agent
        self._obs = Observer()
        self._handler = _Handler(self)

    def _emit(self, kind, src, dest=None):
        try:
            target = dest or src
            if not self.agent._in_scope(target):
                return
            ev = Event(kind=_KIND[kind], path=src, dest=dest,
                       source="watchdog")
            if kind in ("modified", "created"):
                ev.entropy, ev.size = sample_entropy(target)
            ev.canary = self.agent.canaries.is_canary(src) or bool(
                dest and self.agent.canaries.is_canary(dest))
            self.agent.on_event(ev)  # decision ignored (cannot block)
        except Exception as exc:
            print(f"[aegis] watchdog event failed for {src}: {exc!r}",
                  flush=True)

    def start(self):
        for d in self.agent.protected_dirs:
            self._obs.schedule(self._handler, d, recursive=True)
        self._obs.start()

    def stop(self):
        self._obs.stop()
        self._obs.join(timeout=5)
