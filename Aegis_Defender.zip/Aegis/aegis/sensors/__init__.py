"""Sensors turn OS activity into the Phase-A Event contract.

  watchdog_sensor.py   cross-platform, user-space (no root) — always available
  fanotify_sensor.py   Linux kernel, real pre-write BLOCK (needs root + CAP_SYS_ADMIN)

The agent picks the strongest sensor the platform/privileges allow and falls
back to watchdog. All sensors share one callback signature: fn(Event) -> Decision
(the engine returns a Decision; blocking sensors enforce it, others ignore it).
"""
from __future__ import annotations


def build_sensor(agent):
    """Return (sensor, mode_str). Kernel sensor when possible, else watchdog."""
    import sys
    cfg = agent.config.get("sensor", {}) or {}
    pref = cfg.get("mode", "auto")  # auto | kernel | userspace

    if pref in ("auto", "kernel") and sys.platform.startswith("linux"):
        try:
            from .fanotify_sensor import FanotifySensor, available
            ok, why = available()
            if ok:
                return FanotifySensor(agent), "kernel (fanotify, pre-write block)"
            if pref == "kernel":
                raise RuntimeError(f"kernel sensor unavailable: {why}")
        except RuntimeError:
            raise
        except Exception as exc:  # pragma: no cover
            if pref == "kernel":
                raise RuntimeError(f"kernel sensor failed to load: {exc}")

    from .watchdog_sensor import WatchdogSensor
    return WatchdogSensor(agent), "userspace (watchdog, detect-only)"
