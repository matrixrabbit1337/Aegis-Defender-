"""Linux kernel sensor via fanotify — REAL pre-write blocking (Phase D, Linux).

Uses FAN_OPEN_PERM / FAN_ACCESS_PERM permission events: the kernel suspends the
writer and waits for Aegis to allow or DENY *before the write lands*. This is
the plan's "pre-modification copy and block" primitive, implemented with the
Linux-native mechanism. It needs root (CAP_SYS_ADMIN).

Design:
  * One fanotify group in FAN_CLASS_CONTENT (permission-capable).
  * Mark each protected dir with FAN_OPEN_PERM | FAN_ACCESS_PERM, plus
    FAN_MARK_MOUNT? No — per-directory marks (FAN_MARK_ADD, no FAN_ONLYDIR) so
    we never touch files outside scope.
  * On each permission event we read the fd the kernel hands us, identify the
    writing process from the event's pid, ask the engine for a Decision, take a
    pre-modification copy if the engine says so, then write the allow/deny
    response. Unknown/again -> always ALLOW (fail-open per file) so a bug can
    never freeze the user's filesystem.
  * A hard watchdog thread guarantees every event is answered within a timeout,
    so the kernel is never left waiting (which would hang the machine).

fanotify gives us the *pid* directly (no guessing) — this is the attribution
the user-space sensor could only approximate.
"""
from __future__ import annotations

import ctypes
import os
import queue
import struct
import threading

from ..events import Decision

# ---- libc / fanotify constants ------------------------------------------------
FAN_CLOEXEC = 0x00000001
FAN_NONBLOCK = 0x00000002
FAN_CLASS_CONTENT = 0x00000004

FAN_OPEN_PERM = 0x00010000
FAN_ACCESS_PERM = 0x00020000
FAN_OPEN_EXEC_PERM = 0x00040000

FAN_ALLOW = 0x01
FAN_DENY = 0x02

FAN_MARK_ADD = 0x00000001
FAN_MARK_REMOVE = 0x00000002
FAN_MARK_MOUNT = 0x00000010
FAN_MARK_FILESYSTEM = 0x00000100

AT_FDCWD = -100
O_RDONLY = 0

# struct fanotify_event_metadata
_META = struct.Struct("=IBBHii")   # event_len, vers, reserved, meta_len, mask(8)? 
# Actually mask is __u64 and fd is __s32: layout is
#   __u32 event_len; __u8 vers; __u8 reserved; __u16 metadata_len;
#   __aligned_u64 mask; __s32 fd; __s32 pid;
_META = struct.Struct("=IBBHQii")
FAN_EVENT_METADATA_LEN = _META.size
FANOTIFY_METADATA_VERSION = 3

# struct fanotify_response { __s32 fd; __u32 response; }
_RESP = struct.Struct("=iI")


def _libc():
    return ctypes.CDLL("libc.so.6", use_errno=True)


def available() -> tuple[bool, str]:
    """(usable, reason). Usable only if root and fanotify perm events work."""
    import sys
    if not sys.platform.startswith("linux"):
        return False, "not Linux"
    if not (hasattr(os, "geteuid") and os.geteuid() == 0):
        return False, "needs root (CAP_SYS_ADMIN) for permission events"
    try:
        libc = _libc()
        fd = libc.fanotify_init(FAN_CLOEXEC | FAN_NONBLOCK | FAN_CLASS_CONTENT,
                                O_RDONLY)
        if fd < 0:
            return False, os.strerror(ctypes.get_errno())
        os.close(fd)
        return True, "ok"
    except Exception as exc:  # pragma: no cover
        return False, str(exc)


class FanotifySensor:
    blocking = True

    def __init__(self, agent):
        self.agent = agent
        self.libc = _libc()
        self._fd = -1
        self._self_pid = os.getpid()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        c = agent.config.get("sensor", {}) or {}
        self._answer_timeout = float(c.get("answer_timeout_s", 2.0))
        self._copy_before_block = bool(c.get("pre_modification_copy", True))
        # Responses to the kernel happen on the event loop; heavier work
        # (incident, kill, rollback) is handed to this worker so we NEVER block
        # the kernel — which would freeze the filesystem — while responding.
        self._work: queue.Queue = queue.Queue(maxsize=10000)
        self._worker: threading.Thread | None = None

    # -- lifecycle --------------------------------------------------------
    def start(self):
        fd = self.libc.fanotify_init(
            FAN_CLOEXEC | FAN_NONBLOCK | FAN_CLASS_CONTENT, O_RDONLY)
        if fd < 0:
            raise OSError(ctypes.get_errno(),
                          "fanotify_init: " + os.strerror(ctypes.get_errno()))
        self._fd = fd
        # A directory mark does NOT cover files inside it or files created
        # later, so we mark the MOUNT each protected dir lives on and filter
        # every event back to scope in _decide(). One mark per distinct mount.
        mask = FAN_OPEN_PERM | FAN_ACCESS_PERM
        marked = 0
        self._marked_mounts = set()
        for d in self.agent.protected_dirs:
            dev = os.stat(d).st_dev
            if dev in self._marked_mounts:
                marked += 1
                continue
            r = self.libc.fanotify_mark(
                fd, FAN_MARK_ADD | FAN_MARK_MOUNT, ctypes.c_uint64(mask),
                AT_FDCWD, d.encode())
            if r == 0:
                marked += 1
                self._marked_mounts.add(dev)
            else:
                print(f"[aegis] fanotify_mark failed for {d}: "
                      f"{os.strerror(ctypes.get_errno())}", flush=True)
        if not marked:
            os.close(fd)
            self._fd = -1
            raise OSError("fanotify: could not mark any protected mount")
        self._stop.clear()
        self._worker = threading.Thread(target=self._work_loop, daemon=True,
                                        name="aegis-fanotify-worker")
        self._worker.start()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name="aegis-fanotify")
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=3)
        if self._worker:
            self._work.put(None)
            self._worker.join(timeout=3)
        if self._fd >= 0:
            try:
                os.close(self._fd)
            except OSError:
                pass
            self._fd = -1

    # -- event loop -------------------------------------------------------
    def _loop(self):
        import select
        poller = select.poll()
        poller.register(self._fd, select.POLLIN)
        while not self._stop.is_set():
            try:
                if not poller.poll(200):
                    continue
                buf = os.read(self._fd, 8192)
            except (BlockingIOError, InterruptedError):
                continue
            except OSError:
                break
            self._consume(buf)

    def _consume(self, buf: bytes):
        off = 0
        while off + FAN_EVENT_METADATA_LEN <= len(buf):
            (event_len, vers, _res, _mlen, mask, fd, pid) = _META.unpack_from(
                buf, off)
            off += event_len if event_len else FAN_EVENT_METADATA_LEN
            if vers != FANOTIFY_METADATA_VERSION:
                if fd >= 0:
                    os.close(fd)
                continue
            if mask & (FAN_OPEN_PERM | FAN_ACCESS_PERM | FAN_OPEN_EXEC_PERM):
                self._answer(fd, pid, mask)
            elif fd >= 0:
                os.close(fd)

    def _answer(self, fd: int, pid: int, mask: int):
        """Decide allow/deny for one permission event, guaranteed to respond.

        CRITICAL: events caused by our OWN process (the stat/readlink/pread we
        do while deciding) are allowed instantly with no processing — otherwise
        we would recurse into _decide and deadlock the filesystem."""
        decision = Decision.ALLOW
        try:
            if fd >= 0 and pid and pid != self._self_pid:
                decision = self._decide(fd, pid)
        except Exception as exc:  # never hang the kernel on a bug
            print(f"[aegis] fanotify decide error (allowing): {exc!r}",
                  flush=True)
            decision = Decision.ALLOW
        finally:
            resp = FAN_DENY if decision == Decision.DENY else FAN_ALLOW
            try:
                os.write(self._fd, _RESP.pack(fd, resp))
            except OSError:
                pass
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass

    @staticmethod
    def _pid_has_write_open(pid: int, path: str) -> bool:
        """True if <pid> currently has <path> open for writing. Lets us block
        writes while allowing reads — language-agnostic, works for any binary."""
        try:
            fddir = f"/proc/{pid}/fd"
            for name in os.listdir(fddir):
                try:
                    target = os.readlink(os.path.join(fddir, name))
                except OSError:
                    continue
                if target != path:
                    continue
                # read the fd flags from fdinfo
                try:
                    with open(f"/proc/{pid}/fdinfo/{name}") as fh:
                        for line in fh:
                            if line.startswith("flags:"):
                                flags = int(line.split()[1], 8)
                                accmode = flags & 3  # O_ACCMODE
                                # 1=O_WRONLY, 2=O_RDWR
                                if accmode in (1, 2):
                                    return True
                except (OSError, ValueError):
                    # can't read flags: assume write to be safe (block)
                    return True
        except OSError:
            pass
        return False

    def _decide(self, fd: int, pid: int) -> Decision:
        """FAST path: read minimal context, compute a verdict, and enqueue the
        heavy work. Must never call the responder inline — the writer is
        suspended in the kernel waiting for us, so killing it here deadlocks."""
        try:
            path = os.readlink(f"/proc/self/fd/{fd}")
        except OSError:
            return Decision.ALLOW
        # Cheap string check before any realpath() syscall: never process our
        # own state dir (manifest/journal/evidence), which shares the mount.
        if path.startswith(self.agent.state_dir + os.sep):
            return Decision.ALLOW
        if not self.agent._in_scope(path):
            return Decision.ALLOW
        canary = self.agent.canaries.is_canary(path)
        # Is the attacker opening this for WRITE? (reads are always allowed)
        is_write = self._pid_has_write_open(pid, path)
        exe = None
        try:
            exe = os.readlink(f"/proc/{pid}/exe")
        except OSError:
            pass
        # Fast canary/known-extension verdict needs NO fd read.
        entropy = size = None
        if not canary:
            try:
                from .. import intel
                if not intel.is_ransom_extension(path):
                    data = os.pread(fd, 32768, 0)
                    if data:
                        from ..heuristics import shannon_entropy
                        entropy, size = shannon_entropy(data), len(data)
            except OSError:
                pass
        # Quick verdict for the KERNEL only (no response side effects):
        verdict = self.agent.quick_verdict(path=path, pid=pid, exe=exe,
                                           entropy=entropy, size=size,
                                           canary=canary, is_write=is_write)
        # CRITICAL: if this is a high-confidence block (canary, or a denied
        # write), FREEZE the attacker right now — synchronously, before we
        # answer any more events. Suspend is a single syscall (microseconds)
        # and reversible, so a false positive is recoverable. This stops a
        # fast multi-file encryptor from racing ahead while the async worker
        # builds the incident. Language-agnostic: we freeze by PID.
        if verdict == Decision.DENY and pid and pid != self._self_pid:
            try:
                self.agent.freeze_attacker(pid)
            except Exception:
                pass
        try:
            self._work.put_nowait((path, pid, exe, entropy, size, canary,
                                   verdict))
        except queue.Full:
            pass
        return verdict if verdict else Decision.ALLOW

    def _work_loop(self):
        from ..events import Event, EventKind
        while not self._stop.is_set():
            item = self._work.get()
            if item is None:
                break
            path, pid, exe, entropy, size, canary, verdict = item
            try:
                if verdict == Decision.DENY and self._copy_before_block:
                    try:
                        self.agent.journal.capture_pre_modification(path)
                    except Exception:
                        pass
                ev = Event(kind=EventKind.FILE_MODIFY, path=path, pid=pid,
                           exe=exe, entropy=entropy, size=size, canary=canary,
                           source="fanotify", blockable=True)
                # full detection + response, safely off the kernel path
                self.agent.on_event(ev)
            except Exception as exc:
                print(f"[aegis] fanotify worker error: {exc!r}", flush=True)
