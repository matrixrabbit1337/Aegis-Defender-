"""Threat intelligence derived from 2023–2026 ransomware research.

Static, offline indicators that raise detection quality without any feed or
network call (the plan's "local-first" requirement). Everything here is drawn
from public reporting on real families (LockBit, Akira, Royal/BlackSuit,
BlackCat/ALPHV, Clop, Qilin, Medusa, AvosLocker, DarkSide, Hive, RansomEXX...).

Lists are compiled from public threat-intel reporting on real families.
"""
from __future__ import annotations

import os
import re

# --- known ransomware encrypted-file extensions ------------------------------
# A rename to one of these is a near-certain impact signal (T1486).
KNOWN_RANSOM_EXTS = {
    ".akira", ".akiranew", ".powerranges",      # Akira
    ".lockbit", ".abcd", ".lock",               # LockBit family
    ".royal", ".royal_u", ".royal_w",           # Royal
    ".blacksuit",                                 # BlackSuit
    ".avoslinux", ".avos", ".avos2",            # AvosLocker
    ".darkside",                                  # DarkSide
    ".basta",                                     # Black Basta
    ".qilin", ".agenda",                         # Qilin/Agenda
    ".medusa",                                    # Medusa
    ".rhysida",                                    # Rhysida
    ".play",                                       # PLAY
    ".hive",                                        # Hive
    ".crypt", ".crypted", ".encrypted",          # generic
    ".locked", ".enc", ".pays", ".ransom",       # generic
    ".clop", ".cl0p",                             # Clop
    ".conti", ".ryuk", ".revil", ".sodinokibi", ".nemty", ".phobos",
}

# --- known ransom-note filename patterns -------------------------------------
# Extends the config defaults with specific, observed note names.
RANSOM_NOTE_PATTERNS = [
    r"readme[_ \-]?decrypt", r"how[_ \-]?to[_ \-]?recover",
    r"how[_ \-]?to[_ \-]?decrypt", r"decrypt[_ \-]?instruction",
    r"recover[_ \-]?my[_ \-]?files", r"decrypt[_ \-]?your[_ \-]?files",
    r"akira_readme", r"darkside_readme", r"restore[_ \-]?my[_ \-]?files",
    r"!!!.*readme", r"readme[_ \-]?for[_ \-]?decrypt", r"unlock[_ \-]?files",
    r"your[_ \-]?files[_ \-]?are[_ \-]?encrypted", r"recovery[_ \-]?instructions",
    r"\+README", r"RESTORE.*FILES", r"HELP[_ \-]?DECRYPT",
]

# --- recovery-inhibition commands (T1490) ------------------------------------
# Running any of these is a very high-signal pre-encryption step: the attacker
# is destroying the victim's ability to recover BEFORE the encryption burst.
# Watching for these buys the defender the "minutes before encryption" window
# that every incident-response guide points to.
_RECOVERY_INHIBIT_RES = [
    # Windows shadow copies / backup catalog
    re.compile(r"vssadmin(\.exe)?\s+.*delete\s+shadows", re.I),
    re.compile(r"vssadmin(\.exe)?\s+.*resize\s+shadowstorage", re.I),
    re.compile(r"wmic\s+shadowcopy\s+delete", re.I),
    re.compile(r"win32_shadowcopy.*delete", re.I),
    re.compile(r"diskshadow.*delete", re.I),
    re.compile(r"wbadmin\s+delete\s+(catalog|systemstatebackup|backup)", re.I),
    re.compile(r"bcdedit.*(recoveryenabled\s+no|bootstatuspolicy\s+ignoreallfailures)", re.I),
    re.compile(r"Get-WmiObject\s+Win32_Shadowcopy.*Delete", re.I),
    # Windows Defender / backup service tampering
    re.compile(r"Set-MpPreference\s+.*-Disable", re.I),
    # Linux / ESXi
    re.compile(r"esxcli\s+vm\s+process\s+kill", re.I),
    re.compile(r"esxcli\s+system\s+syslog\s+config\s+set\s+.*--logdir=/tmp", re.I),
    re.compile(r"\bvim-cmd\s+vmsvc/power\.off", re.I),
    re.compile(r"\brm\s+.*\.vmdk", re.I),
    # cloud/offsite sync snapshots
    re.compile(r"\bsnapshot\b.*\bdelete\b", re.I),
    # 2026 recovery-disruption playbook (Settra and others, Huntress/SOC Prime)
    re.compile(r"reagentc(\.exe)?\s+/disable", re.I),         # kill Win Recovery Env
    re.compile(r"cipher(\.exe)?\s+/w[:\s]", re.I),            # wipe free space
    re.compile(r"diskpart.*(delete|clean|remove)", re.I),      # remove recovery partition
    re.compile(r"wevtutil\s+(cl|clear-log)", re.I),            # clear event logs
    re.compile(r"Clear-EventLog", re.I),
    re.compile(r"fsutil\s+usn\s+deletejournal", re.I),        # kill NTFS change journal
    re.compile(r"bcdedit.*safeboot", re.I),
    # macOS: Time Machine / local snapshots / unified log wipe
    re.compile(r"tmutil\s+(delete|deletelocalsnapshots|disable|thinlocalsnapshots)", re.I),
    re.compile(r"\blog\s+erase\b", re.I),
    # Service stopping before encryption (T1489): backups, VSS, DBs, AV
    re.compile(r"\b(net|sc)(\.exe)?\s+(stop|config)\s+\"?(vss|veeam\w*|"
               r"wbengine|backup\w*|sql\w*|msexchange\w*|sophos\w*|"
               r"windefend|sense|mbamservice)\b", re.I),
    re.compile(r"systemctl\s+(stop|disable)\s+.*(backup|restic|borg|"
               r"veeam|bacula|snapper|timeshift)", re.I),
    # BYOVD: loading a known-vulnerable driver to kill EDR at the kernel
    re.compile(r"\b(gdrv|rtcore64|dbutil_2_3|iqvw64e|procexp152|aswarpot)\.sys\b", re.I),
]

# --- encryptionless / extortion-only awareness -------------------------------
# A growing share of 2026 incidents skip encryption and steal data only. The
# egress guard (aegis/egress.py) is the control for that path; recorded here so
# the two modules stay conceptually linked.
EXTORTION_ONLY_NOTE = (
    "2026 trend: many groups now exfiltrate and extort WITHOUT encrypting. "
    "Rollback cannot undo theft — the egress guard is the relevant control.")


def is_ransom_extension(path: str) -> bool:
    return os.path.splitext(path)[1].lower() in KNOWN_RANSOM_EXTS


def matches_recovery_inhibit(cmdline: str) -> str | None:
    """Return the matched reason if a command line is a recovery-inhibition
    (T1490) action, else None."""
    if not cmdline:
        return None
    for rx in _RECOVERY_INHIBIT_RES:
        if rx.search(cmdline):
            return f"recovery-inhibition command (T1490): {cmdline[:120]}"
    return None


def note_patterns() -> list[str]:
    return list(RANSOM_NOTE_PATTERNS)
