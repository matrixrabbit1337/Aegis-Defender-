& (Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) "install_windows.ps1") @args
