@echo off
setlocal
rem Double-click to remove Aegis Defender.
rem Asks for administrator rights, then runs the Aegis Defender installer script.
set "AEGIS_PS1=%~dp0windows\Install-Aegis.ps1"
if not exist "%AEGIS_PS1%" set "AEGIS_PS1=%~dp0install_windows.ps1"
if not exist "%AEGIS_PS1%" (
  echo The installer script was not found next to this file.
  echo Extract the whole ZIP first, then run this again.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%AEGIS_PS1%" -Uninstall %*
exit /b %errorlevel%
