import io
import os
from pathlib import Path
from unittest import mock
import tempfile
import unittest
import zipfile
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import upgrade_aegis as app


def fixture_archive(overrides=None):
    files = {
        "Aegis/aegis/agent.py": "import os\nrp = os.path.realpath(d)\n",
        "Aegis/aegis/gui.py": (
            "import time\n"
            "from datetime import datetime, timezone\n"
            "def _ts(epoch: float | None = None) -> str:\n"
            "    return datetime.fromtimestamp(epoch or time.time(),\n"
            "                                 tz=timezone.utc).strftime(\"%H:%M:%S\")\n"),
        "Aegis/install.sh": "#!/usr/bin/env bash\necho install\n",
        "Aegis/aegis/journal.py": "# baseline journal\n",
        "Aegis/README.md": "MIT licensed.\n",
        "Aegis/LICENSE": "MIT License\n",
        "Aegis/tests/test_journal.py": "def test_ok(): assert True\n",
    }
    # every anchored upstream snippet the kit patches, so the fixture
    # exercises the same patch list as the real archive
    for rel, before, _after in app.PATCHES:
        name = "Aegis/" + rel
        files[name] = files.get(name, "") + before
    files.update(overrides or {})
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w') as archive:
        for name, content in files.items():
            info = zipfile.ZipInfo(name)
            info.create_system = 3
            mode = 0o775 if name.endswith(".sh") else 0o664
            info.external_attr = (0o100000 | mode) << 16
            archive.writestr(info, content)
    return out.getvalue()


class UpgradeTests(unittest.TestCase):
    def test_assemble_output_with_expected_fixes(self):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / "improved.zip"
            app.upgrade(fixture_archive(), target)
            self.assertTrue(target.exists())
            with zipfile.ZipFile(target) as z:
                agent = z.read("Aegis/aegis/agent.py").decode()
                gui = z.read("Aegis/aegis/gui.py").decode()
                self.assertIn("os.path.realpath(os.path.expanduser(d))", agent)
                self.assertIn("epoch if epoch is not None else time.time()", gui)
                self.assertNotIn("timezone", gui)
                self.assertIn("Aegis/aegis/diagnostics.py", z.namelist())
                self.assertIn("Aegis/tests/test_review_regressions.py", z.namelist())
                self.assertIn("Aegis/aegis/fulldrive.py", z.namelist())
                self.assertIn("Aegis/tests/test_full_drive.py", z.namelist())
                for rel, _before, after in app.PATCHES:
                    self.assertIn(after, z.read("Aegis/" + rel).decode(), rel)
                self.assertTrue(z.testzip() is None)

    def test_archive_rejects_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            bad = fixture_archive({"Aegis/../../escaped.txt": "bad"})
            with self.assertRaisesRegex(ValueError, "Unsafe archive path"):
                app.clean_extract(bad, Path(d))

    def test_archive_rejects_duplicate_paths(self):
        with tempfile.TemporaryDirectory() as d:
            b = io.BytesIO()
            with zipfile.ZipFile(b, "w") as z:
                z.writestr("Aegis/README.md", "one")
                import warnings
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    z.writestr("Aegis/README.md", "two")
            with self.assertRaisesRegex(ValueError, "Duplicate archive path"):
                app.clean_extract(b.getvalue(), Path(d))

    def test_archive_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            b = io.BytesIO()
            with zipfile.ZipFile(b, "w") as z:
                inf = zipfile.ZipInfo("Aegis/aegis/agent.py")
                inf.create_system = 3
                inf.external_attr = (0o120777 << 16)
                z.writestr(inf, "/etc/passwd")
            with self.assertRaisesRegex(ValueError, "Symlink"):
                app.clean_extract(b.getvalue(), Path(d))

    def test_archive_refuses_unexpected_package(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError, "Not the expected"):
                app.clean_extract(self.only_readme_zip(), Path(d))

    @staticmethod
    def only_readme_zip():
        b = io.BytesIO()
        with zipfile.ZipFile(b, 'w') as z:
            z.writestr("Aegis/README.md", "test")
        return b.getvalue()

    def test_fails_safely_on_drifted_upstream_code(self):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / "improved.zip"
            with self.assertRaisesRegex(ValueError, "Patch mismatch"):
                app.upgrade(fixture_archive({"Aegis/aegis/agent.py": "# changed unexpectedly\n"}), target)
            self.assertFalse(target.exists())

    def test_blob_integrity_hash_uses_git_format(self):
        import hashlib
        content = b"hello world"
        digest = hashlib.sha1(b"blob 11\0" + content).hexdigest()
        self.assertEqual(app.git_blob_sha(content), digest)

    def test_no_output_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / "improved.zip"
            target.write_text("existing")
            with self.assertRaises(FileExistsError):
                app.upgrade(fixture_archive(), target)
            self.assertEqual(target.read_text(), "existing")

    def _build(self, d, **kw):
        target = Path(d) / "improved.zip"
        app.upgrade(fixture_archive(), target, **kw)
        return target

    def test_executable_bits_preserved_in_zip(self):
        with tempfile.TemporaryDirectory() as d:
            with zipfile.ZipFile(self._build(d)) as z:
                mode = lambda n: (z.getinfo(n).external_attr >> 16) & 0o777
                self.assertEqual(mode("Aegis/install.sh"), 0o755)
                self.assertEqual(mode("Aegis/run_diagnostics.sh"), 0o755)
                self.assertEqual(mode("Aegis/README.md"), 0o644)
                self.assertNotIn("Aegis/" + app.MODES_FILE, z.namelist())

    @unittest.skipIf(os.name == "nt", "POSIX permissions")
    def test_executable_bits_preserved_in_source_folder(self):
        with tempfile.TemporaryDirectory() as d:
            folder = Path(d) / "src"
            self._build(d, keep_source_folder=folder)
            self.assertTrue(os.access(folder / "install.sh", os.X_OK))
            self.assertTrue(os.access(folder / "run_diagnostics.sh", os.X_OK))
            self.assertFalse((folder / app.MODES_FILE).exists())

    def test_generated_line_endings_fixed_on_every_os(self):
        with tempfile.TemporaryDirectory() as d:
            with zipfile.ZipFile(self._build(d)) as z:
                for name in ("Aegis/run_diagnostics.sh", "Aegis/aegis/diagnostics.py",
                             "Aegis/tests/test_review_regressions.py"):
                    self.assertNotIn(b"\r\n", z.read(name), name)
                cmd = z.read("Aegis/Run_Diagnostics.cmd")
                self.assertEqual(cmd.count(b"\n"), cmd.count(b"\r\n"))

    def test_generated_modules_compile(self):
        with tempfile.TemporaryDirectory() as d:
            with zipfile.ZipFile(self._build(d)) as z:
                for name in ("Aegis/aegis/diagnostics.py", "Aegis/aegis/fulldrive.py",
                             "Aegis/tests/test_review_regressions.py",
                             "Aegis/tests/test_full_drive.py"):
                    compile(z.read(name), name, "exec")

    def test_archive_rejects_drive_letter_component(self):
        with tempfile.TemporaryDirectory() as d:
            bad = fixture_archive({"Aegis/D:evil.txt": "bad"})
            with self.assertRaisesRegex(ValueError, "Unsafe archive path"):
                app.clean_extract(bad, Path(d))

    def test_archive_rejects_case_only_duplicates(self):
        with tempfile.TemporaryDirectory() as d:
            bad = fixture_archive({"Aegis/readme.md": "shadow"})
            with self.assertRaisesRegex(ValueError, "Duplicate archive path"):
                app.clean_extract(bad, Path(d))

    def test_no_partial_output_when_copy_fails(self):
        with tempfile.TemporaryDirectory() as d:
            target = Path(d) / "improved.zip"
            folder = Path(d) / "src"
            with mock.patch.object(app.shutil, "copytree", side_effect=OSError("disk full")):
                with self.assertRaises(OSError):
                    app.upgrade(fixture_archive(), target, folder)
            self.assertFalse(target.exists())

    def test_cli_refuses_unverified_local_zip(self):
        with tempfile.TemporaryDirectory() as d:
            src = Path(d) / "Aegis_Defender.zip"
            src.write_bytes(fixture_archive())
            out = Path(d) / "out.zip"
            with self.assertRaises(SystemExit) as ctx, mock.patch("sys.stderr"):
                app.main(["--source", str(src), "--output", str(out)])
            self.assertEqual(ctx.exception.code, 1)
            self.assertFalse(out.exists())
            self.assertEqual(app.main(["--source", str(src), "--output", str(out),
                                       "--allow-modified-source"]), 0)
            self.assertTrue(out.exists())

    def test_every_patch_anchor_is_unique_and_required(self):
        # A patch whose anchor vanished upstream must stop the build.
        for rel, before, _after in app.PATCHES:
            name = "Aegis/" + rel
            files = {}
            for r2, b2, _a2 in app.PATCHES:
                n2 = "Aegis/" + r2
                files[n2] = files.get(n2, "") + (b2 if b2 != before else "")
            with tempfile.TemporaryDirectory() as d:
                with self.assertRaisesRegex(ValueError, "Patch mismatch"):
                    app.upgrade(fixture_archive({name: files[name]}), Path(d) / "x.zip")

    def test_build_ships_windows_installer_icon_and_launchers(self):
        with tempfile.TemporaryDirectory() as d:
            with zipfile.ZipFile(self._build(d)) as z:
                for rel, dest in app.KIT_FILES.items():
                    self.assertEqual(z.read("Aegis/" + dest), app.kit_file(rel), dest)
                compile(z.read("Aegis/aegis/launcher.py"), "launcher.py", "exec")
                ico = z.read("Aegis/aegis/assets/aegis.ico")
                self.assertEqual(ico[:4], b"\x00\x00\x01\x00")  # ICO header

    def test_build_has_no_extra_text_files(self):
        with tempfile.TemporaryDirectory() as d:
            src = fixture_archive({"Aegis/CHANGELOG.md": "# old notes\n"})
            target = Path(d) / "out.zip"
            app.upgrade(src, target)
            with zipfile.ZipFile(target) as z:
                names = z.namelist()
                readme = z.read("Aegis/README.md").decode("utf-8")
            self.assertNotIn("Aegis/CHANGELOG.md", names)
            self.assertNotIn("Aegis/REVIEWED_BUILD.md", names)
            docs = [n for n in names if n.count("/") == 1
                    and n.lower().endswith((".md", ".txt"))
                    and not n.lower().startswith("aegis/requirements")]
            self.assertEqual(docs, ["Aegis/README.md"])
            self.assertEqual(readme.count(app.README_MARKER), 1)

    def test_kit_itself_has_only_the_readme_as_text(self):
        texts = [p.relative_to(app.KIT_DIR).as_posix() for p in app.KIT_DIR.rglob("*")
                 if p.is_file() and p.suffix.lower() in (".md", ".txt")]
        self.assertEqual(texts, ["README.md"])

    def test_missing_kit_file_stops_the_build(self):
        with tempfile.TemporaryDirectory() as d, \
                mock.patch.object(app, "KIT_DIR", Path(d) / "nowhere"):
            with self.assertRaisesRegex(ValueError, "Kit file missing"):
                app.upgrade(fixture_archive(), Path(d) / "x.zip")
            self.assertFalse((Path(d) / "x.zip").exists())


if __name__ == "__main__":
    unittest.main()
