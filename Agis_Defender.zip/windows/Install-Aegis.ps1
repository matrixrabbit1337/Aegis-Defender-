<#
  Aegis Defender installer and uninstaller for Windows.

  Double-click Install_Aegis_Defender.bat or Uninstall_Aegis_Defender.bat
  instead of running this file directly. It asks for administrator rights,
  installs Python if needed, installs Aegis into Program Files with its own
  Python environment, and creates a desktop icon that runs as administrator.

  Works from two places:
    * the upgrade kit (windows\Install-Aegis.ps1): builds the reviewed Aegis
      package first (download, hash check, patches), then installs it
    * an Aegis source folder (install_windows.ps1 next to aegis\): installs it
#>
[CmdletBinding()]
param(
    [switch]$Uninstall,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'  # the progress bar makes downloads crawl

$AppName      = 'Aegis Defender'
$AppId        = 'AegisDefender'
$Publisher    = 'Rabbit1337'
$InstallDir   = Join-Path $env:ProgramFiles $AppName
$StageDir     = "$InstallDir.new"
$OldDir       = "$InstallDir.old"
$UninstallKey = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\$AppId"
$PyVersion    = '3.12.10'
$Here         = $PSScriptRoot

# -- output helpers ---------------------------------------------------------------

function Write-Step([string]$Text) {
    Write-Host ''
    Write-Host "==> $Text" -ForegroundColor Cyan
}
function Write-Info([string]$Text) { Write-Host "    $Text" }
function Write-Warn([string]$Text) { Write-Host "    WARNING: $Text" -ForegroundColor Yellow }

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($id)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Run a program, show its output, return its exit code. Native stderr is never
# redirected here: in Windows PowerShell 5.1 redirecting it while
# ErrorActionPreference is Stop turns the first warning into a fatal error.
function Invoke-Native([string]$Exe, [string[]]$Arguments) {
    $ErrorActionPreference = 'Continue'
    & $Exe @Arguments | Out-Host
    return $LASTEXITCODE
}

# Run a program and return its stdout lines (stderr discarded), or $null.
function Get-NativeOutput([string]$Exe, [string[]]$Arguments) {
    $ErrorActionPreference = 'Continue'
    try {
        $out = & $Exe @Arguments 2>$null
    } catch {
        return $null
    }
    if ($LASTEXITCODE -ne 0) { return $null }
    return @($out)
}

function Assert-Ok([int]$Code, [string]$Message) {
    if ($Code -ne 0) { throw "$Message (exit code $Code)" }
}

function Update-SessionPath {
    $machine = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user = [Environment]::GetEnvironmentVariable('Path', 'User')
    $env:Path = "$machine;$user"
}

# -- Python -----------------------------------------------------------------------

function Get-PythonInfo([string]$Exe, [string[]]$Prefix) {
    $code = "import sys, tkinter; print(sys.executable); print('%d.%d' % sys.version_info[:2])"
    $out = @(Get-NativeOutput $Exe ($Prefix + @('-c', $code)))
    if (-not $out -or $out.Count -lt 2) { return $null }
    $exe = "$($out[0])".Trim()
    $ver = "$($out[1])".Trim()
    # Skip the Microsoft Store alias / Store build: venvs made from it are fragile.
    if ($exe -match 'WindowsApps' -or -not (Test-Path -LiteralPath $exe)) { return $null }
    if ($ver -notmatch '^\d+\.\d+$') { return $null }
    $v = [version]$ver
    if ($v -lt [version]'3.10') { return $null }
    return [pscustomobject]@{ Exe = $exe; Version = $v }
}

function Find-Python {
    $found = @()
    foreach ($c in @(@('py', '-3'), @('python'), @('python3'))) {
        $prefix = @()
        if ($c.Count -gt 1) { $prefix = @($c[1..($c.Count - 1)]) }
        $info = Get-PythonInfo $c[0] $prefix
        if ($info) { $found += $info }
    }
    $patterns = @("$env:ProgramFiles\Python3*\python.exe")
    if ($env:LOCALAPPDATA) { $patterns += "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" }
    foreach ($pattern in $patterns) {
        foreach ($file in @(Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue)) {
            $info = Get-PythonInfo $file.FullName @()
            if ($info) { $found += $info }
        }
    }
    if ($found.Count -eq 0) { return $null }
    return $found | Sort-Object -Property Version -Descending | Select-Object -First 1
}

function Install-Python {
    Write-Info "No suitable Python found. Installing Python $PyVersion for all users..."
    if (Get-Command winget -ErrorAction SilentlyContinue) {
        $code = Invoke-Native 'winget' @('install', '--id', 'Python.Python.3.12', '-e',
            '--source', 'winget', '--scope', 'machine', '--silent',
            '--accept-package-agreements', '--accept-source-agreements')
        Update-SessionPath
        $py = Find-Python
        if ($py) { return $py }
        Write-Warn "winget did not provide a usable Python (exit code $code). Trying python.org."
    }
    $arch = 'amd64'
    if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $arch = 'arm64' }
    $url = "https://www.python.org/ftp/python/$PyVersion/python-$PyVersion-$arch.exe"
    $file = Join-Path $env:TEMP "python-$PyVersion-$arch.exe"
    [Net.ServicePointManager]::SecurityProtocol =
        [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    Write-Info "Downloading $url"
    Invoke-WebRequest -Uri $url -OutFile $file -UseBasicParsing
    $sig = Get-AuthenticodeSignature -FilePath $file
    if ($sig.Status -ne 'Valid' -or "$($sig.SignerCertificate.Subject)" -notmatch 'Python Software Foundation') {
        Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
        throw 'The downloaded Python installer failed its signature check; nothing was installed.'
    }
    $p = Start-Process -FilePath $file -Wait -PassThru -ArgumentList @(
        '/quiet', 'InstallAllUsers=1', 'PrependPath=1', 'Include_tcltk=1',
        'Include_pip=1', 'Include_launcher=1', 'Include_test=0')
    Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
    if ($p.ExitCode -ne 0) { throw "The Python installer failed (exit code $($p.ExitCode))." }
    Update-SessionPath
    $py = Find-Python
    if (-not $py) {
        throw ('Python was installed but no usable copy was found. If an existing Python ' +
               'lacks Tk, repair it with "tcl/tk and IDLE" ticked, then run this again.')
    }
    return $py
}

# -- running copies, shortcuts --------------------------------------------------------

function Stop-Aegis {
    $names = @('python.exe', 'pythonw.exe', 'aegis.exe')
    $procs = @(Get-CimInstance -ClassName Win32_Process -ErrorAction SilentlyContinue | Where-Object {
        $names -contains $_.Name.ToLower() -and $_.ProcessId -ne $PID -and (
            ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($InstallDir, [StringComparison]::OrdinalIgnoreCase)) -or
            ($_.CommandLine -and ($_.CommandLine.IndexOf($InstallDir, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
                                  $_.CommandLine -match '(?i)-m\s+aegis\b' -or
                                  ($_.Name -eq 'aegis.exe' -and $_.CommandLine -match '(?i)\b(gui|watch|launch)\b'))))
    })
    foreach ($p in $procs) {
        Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue
        Write-Info "Stopped running Aegis process $($p.ProcessId)"
    }
    if ($procs.Count -gt 0) { Start-Sleep -Seconds 2 }
}

function Get-ShortcutPaths {
    return @(
        (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) "$AppName.lnk"),
        (Join-Path ([Environment]::GetFolderPath('CommonPrograms')) "$AppName.lnk")
    )
}

function Remove-OldShortcuts {
    # Shortcuts made by the original Aegis Shield installer. Only removed when
    # they really point at Aegis, never an unrelated "Aegis.lnk".
    $shell = New-Object -ComObject WScript.Shell
    foreach ($folder in @('Desktop', 'Programs', 'CommonDesktopDirectory', 'CommonPrograms')) {
        $dir = [Environment]::GetFolderPath($folder)
        if (-not $dir) { continue }
        foreach ($name in @('Aegis Shield.lnk', 'Aegis.lnk')) {
            $lnk = Join-Path $dir $name
            if (-not (Test-Path -LiteralPath $lnk)) { continue }
            $target = $shell.CreateShortcut($lnk)
            $leaf = [IO.Path]::GetFileName("$($target.TargetPath)")
            if ($leaf -eq 'aegis.exe' -or "$($target.Arguments)" -match '(?i)\baegis\b') {
                Remove-Item -LiteralPath $lnk -Force
                Write-Info "Removed old shortcut: $lnk"
            }
        }
    }
}

function New-AppShortcut([string]$Path) {
    $shell = New-Object -ComObject WScript.Shell
    $lnk = $shell.CreateShortcut($Path)
    $lnk.TargetPath = Join-Path $InstallDir '.venv\Scripts\pythonw.exe'
    $lnk.Arguments = '-m aegis.launcher'
    $lnk.WorkingDirectory = $InstallDir
    $lnk.IconLocation = (Join-Path $InstallDir 'aegis\assets\aegis.ico') + ',0'
    $lnk.Description = 'Aegis Defender anti-ransomware dashboard'
    $lnk.Save()
    # "Run as administrator": LinkFlags at offset 0x14, RunAsUser = 0x00002000.
    $bytes = [IO.File]::ReadAllBytes($Path)
    $bytes[0x15] = [byte]($bytes[0x15] -bor 0x20)
    [IO.File]::WriteAllBytes($Path, $bytes)
}

# -- install ----------------------------------------------------------------------------

function Get-SourceDir([string]$WorkDir, $Python) {
    if (Test-Path -LiteralPath (Join-Path $Here 'aegis\agent.py')) { return $Here }
    $kit = Split-Path -Parent $Here
    $builder = Join-Path $kit 'upgrade_aegis.py'
    if (-not (Test-Path -LiteralPath $builder)) {
        throw "Neither an Aegis source folder nor the upgrade kit was found next to $PSCommandPath"
    }
    Write-Step 'Building the reviewed Aegis package (download, hash check, patches)'
    $zip = Join-Path $WorkDir 'Aegis_Defender_Improved.zip'
    $arguments = @($builder, '--output', $zip)
    $local = Join-Path $kit 'Aegis_Defender.zip'
    if (Test-Path -LiteralPath $local) {
        Write-Info "Using the local copy: $local"
        $arguments += @('--source', $local)
    }
    Assert-Ok (Invoke-Native $Python.Exe $arguments) ('Building the Aegis package failed. Check your ' +
        'internet connection, or put the original Aegis_Defender.zip next to this installer')
    Expand-Archive -LiteralPath $zip -DestinationPath $WorkDir -Force
    return (Join-Path $WorkDir 'Aegis')
}

function Get-AppVersion([string]$Src) {
    $line = Select-String -LiteralPath (Join-Path $Src 'pyproject.toml') -Pattern '^version\s*=\s*"([^"]+)"' |
        Select-Object -First 1
    if ($line) { return $line.Matches[0].Groups[1].Value }
    return '0'
}

function Register-Uninstaller([string]$Version) {
    $size = (Get-ChildItem -LiteralPath $InstallDir -Recurse -File -ErrorAction SilentlyContinue |
        Measure-Object -Property Length -Sum).Sum
    $script = Join-Path $InstallDir 'Uninstall-Aegis.ps1'
    New-Item -Path $UninstallKey -Force | Out-Null
    $values = @{
        DisplayName     = $AppName
        DisplayVersion  = $Version
        Publisher       = $Publisher
        InstallLocation = $InstallDir
        DisplayIcon     = (Join-Path $InstallDir 'aegis\assets\aegis.ico')
        UninstallString = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$script`" -Uninstall"
    }
    foreach ($k in $values.Keys) {
        New-ItemProperty -Path $UninstallKey -Name $k -Value $values[$k] -PropertyType String -Force | Out-Null
    }
    foreach ($k in @('NoModify', 'NoRepair')) {
        New-ItemProperty -Path $UninstallKey -Name $k -Value 1 -PropertyType DWord -Force | Out-Null
    }
    New-ItemProperty -Path $UninstallKey -Name 'EstimatedSize' -PropertyType DWord -Force `
        -Value ([int][math]::Ceiling($size / 1KB)) | Out-Null
}

function Install-Aegis {
    Write-Step 'Checking for Python 3.10 or newer (with Tk)'
    $py = Find-Python
    if (-not $py) { $py = Install-Python }
    Write-Info "Using Python $($py.Version): $($py.Exe)"

    $work = Join-Path $env:TEMP ('aegis-install-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    New-Item -ItemType Directory -Path $work | Out-Null
    try {
        $src = Get-SourceDir $work $py
        foreach ($need in @('aegis\agent.py', 'aegis\launcher.py', 'aegis\assets\aegis.ico',
                            'requirements.txt', 'README.md', 'pyproject.toml')) {
            if (-not (Test-Path -LiteralPath (Join-Path $src $need))) {
                throw "The Aegis package is incomplete: $need is missing"
            }
        }
        $version = Get-AppVersion $src

        Write-Step 'Stopping any running copy of Aegis'
        Stop-Aegis
        Remove-OldShortcuts

        Write-Step "Preparing $AppName $version"
        foreach ($d in @($StageDir, $OldDir)) {
            if (Test-Path -LiteralPath $d) { Remove-Item -LiteralPath $d -Recurse -Force }
        }
        New-Item -ItemType Directory -Path $StageDir | Out-Null
        Copy-Item -LiteralPath (Join-Path $src 'aegis') -Destination $StageDir -Recurse
        Get-ChildItem -LiteralPath $StageDir -Recurse -Directory -Filter '__pycache__' |
            Remove-Item -Recurse -Force
        foreach ($f in @('README.md', 'LICENSE')) {
            $path = Join-Path $src $f
            if (Test-Path -LiteralPath $path) { Copy-Item -LiteralPath $path -Destination $StageDir }
        }
        Copy-Item -LiteralPath $PSCommandPath -Destination (Join-Path $StageDir 'Uninstall-Aegis.ps1')
        $cmd = "@echo off`r`n`"%~dp0.venv\Scripts\python.exe`" -m aegis %*`r`n"
        [IO.File]::WriteAllText((Join-Path $StageDir 'aegis.cmd'), $cmd, [Text.Encoding]::ASCII)
        $diag = "@echo off`r`n`"%~dp0.venv\Scripts\python.exe`" -m aegis.diagnostics %*`r`npause`r`n"
        [IO.File]::WriteAllText((Join-Path $StageDir 'Run_Diagnostics.cmd'), $diag, [Text.Encoding]::ASCII)

        Write-Step 'Installing dependencies (this can take a few minutes)'
        $venv = Join-Path $StageDir '.venv'
        Assert-Ok (Invoke-Native $py.Exe @('-m', 'venv', $venv)) 'Creating the Python environment failed'
        $vpy = Join-Path $venv 'Scripts\python.exe'
        Assert-Ok (Invoke-Native $vpy @('-m', 'pip', 'install', '--disable-pip-version-check',
            '--no-input', '-r', (Join-Path $src 'requirements.txt'))) `
            'Installing dependencies failed (check your internet connection)'
        # Make the installed aegis package importable from the environment.
        [IO.File]::WriteAllText((Join-Path $venv 'Lib\site-packages\aegis-defender.pth'),
            "$InstallDir`r`n", [Text.Encoding]::ASCII)

        Write-Step 'Switching to the new version'
        if (Test-Path -LiteralPath $InstallDir) {
            try {
                Rename-Item -LiteralPath $InstallDir -NewName (Split-Path -Leaf $OldDir)
            } catch {
                throw "Could not replace $InstallDir (close any window or program using it): $_"
            }
        }
        Rename-Item -LiteralPath $StageDir -NewName $AppName

        $vpy = Join-Path $InstallDir '.venv\Scripts\python.exe'
        $check = @(Get-NativeOutput $vpy @('-c',
            'import aegis, aegis.gui, aegis.launcher, aegis.diagnostics; print(aegis.__file__)'))
        $expected = Join-Path $InstallDir 'aegis\__init__.py'
        $got = ''
        if ($check.Count -gt 0) { $got = "$($check[-1])".Trim() }
        if ($got -ne $expected) {
            Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction SilentlyContinue
            if (Test-Path -LiteralPath $OldDir) {
                Rename-Item -LiteralPath $OldDir -NewName $AppName
                Write-Warn 'The previous version was restored.'
            }
            throw "The installed copy failed its self-check (aegis loaded from: $got)"
        }
        if (Test-Path -LiteralPath $OldDir) { Remove-Item -LiteralPath $OldDir -Recurse -Force }
        Write-Info 'Self-check passed.'

        Write-Step 'Creating the desktop icon and Start menu entry'
        foreach ($lnk in Get-ShortcutPaths) {
            New-AppShortcut $lnk
            Write-Info $lnk
        }
        Register-Uninstaller $version

        Write-Step 'Checking the installation'
        Invoke-Native $vpy @('-m', 'aegis.diagnostics') | Out-Null

        $other = Get-Command aegis -ErrorAction SilentlyContinue
        if ($other -and -not $other.Source.StartsWith($InstallDir, [StringComparison]::OrdinalIgnoreCase)) {
            Write-Warn "An older 'aegis' command is still on PATH ($($other.Source)). Use the desktop icon or `"$InstallDir\aegis.cmd`"."
        }
    } finally {
        Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue
    }

    Write-Host ''
    Write-Host "  $AppName $version is installed." -ForegroundColor Green
    Write-Host "  Desktop icon: $AppName (runs as administrator)"
    Write-Host "  Program:      $InstallDir"
    Write-Host "  Settings and incidents: $env:LOCALAPPDATA\Aegis"
    Write-Host "  Remove it from Settings > Apps, or with Uninstall_Aegis_Defender.bat."
    if (-not $Quiet) {
        $answer = Read-Host 'Start Aegis Defender now? [Y/n]'
        if ($answer -notmatch '^[Nn]') {
            Start-Process -FilePath (Join-Path $InstallDir '.venv\Scripts\pythonw.exe') `
                -ArgumentList @('-m', 'aegis.launcher') -WorkingDirectory $InstallDir
        }
    }
}

# -- uninstall ----------------------------------------------------------------------

function Uninstall-Aegis {
    Write-Step "Removing $AppName"
    Stop-Aegis
    foreach ($lnk in Get-ShortcutPaths) {
        if (Test-Path -LiteralPath $lnk) { Remove-Item -LiteralPath $lnk -Force; Write-Info "Removed $lnk" }
    }
    foreach ($d in @($InstallDir, $StageDir, $OldDir)) {
        if (Test-Path -LiteralPath $d) { Remove-Item -LiteralPath $d -Recurse -Force; Write-Info "Removed $d" }
    }
    if (Test-Path -Path $UninstallKey) { Remove-Item -Path $UninstallKey -Recurse -Force }
    $data = Join-Path $env:LOCALAPPDATA 'Aegis'
    if (Test-Path -LiteralPath $data) {
        $remove = $false
        if (-not $Quiet) {
            $answer = Read-Host "Also delete settings, incident history and file snapshots in $data ? [y/N]"
            $remove = $answer -match '^[Yy]'
        }
        if ($remove) {
            Remove-Item -LiteralPath $data -Recurse -Force
            Write-Info "Removed $data"
        } else {
            Write-Info "Kept your settings and snapshots in $data"
        }
    }
    Write-Host ''
    Write-Host "  $AppName has been removed." -ForegroundColor Green
}

# -- main ----------------------------------------------------------------------------

if (-not (Test-Admin)) {
    $relaunch = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $PSCommandPath))
    if ($Uninstall) { $relaunch += '-Uninstall' }
    if ($Quiet) { $relaunch += '-Quiet' }
    try {
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $relaunch
    } catch {
        Write-Host 'Administrator rights are required. Nothing was changed.' -ForegroundColor Red
        if (-not $Quiet) { Read-Host 'Press Enter to close' | Out-Null }
        exit 1
    }
    exit 0
}

$exitCode = 0
# Neutral working folder: "python -c" imports from the current folder first,
# so running from a folder that contains aegis\ would fool the self-check.
Set-Location -LiteralPath $env:TEMP
try {
    if ($Uninstall) { Uninstall-Aegis } else { Install-Aegis }
} catch {
    Write-Host ''
    Write-Host "  FAILED: $($_.Exception.Message)" -ForegroundColor Red
    $exitCode = 1
} finally {
    if (-not $Quiet) {
        Write-Host ''
        Read-Host 'Press Enter to close' | Out-Null
    }
}
exit $exitCode
