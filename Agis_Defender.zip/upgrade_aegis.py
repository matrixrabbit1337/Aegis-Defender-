#!/usr/bin/env python3
"""Create a reviewed Aegis Defender source distribution from the original ZIP.

Never overwrites the original ZIP or the live installed agent. Uses only the
standard library. The expected upstream revision is pinned to a verified commit.
"""
from __future__ import annotations

import argparse
import ast
import io
import hashlib
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import tempfile
import urllib.request
import zipfile

COMMIT = "7422ee2d1d06288626120715496a7935e5d11825"
SOURCE_URL = (
    "https://raw.githubusercontent.com/matrixrabbit1337/Aegis-Defender-/"
    f"{COMMIT}/Aegis_Defender.zip"
)
EXPECTED_BLOB_SHA = "6459addb7d7dde0bf895666699ce912fc5e8d90e"
MAX_ARCHIVE_BYTES = 8 * 1024 * 1024
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_UNPACKED_BYTES = 32 * 1024 * 1024
MAX_ENTRIES = 512
MODES_FILE = ".aegis_kit_modes"
KIT_DIR = Path(__file__).resolve().parent
# kit file -> where it goes in the reviewed build
KIT_FILES = {
    "windows/Install-Aegis.ps1": "install_windows.ps1",
    "windows/aegis.ico": "aegis/assets/aegis.ico",
    "Install_Aegis_Defender.bat": "Install_Aegis_Defender.bat",
    "Uninstall_Aegis_Defender.bat": "Uninstall_Aegis_Defender.bat",
}
README_MARKER = "## This build: reviewed release"


def kit_file(rel: str) -> bytes:
    path = KIT_DIR / rel
    if not path.is_file():
        raise ValueError("Kit file missing: " + rel + " (extract the whole kit ZIP)")
    return path.read_bytes()
GENERATED_MODES = {"run_diagnostics.sh": 0o755}

# --- BEGIN EMBEDDED SOURCES (generated) ---
DIAGNOSTICS_MODULE = r'''"""Read-only local diagnostics for Aegis Defender.

Never kills processes and never writes files. It uses the agent's own config
loader and protected-folder rules, so what it reports is what the agent will
actually do with your configuration.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import stat
import sys
import types

DEPENDENCIES = {"yaml": "PyYAML", "psutil": "psutil", "watchdog": "watchdog",
                "customtkinter": "CustomTkinter", "cryptography": "cryptography"}


def _agent_class():
    try:
        from aegis.agent import AegisAgent
        return AegisAgent
    except Exception:  # runtime dependencies missing; reported separately
        return None


def _is_fs_root(agent, path):
    if agent is not None:
        return agent._is_fs_root(path)
    rp = os.path.realpath(path)
    if rp == os.path.abspath(os.sep):
        return True
    drive, rest = os.path.splitdrive(rp)
    return bool(drive) and rest in (os.sep, "/", "")


def _auto_dirs(agent, plat):
    if agent is not None:
        fake = types.SimpleNamespace(plat=plat)
        return (list(agent._auto_protect_dirs(fake)),
                list(agent._auto_watch_dirs(fake)))
    return [], [os.path.expanduser("~")]


def _check_protected(cfg, plat, put):
    agent = _agent_class()
    raw = list(cfg.get("protected_dirs") or [])
    watch = list(cfg.get("watch_only_dirs") or [])
    if not raw or raw == ["auto"]:
        dirs, auto_watch = _auto_dirs(agent, plat)
        watch += auto_watch
        put("Protected folders", "ok",
            "automatic full-drive mode (" + ("empty list" if not raw else "'auto'") +
            "): " + str(len(dirs)) + " rollback folder(s), " +
            str(len(auto_watch)) + " watch-only location(s)")
        put("CLI compatibility", "warning",
            "`aegis watch` and `aegis seed-canaries` need explicit folders "
            "and will refuse this configuration")
    else:
        if "auto" in raw:
            put("Protected folder 'auto'", "warning",
                "'auto' only works on its own; mixed with other folders it is "
                "ignored, so only the listed folders are protected")
        dirs = [d for d in raw if d != "auto"]

    allow = bool(cfg.get("allow_dangerous_dirs"))
    seen = set()
    rollback = 0
    for d in dirs:
        rp = os.path.realpath(os.path.expanduser(d))
        if rp in seen:
            continue
        seen.add(rp)
        name = "Rollback folder: " + rp
        if not os.path.isdir(rp):
            put(name, "warning", "does not exist; the agent will skip it")
            continue
        rollback += 1
        if _is_fs_root(agent, rp):
            put(name, "error", "drive or filesystem root cannot be snapshotted; "
                "the agent refuses to start. Move it to watch_only_dirs")
        elif plat.is_dangerous(rp) and not allow:
            put(name, "error", "home/system folder and allow_dangerous_dirs is "
                "false; the agent refuses to start")
        elif plat.is_dangerous(rp):
            put(name, "ok", "home/system folder (allowed by allow_dangerous_dirs); "
                "the whole folder is copied at every start")
        else:
            put(name, "ok", "snapshotted at start, restored after an attack")

    watched = 0
    for d in watch:
        rp = os.path.realpath(os.path.expanduser(d))
        if rp in seen:
            continue
        seen.add(rp)
        name = "Watch-only location: " + rp
        if not os.path.isdir(rp):
            put(name, "warning", "does not exist; the agent will skip it")
            continue
        watched += 1
        put(name, "ok", "detect + contain, no snapshot (recover from OS "
            "snapshots or backups)")

    if not rollback and not watched:
        put("Protected folders", "error",
            "no configured folder exists; nothing would be protected")
    elif not rollback:
        put("Rollback tier", "warning", "empty: attacks can be detected and "
            "stopped, but no files can be restored by Aegis")


def _check_state(state, put):
    if not os.path.exists(state):
        put("State directory", "warning", "Not created yet: " + state)
        return
    if not os.path.isdir(state):
        put("State directory", "error", "Path is not a directory: " + state)
        return
    access = os.access(state, os.R_OK | os.W_OK)
    put("State directory", "ok" if access else "warning",
        state + (" (accessible)" if access else " (not readable/writable)"))
    if os.name != "nt":
        mode = stat.S_IMODE(os.stat(state).st_mode)
        if mode & 0o077:
            put("State permissions", "warning", f"Mode {mode:04o}; consider chmod 700")


def audit(config_path=None):
    checks = []

    def put(name, status, detail):
        checks.append({"name": name, "status": status, "detail": detail})

    put("Python", "ok" if sys.version_info >= (3, 10) else "error",
        sys.version.split()[0] + " (3.10+ required)")
    put("Platform", "ok", platform.system() + " " + platform.release())
    for module, package in DEPENDENCIES.items():
        found = importlib.util.find_spec(module) is not None
        put("Dependency: " + package, "ok" if found else "warning",
            "installed" if found else "not importable; run your platform installer")

    try:
        from aegis import config as aegis_config
        from aegis.platforms import get_platform
        plat = get_platform()
    except Exception as exc:
        put("Aegis package", "error", "cannot import aegis: " + type(exc).__name__ + ": " + str(exc))
        return _summary(checks)

    path = os.path.expanduser(str(config_path)) if config_path else plat.default_config_path()
    cfg = None
    if not os.path.exists(path):
        put("Configuration", "warning", "Not found: " + path + "; run `aegis setup` or open the GUI")
    elif not os.path.isfile(path):
        put("Configuration", "error", "Not a file: " + path)
    elif importlib.util.find_spec("yaml") is None:
        put("Configuration", "warning", path + " exists but PyYAML is missing, so it cannot be checked")
    else:
        try:
            cfg = aegis_config.load_config(path)
            put("Configuration", "ok", path)
        except Exception as exc:
            put("Configuration", "error", type(exc).__name__ + ": " + str(exc))

    if cfg is not None:
        _check_protected(cfg, plat, put)
    state = cfg["state_dir"] if cfg else plat.default_state_dir()
    _check_state(os.path.realpath(os.path.expanduser(state)), put)
    return _summary(checks)


def _summary(checks):
    statuses = {c["status"] for c in checks}
    overall = "error" if "error" in statuses else "warning" if "warning" in statuses else "ok"
    return {"status": overall, "checks": checks}


def main(argv=None):
    parser = argparse.ArgumentParser(description="Read-only Aegis preflight checks")
    parser.add_argument("--config", help="Alternate config YAML path")
    parser.add_argument("--json", action="store_true", help="Machine-readable output")
    args = parser.parse_args(argv)
    report = audit(args.config)
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print("AEGIS DEFENDER - READ-ONLY DIAGNOSTICS")
        print("=" * 45)
        for check in report["checks"]:
            print("[{status:7}] {name}: {detail}".format(**check))
        print("Overall:", report["status"].upper())
    return int(report["status"] == "error")


if __name__ == "__main__":
    raise SystemExit(main())
'''

REGRESSION_TESTS = r'''"""Review-kit regressions. These tests are deliberately non-destructive."""
import ast
from datetime import datetime
import os
from pathlib import Path
import time

from aegis import diagnostics

ROOT = Path(__file__).resolve().parents[1]


def _load_ts(namespace):
    text = (ROOT / "aegis" / "gui.py").read_text(encoding="utf-8")
    module = ast.parse(text)
    function = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == "_ts")
    exec(compile(ast.Module(body=[function], type_ignores=[]), "aegis/gui.py", "exec"), namespace)
    return namespace["_ts"]


def test_home_directory_expansion_in_agent():
    source = (ROOT / "aegis" / "agent.py").read_text(encoding="utf-8")
    assert "os.path.realpath(os.path.expanduser(d))" in source


def test_timestamp_zero_is_not_replaced_by_now():
    seen = []

    class StubDatetime:
        @staticmethod
        def fromtimestamp(epoch, *args, **kwargs):
            seen.append(epoch)
            return datetime(2000, 1, 1)

    class NoClock:
        @staticmethod
        def time():
            raise AssertionError("time.time() must not be used for epoch 0")

    _load_ts({"datetime": StubDatetime, "time": NoClock})(0)
    assert seen == [0]


def test_timestamp_uses_local_time():
    ts = _load_ts({"datetime": datetime, "time": time})
    assert ts(1_000_000) == datetime.fromtimestamp(1_000_000).strftime("%H:%M:%S")
    assert len(ts()) == 8


def _audit(tmp_path, body):
    cfg = tmp_path / "config.yaml"
    cfg.write_text(body + "\nstate_dir: " + str(tmp_path / "state") + "\n", encoding="utf-8")
    report = diagnostics.audit(cfg)
    return report, {c["name"]: c for c in report["checks"]}


def test_diagnostics_missing_configuration(tmp_path):
    result = diagnostics.audit(tmp_path / "missing.yaml")
    assert result["status"] in ("ok", "warning")
    assert any(item["name"] == "Configuration" for item in result["checks"])


def test_diagnostics_accepts_what_loader_accepts(tmp_path, monkeypatch):
    target = tmp_path / "data"
    target.mkdir()
    monkeypatch.setenv("AEGIS_TEST_DIR", str(target))
    report, checks = _audit(tmp_path, "protected_dirs: $AEGIS_TEST_DIR")
    assert checks["Configuration"]["status"] == "ok"
    assert checks["Rollback folder: " + os.path.realpath(target)]["status"] == "ok"


def test_diagnostics_warns_auto_mixed_with_folders(tmp_path):
    target = tmp_path / "data"
    target.mkdir()
    report, checks = _audit(tmp_path, "protected_dirs: [auto, '" + str(target) + "']")
    assert checks["Protected folder 'auto'"]["status"] == "warning"


def test_diagnostics_flags_drive_root_as_fatal(tmp_path):
    root = Path(os.path.realpath(tmp_path)).anchor
    report, checks = _audit(tmp_path, "protected_dirs: ['" + root.replace("\\", "/") + "']")
    assert report["status"] == "error"


def test_package_license_matches_readme():
    license_text = (ROOT / "LICENSE").read_text(encoding="utf-8")
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert license_text.startswith("MIT License")
    assert "MIT" in readme


def _run_launcher(tmp_path, monkeypatch, cli_main):
    import sys
    from aegis import cli, launcher
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path))
    shown = []
    monkeypatch.setattr(launcher, "show_error", shown.append)
    monkeypatch.setattr(cli, "main", cli_main)
    monkeypatch.setattr(sys, "stdout", None)  # as under pythonw.exe
    monkeypatch.setattr(sys, "stderr", None)
    try:
        code = launcher.main()
    finally:
        if sys.stdout is not None:
            sys.stdout.close()
    log = tmp_path / "Aegis" / "gui.log"
    return code, shown, log.read_text(encoding="utf-8") if log.exists() else ""


def test_launcher_shows_startup_crash_and_logs_it(tmp_path, monkeypatch):
    def boom(argv):
        raise ImportError("No module named 'customtkinter'")
    code, shown, log = _run_launcher(tmp_path, monkeypatch, boom)
    assert code == 1
    assert "customtkinter" in shown[0] and "gui.log" in shown[0]
    assert "Traceback" in log and "customtkinter" in log


def test_launcher_reports_error_exit(tmp_path, monkeypatch):
    def fail(argv):
        print("error: protected dir does not exist")
        return 1
    code, shown, log = _run_launcher(tmp_path, monkeypatch, fail)
    assert code == 1 and "exit code 1" in shown[0]
    assert "protected dir does not exist" in log


def test_launcher_clean_exit_is_silent(tmp_path, monkeypatch):
    seen = []

    def ok(argv):
        seen.append(argv)
        return 0
    code, shown, _log = _run_launcher(tmp_path, monkeypatch, ok)
    assert code == 0 and shown == [] and seen == [["gui"]]
'''

FULLDRIVE_MODULE = r'''"""Full-drive mode: hybrid protection (rollback tier + watch-only tier).

protected_dirs   ROLLBACK tier. Snapshotted when the agent starts and restored
                 byte-for-byte after an attack. Copying costs disk and time,
                 so this is your important folders, not whole drives.
watch_only_dirs  DETECTION tier. Watched for ransomware behaviour and the
                 attacker is suspended/killed, but nothing is copied, so whole
                 drives are affordable. Recovery there relies on OS snapshots
                 (shadow copies / Time Machine) and your own backups.

Inside the watch-only tier, noisy system/cache locations are ignored (see
WatchFilter) and writes are never blocked on entropy alone; only canaries and
known ransomware extensions are pre-blocked there.
"""
from __future__ import annotations

import ntpath
import os
import re
import string

# Top-level folders of the Windows system drive that are never watched.
WINDOWS_SKIP_TOP = {
    "windows", "program files", "program files (x86)", "programdata", "users",
    "documents and settings", "system volume information", "recovery",
    "perflogs", "config.msi", "msocache", "onedrivetemp",
}
# Path components ignored anywhere in the watch-only tier (high churn,
# compressed content, or OS bookkeeping; not what ransomware is after).
SKIP_COMPONENTS = {
    "$recycle.bin", "system volume information", ".git", "node_modules",
    "__pycache__", ".trashes", ".spotlight-v100", ".fseventsd",
    ".documentrevisions-v100", ".temporaryitems",
}
_PSEUDO_FS = {
    "proc", "sysfs", "tmpfs", "devtmpfs", "devpts", "cgroup", "cgroup2",
    "overlay", "squashfs", "autofs", "debugfs", "tracefs", "securityfs",
    "pstore", "bpf", "mqueue", "hugetlbfs", "configfs", "fusectl",
    "binfmt_misc", "efivarfs", "ramfs", "nsfs", "fuse.gvfsd-fuse",
    "fuse.portal",
}
_DRIVE_REMOVABLE, _DRIVE_FIXED = 2, 3


def under(path: str, root: str, sep: str = os.sep) -> bool:
    """True if ``path`` is ``root`` or inside it (both already normalised)."""
    base = root.rstrip(sep)
    return path == root or path == base or path.startswith(base + sep)


def is_fs_root(path: str) -> bool:
    rp = os.path.realpath(path)
    if rp == os.path.abspath(os.sep):
        return True
    drive, rest = os.path.splitdrive(rp)
    return bool(drive) and rest in (os.sep, "/", "")


# -- discovering what to watch ------------------------------------------------

def windows_drives() -> list[str]:
    """Fixed and removable drive roots. Network and optical drives are left
    out: watching a share sees only local writes and can stall on a slow link."""
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        mask = kernel32.GetLogicalDrives()
    except Exception:
        return []
    drives = []
    for i, letter in enumerate(string.ascii_uppercase):
        if not mask & (1 << i):
            continue
        root = letter + ":\\"
        try:
            kind = kernel32.GetDriveTypeW(ctypes.c_wchar_p(root))
        except Exception:
            continue
        if kind in (_DRIVE_REMOVABLE, _DRIVE_FIXED) and os.path.isdir(root):
            drives.append(root)
    return drives


def windows_watch(home: str, drives: list[str], system_drive: str,
                  listdir=os.listdir, isdir=os.path.isdir) -> list[str]:
    """Home, every non-system drive root, and the user-data folders at the top
    of the system drive. The system drive root itself is not watched: the OS
    writes there constantly and those folders are excluded anyway."""
    watch = [home]
    system = system_drive.rstrip("\\/").upper()
    for root in drives:
        if root.rstrip("\\/").upper() != system:
            watch.append(root)
            continue
        try:
            names = sorted(listdir(root))
        except OSError:
            continue
        for name in names:
            if name.lower() in WINDOWS_SKIP_TOP or name.startswith("$"):
                continue
            path = ntpath.join(root, name)
            if isdir(path):
                watch.append(path)
    return watch


def linux_mounts(mounts_text: str | None = None, isdir=os.path.isdir) -> list[str]:
    """Data volumes mounted under /mnt, /media or /run/media."""
    if mounts_text is None:
        try:
            with open("/proc/mounts", encoding="utf-8") as fh:
                mounts_text = fh.read()
        except OSError:
            return []
    found = []
    for line in mounts_text.splitlines():
        fields = line.split()
        if len(fields) < 3 or fields[2] in _PSEUDO_FS:
            continue
        point = re.sub(r"\\([0-7]{3})", lambda m: chr(int(m.group(1), 8)),
                       fields[1])
        if any(under(point, p, "/") for p in ("/mnt", "/media", "/run/media")):
            if point not in found:
                found.append(point)
    return [p for p in found if isdir(p)]


def macos_volumes() -> list[str]:
    out = []
    try:
        names = sorted(os.listdir("/Volumes"))
    except OSError:
        return out
    for name in names:
        path = os.path.join("/Volumes", name)
        if os.path.realpath(path) != "/" and os.path.isdir(path):
            out.append(path)
    return out


def layout(plat) -> tuple[list[str], list[str]]:
    """(protected_dirs, watch_only_dirs) for full-drive mode on this machine."""
    home = os.path.expanduser("~")
    protected = list(plat.user_folders())
    if plat.name == "windows":
        watch = windows_watch(home, windows_drives(),
                              os.environ.get("SystemDrive", "C:"))
    elif plat.name == "macos":
        watch = [home] + macos_volumes()
    else:
        watch = [home] + linux_mounts()
    seen, unique = set(), []
    for d in watch:
        key = plat.normcase(d)
        if key not in seen:
            seen.add(key)
            unique.append(d)
    return protected, unique


def apply_full_drive(cfg: dict, plat, layout_fn=layout) -> tuple[list, list]:
    """Turn on full-drive mode in a config dict (used by the GUI and CLI).

    Drive roots are moved out of protected_dirs (the agent refuses to snapshot
    them) into watch_only_dirs. Folders you chose yourself are kept."""
    protected, watch = layout_fn(plat)
    current = [d for d in (cfg.get("protected_dirs") or []) if d != "auto"]
    roots = [d for d in current if is_fs_root(d)]
    current = [d for d in current if d not in roots]
    for d in protected:
        if d not in current:
            current.append(d)
    watched = list(cfg.get("watch_only_dirs") or [])
    for d in roots + watch:
        if d not in watched:
            watched.append(d)
    cfg["protected_dirs"] = current
    cfg["watch_only_dirs"] = watched
    return current, watched


# -- noise filter for the watch-only tier --------------------------------------

class WatchFilter:
    """Decides which paths inside watch-only folders are ignored."""

    def __init__(self, plat, state_dir: str, extra=()):
        n = plat.normcase
        self._n = n
        home = os.path.expanduser("~")
        self.home = n(os.path.realpath(home))
        prefixes = [state_dir, *extra]
        for d in plat.dangerous_dirs():
            dn = n(os.path.realpath(d))
            # never exclude an ancestor of home (/Users, /root as $HOME, ...)
            if not under(self.home, dn):
                prefixes.append(d)
        if plat.name == "windows":
            prefixes.append(os.path.join(home, "AppData"))
        elif plat.name == "macos":
            prefixes.append(os.path.join(home, "Library"))
        self.prefixes = sorted({n(os.path.realpath(os.path.expanduser(p)))
                                for p in prefixes if p})

    def excluded(self, rp: str) -> bool:
        """``rp`` must already be realpath()'d and normcase()'d."""
        if any(under(rp, p) for p in self.prefixes):
            return True
        home = self.home.rstrip(os.sep) + os.sep
        if rp.startswith(home) and rp[len(home):].startswith("."):
            return True  # dot-folders in home: caches, toolchains, configs
        for part in rp.split(os.sep):
            low = part.lower()
            if low in SKIP_COMPONENTS or low.startswith(".trash"):
                return True
        return False
'''

FULLDRIVE_TESTS = r'''"""Full-drive mode: rollback tier + watch-only tier (review-kit tests)."""
import json
import os
import shutil
import subprocess
import sys
import time
import types
import uuid
from pathlib import Path

import pytest

from aegis import diagnostics, fulldrive
from aegis.agent import AegisAgent
from aegis.config import default_config, load_config
from aegis.events import Decision
from aegis.platforms import get_platform

ROOT = Path(__file__).resolve().parents[1]
FS_ROOT = os.path.abspath(os.sep)


def _cfg(tmp_path, protected=(), watch=(), **extra):
    cfg = default_config()
    cfg["protected_dirs"] = [str(p) for p in protected]
    cfg["watch_only_dirs"] = [str(p) for p in watch]
    cfg["state_dir"] = str(tmp_path / "state")
    cfg["sensor"]["mode"] = "userspace"
    cfg["recovery_guard"]["enabled"] = False
    cfg["egress"]["enabled"] = False
    cfg.update(extra)
    return cfg


def _dirs(tmp_path, *names):
    out = []
    for name in names:
        p = tmp_path / name
        p.mkdir(parents=True, exist_ok=True)
        out.append(p)
    return out


# -- layout ---------------------------------------------------------------------

def test_layout_never_puts_a_drive_root_in_the_rollback_tier(tmp_path, monkeypatch):
    home = tmp_path / "home"
    for name in ("Documents", "Desktop"):
        (home / name).mkdir(parents=True)
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("USERPROFILE", str(home))
    protected, watch = fulldrive.layout(get_platform())
    assert {Path(p).name for p in protected} == {"Documents", "Desktop"}
    assert not any(fulldrive.is_fs_root(p) for p in protected)
    assert os.path.realpath(watch[0]) == os.path.realpath(home)


def test_windows_layout_skips_system_folders_and_keeps_data_drives():
    names = ["Windows", "Program Files", "Users", "$Recycle.Bin", "ProgramData",
             "Data", "Games", "pagefile.sys"]
    watch = fulldrive.windows_watch(
        "C:\\Users\\me", ["C:\\", "D:\\"], "C:",
        listdir=lambda root: names, isdir=lambda p: not p.endswith(".sys"))
    assert watch == ["C:\\Users\\me", "C:\\Data", "C:\\Games", "D:\\"]


def test_linux_mounts_only_real_data_volumes():
    text = "\n".join([
        "/dev/sda1 / ext4 rw 0 0",
        "/dev/sdb1 /media/me/USB\\040Drive vfat rw 0 0",
        "/dev/sdc1 /mnt/data xfs rw 0 0",
        "tmpfs /mnt/ram tmpfs rw 0 0",
        "/dev/sdd1 /run/media/me/backup ext4 rw 0 0",
        "/dev/sde1 /srv ext4 rw 0 0",
    ])
    found = fulldrive.linux_mounts(text, isdir=lambda p: True)
    assert found == ["/media/me/USB Drive", "/mnt/data", "/run/media/me/backup"]


def test_apply_full_drive_moves_roots_out_of_rollback_tier(tmp_path):
    keep, = _dirs(tmp_path, "keep")
    cfg = {"protected_dirs": [str(keep), FS_ROOT, "auto"]}
    protected, watch = fulldrive.apply_full_drive(
        cfg, get_platform(), layout_fn=lambda plat: (["/p"], ["/w"]))
    assert protected == [str(keep), "/p"]
    assert watch == [FS_ROOT, "/w"]
    assert cfg["watch_only_dirs"] == watch


# -- scope ----------------------------------------------------------------------

def test_scope_tiers_and_noise_filter(tmp_path):
    prot, watch = _dirs(tmp_path, "prot", "watch")
    agent = AegisAgent(_cfg(tmp_path, [prot], [watch]))
    assert agent._scope(str(prot / "a.docx")) == "protected"
    assert agent._scope(str(watch / "a.docx")) == "watch"
    assert agent._scope(str(watch / "node_modules" / "x.js")) is None
    assert agent._scope(str(watch / "repo" / ".git" / "objects" / "ab")) is None
    assert agent._scope(str(tmp_path / "elsewhere.txt")) is None
    assert agent._scope(os.path.join(agent.state_dir, "x")) is None
    assert agent._in_scope(str(watch / "a.docx"))
    assert not agent._in_protected_scope(str(watch / "a.docx"))


def test_home_dot_folders_and_user_excludes_are_ignored(tmp_path, monkeypatch):
    home, = _dirs(tmp_path, "home")
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setenv("USERPROFILE", str(home))
    agent = AegisAgent(_cfg(tmp_path, watch=[home],
                            watch_only_exclude=[str(home / "build")]))
    assert agent._scope(str(home / ".cache" / "blob")) is None
    assert agent._scope(str(home / "build" / "out.bin")) is None
    assert agent._scope(str(home / "Projects" / "report.pdf")) == "watch"


def test_drive_root_is_accepted_in_watch_only_tier(tmp_path, monkeypatch):
    prot, = _dirs(tmp_path, "prot")
    agent = AegisAgent(_cfg(tmp_path, [prot], [FS_ROOT]))
    assert agent.watch_only_dirs == [FS_ROOT]

    class Reached(Exception):
        pass

    def stop_here(dirs):
        assert dirs == agent.protected_dirs  # only the rollback tier is copied
        raise Reached

    monkeypatch.setattr(agent.journal, "take_baseline", stop_here)
    with pytest.raises(Reached):  # passed the root/dangerous checks
        agent.start()


def test_drive_root_still_refused_in_rollback_tier(tmp_path):
    agent = AegisAgent(_cfg(tmp_path, [FS_ROOT]))
    with pytest.raises(RuntimeError, match="filesystem root"):
        agent.start()


def test_start_needs_at_least_one_existing_folder(tmp_path):
    agent = AegisAgent(_cfg(tmp_path, [tmp_path / "nope"], [tmp_path / "gone"]))
    with pytest.raises(RuntimeError, match="no existing folders"):
        agent.start()


# -- blocking and containment ---------------------------------------------------

def test_open_time_entropy_never_blocks_in_either_tier(tmp_path):
    # at permission time the file still holds its OLD content: a high reading
    # means "photo/archive", so it must never block on its own
    prot, watch = _dirs(tmp_path, "prot", "watch")
    agent = AegisAgent(_cfg(tmp_path, [prot], [watch]))
    kw = dict(pid=999999, exe=None, entropy=7.99, size=65536, canary=False,
              is_write=True)
    assert agent.quick_verdict(path=str(prot / "a.bin"), **kw) == Decision.ALLOW
    assert agent.quick_verdict(path=str(watch / "a.bin"), **kw) == Decision.ALLOW
    assert agent.quick_verdict(path=str(prot / "a.lockbit"),
                               **kw) == Decision.DENY
    assert agent.quick_verdict(path=str(watch / "a.lockbit"),
                               **kw) == Decision.DENY
    assert agent.quick_verdict(path=str(watch / "x"), pid=1, exe=None,
                               entropy=None, size=None, canary=True) == Decision.DENY


@pytest.mark.parametrize("contain, expect_alert_only", [(True, False), (False, True)])
def test_watch_only_contain_switch(tmp_path, contain, expect_alert_only):
    prot, watch = _dirs(tmp_path, "prot", "watch")
    agent = AegisAgent(_cfg(tmp_path, [prot], [watch], watch_only_contain=contain))
    seen = []
    agent.responder.handle_trigger = lambda pid, reasons, score, ctx: seen.append(ctx)
    event = types.SimpleNamespace(src=str(watch / "a.docx"), dest=None)
    agent._on_trigger(1234, ["test"], 99.0, {"event": event})
    assert bool(seen[0].get("alert_only")) is expect_alert_only
    # the rollback tier is always contained
    seen.clear()
    event = types.SimpleNamespace(src=str(prot / "a.docx"), dest=None)
    agent._on_trigger(1234, ["test"], 99.0, {"event": event})
    assert not seen[0].get("alert_only")


# -- sensor ---------------------------------------------------------------------

def test_sensor_watches_outermost_folders_only():
    from aegis.sensors.watchdog_sensor import _outermost
    n = get_platform().normcase
    a = os.path.join(FS_ROOT, "data")
    dirs = [os.path.join(a, "docs"), a, a, os.path.join(FS_ROOT, "other")]
    assert _outermost(dirs, n) == [a, os.path.join(FS_ROOT, "other")]


def test_unwatchable_watch_only_folder_falls_back_to_rollback_folders(tmp_path):
    from aegis.sensors.watchdog_sensor import WatchdogSensor
    home, = _dirs(tmp_path, "home")
    docs, = _dirs(home, "Documents")
    agent = AegisAgent(_cfg(tmp_path, [docs], [home]))
    sensor = WatchdogSensor(agent)
    real_schedule = sensor._obs.schedule
    scheduled = []

    def schedule(handler, path, recursive=True):
        if os.path.realpath(path) == os.path.realpath(home):
            raise OSError(28, "inotify watch limit reached")
        scheduled.append(path)
        return real_schedule(handler, path, recursive=recursive)

    sensor._obs.schedule = schedule
    try:
        sensor.start()
        assert sensor.unwatched == [str(Path(os.path.realpath(home)))]
        assert scheduled == [os.path.realpath(docs)]
    finally:
        sensor.stop()


def test_watcher_beside_kernel_sensor_ignores_rollback_tier(tmp_path):
    from aegis.sensors.watchdog_sensor import WatchdogSensor
    prot, watch = _dirs(tmp_path, "prot", "watch")
    agent = AegisAgent(_cfg(tmp_path, [prot], [watch]))
    seen = []
    agent.on_event = lambda ev: seen.append(ev.path)
    sensor = WatchdogSensor(agent, "watch")
    for path in (prot / "a.txt", watch / "b.txt"):
        path.write_text("x", encoding="utf-8")
        sensor._emit("modified", str(path))
    assert seen == [str(watch / "b.txt")]


def test_stop_really_stops_every_background_thread(tmp_path):
    import threading
    prot, = _dirs(tmp_path, "prot")
    before = {t.ident for t in threading.enumerate()}
    agent = AegisAgent(_cfg(tmp_path, [prot]))
    agent.start()
    agent.stop()
    deadline = time.time() + 5
    while time.time() < deadline:
        left = [t.name for t in threading.enumerate()
                if t.ident not in before and t.is_alive()
                and t.name in ("aegis-integrity", "aegis-procguard")]
        if not left:
            break
        time.sleep(0.2)
    assert not left, f"still running after stop(): {left}"


# -- config and diagnostics -----------------------------------------------------

def test_config_accepts_string_and_rejects_bad_watch_list(tmp_path):
    good = tmp_path / "good.yaml"
    good.write_text(f"watch_only_dirs: '{tmp_path.as_posix()}'\n", encoding="utf-8")
    assert load_config(good)["watch_only_dirs"] == [tmp_path.as_posix()]
    bad = tmp_path / "bad.yaml"
    bad.write_text("watch_only_dirs: 12\n", encoding="utf-8")
    with pytest.raises(RuntimeError, match="watch_only_dirs"):
        load_config(bad)


def test_diagnostics_reports_watch_only_root_as_ok(tmp_path):
    prot, = _dirs(tmp_path, "prot")
    cfg = tmp_path / "config.yaml"
    cfg.write_text(f"protected_dirs: ['{prot.as_posix()}']\n"
                   f"watch_only_dirs: ['{FS_ROOT.replace(chr(92), '/')}']\n"
                   f"state_dir: '{(tmp_path / 'state').as_posix()}'\n",
                   encoding="utf-8")
    report = diagnostics.audit(cfg)
    names = {c["name"]: c for c in report["checks"]}
    assert names["Watch-only location: " + FS_ROOT]["status"] == "ok"
    assert report["status"] != "error"


# -- end to end -------------------------------------------------------------------

def _wait_for_incident(state_dir: Path, timeout: float = 60):
    deadline = time.time() + timeout
    while time.time() < deadline:
        inc = state_dir / "incidents"
        if inc.is_dir():
            for entry in inc.iterdir():
                report = entry / "report.json"
                if report.exists():
                    return json.loads(report.read_text(encoding="utf-8"))
        time.sleep(0.5)
    return None


def _kernel_available():
    if not sys.platform.startswith("linux"):
        return False
    try:
        from aegis.sensors.fanotify_sensor import available
        return available()[0]
    except Exception:
        return False


@pytest.mark.parametrize("mode", [
    "userspace",
    pytest.param("kernel", marks=pytest.mark.skipif(
        not _kernel_available(), reason="fanotify needs Linux + root")),
])
def test_end_to_end_attack_in_watch_only_tier_is_stopped(tmp_path, mode):
    """The simulator attacks a folder that is watch-only (never snapshotted).
    Aegis must still detect it and contain the process, and the baseline must
    contain nothing from that folder."""
    import psutil
    sys.path.insert(0, str(ROOT))
    from simulator import SANDBOX_PREFIX
    sandbox = Path(f"{SANDBOX_PREFIX}watch-{uuid.uuid4().hex[:8]}")
    sandbox.mkdir(parents=True)
    prot, = _dirs(tmp_path, "prot")
    (prot / "keep.txt").write_text("rollback tier file", encoding="utf-8")
    try:
        for i in range(24):
            (sandbox / f"doc_{i:02d}.txt").write_bytes(
                (f"Document {i}: the quick brown fox. " * 1500).encode())
        cfg = _cfg(tmp_path, [prot], [sandbox])
        cfg["sensor"]["mode"] = mode
        agent = AegisAgent(cfg)
        baseline = agent.start()
        if mode == "kernel":
            assert "watch-only tier" in agent.sensor_mode
        time.sleep(2)
        proc = subprocess.Popen([sys.executable, str(ROOT / "simulator.py"),
                                 "--target", str(sandbox)],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            report = _wait_for_incident(tmp_path / "state")
            assert report is not None, "attack in watch-only tier not detected"
            if get_platform().supports_io_counters:
                deadline = time.time() + 30
                while time.time() < deadline:
                    try:
                        if "simulator" not in " ".join(psutil.Process(proc.pid).cmdline()):
                            break
                    except psutil.NoSuchProcess:
                        break
                    time.sleep(0.5)
                else:
                    pytest.fail("simulator in watch-only tier was NOT contained")
        finally:
            agent.stop()
            if proc.poll() is None:
                proc.kill()
                proc.wait()
        manifest = json.loads((tmp_path / "state" / "journal" / "baselines" /
                               baseline / "manifest.json").read_text(encoding="utf-8"))
        assert [os.path.realpath(d) for d in manifest["dirs"]] == [os.path.realpath(prot)]
        assert all(k.startswith("dir0/") for k in manifest["files"])
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)
'''

KERNEL_TESTS = r'''"""Kernel sensor scores WRITES (FAN_CLOSE_WRITE), never plain opens."""
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(not sys.platform.startswith("linux"),
                                reason="fanotify is Linux-only")

ROOT = Path(__file__).resolve().parents[1]


def _kernel_ok():
    try:
        from aegis.sensors.fanotify_sensor import available
        return available()[0]
    except Exception:
        return False


needs_kernel = pytest.mark.skipif(not _kernel_ok(),
                                  reason="needs root + fanotify")


def _cfg(tmp_path, protected, mode="kernel"):
    from aegis.config import default_config
    cfg = default_config()
    cfg["protected_dirs"] = [str(p) for p in protected]
    cfg["state_dir"] = str(tmp_path / "state")
    cfg["sensor"]["mode"] = mode
    cfg["recovery_guard"]["enabled"] = False
    cfg["egress"]["enabled"] = False
    return cfg


def _incidents(tmp_path):
    inc = tmp_path / "state" / "incidents"
    return [json.loads(r.read_text(encoding="utf-8"))
            for r in inc.glob("*/report.json")] if inc.exists() else []


# -- dispatch (no root needed) ----------------------------------------------

def test_close_write_is_scored_and_permission_events_are_answered(tmp_path):
    from aegis.agent import AegisAgent
    from aegis.sensors import fanotify_sensor as fs
    (tmp_path / "p").mkdir()
    sensor = fs.FanotifySensor(AegisAgent(_cfg(tmp_path, [tmp_path / "p"],
                                               "userspace")))
    calls = []
    sensor._notify_write = lambda fd, pid: calls.append(("write", pid))
    sensor._answer = lambda fd, pid, mask: calls.append(("perm", pid))

    def meta(mask, pid):
        return fs._META.pack(fs.FAN_EVENT_METADATA_LEN, fs.FANOTIFY_METADATA_VERSION,
                             0, fs.FAN_EVENT_METADATA_LEN, mask, -1, pid)

    sensor._consume(meta(fs.FAN_CLOSE_WRITE, 11) + meta(fs.FAN_OPEN_PERM, 22))
    assert calls == [("write", 11), ("perm", 22)]


def test_worker_reports_creations_and_modifications(tmp_path):
    from aegis.agent import AegisAgent
    from aegis.events import Decision, EventKind
    from aegis.sensors import fanotify_sensor as fs
    (tmp_path / "p").mkdir()
    agent = AegisAgent(_cfg(tmp_path, [tmp_path / "p"], "userspace"))
    seen = []
    agent.on_event = lambda ev: seen.append((ev.kind, ev.pid, ev.entropy)) or Decision.ALLOW
    sensor = fs.FanotifySensor(agent)
    worker = threading.Thread(target=sensor._work_loop, daemon=True)
    worker.start()
    sensor._work.put(("write", "/x/note.txt", 5, None, 1.0, 10, False, True))
    sensor._work.put(("write", "/x/doc.txt", 6, None, 7.9, 4096, False, False))
    sensor._work.put(None)
    worker.join(5)
    assert seen == [(EventKind.FILE_CREATE, 5, 1.0), (EventKind.FILE_MODIFY, 6, 7.9)]


# -- real kernel behaviour (root) ---------------------------------------------

@needs_kernel
def test_reading_many_photos_is_not_an_attack(tmp_path):
    from aegis.agent import AegisAgent
    pics = tmp_path / "Pictures"
    for year in ("2024", "2025", "2026"):
        (pics / year).mkdir(parents=True)
        for i in range(5):
            (pics / year / f"img{i}.jpg").write_bytes(os.urandom(200_000))
    agent = AegisAgent(_cfg(tmp_path, [pics]))
    agent.start()
    try:
        time.sleep(0.5)
        viewer = subprocess.run(
            [sys.executable, "-c",
             f"import glob\nfor f in sorted(glob.glob({str(pics)!r} + '/*/*.jpg')):\n"
             "    open(f, 'rb').read()\n"], timeout=60)
        time.sleep(2)
    finally:
        agent.stop()
    assert viewer.returncode == 0, "read-only viewer was killed"
    assert _incidents(tmp_path) == []


@needs_kernel
def test_writes_carry_exact_pid_new_content_and_creation(tmp_path):
    from aegis.agent import AegisAgent
    from aegis.events import Decision, EventKind
    docs = tmp_path / "Documents"
    docs.mkdir()
    (docs / "report.txt").write_text("plain text " * 500, encoding="utf-8")
    agent = AegisAgent(_cfg(tmp_path, [docs]))
    seen = []
    agent.on_event = lambda ev: seen.append(ev) or Decision.ALLOW
    agent.start()
    try:
        time.sleep(0.5)
        child = subprocess.Popen([sys.executable, "-c",
            f"import os, time\nopen({str(docs / 'report.txt')!r}, 'wb').write(os.urandom(8192))\n"
            f"open({str(docs / 'HOW_TO_RECOVER.txt')!r}, 'w').write('pay')\ntime.sleep(1)"])
        child.wait(10)
        time.sleep(1.5)
    finally:
        agent.stop()
    by_name = {Path(e.path).name: e for e in seen}
    assert by_name["report.txt"].kind == EventKind.FILE_MODIFY
    assert by_name["report.txt"].pid == child.pid
    assert by_name["report.txt"].entropy > 7.0  # the NEW bytes, not the old text
    assert by_name["HOW_TO_RECOVER.txt"].kind == EventKind.FILE_CREATE


@needs_kernel
def test_kernel_end_to_end_attack_detected_killed_rolled_back(tmp_path):
    import psutil
    from aegis.agent import AegisAgent
    from aegis.journal import Journal
    sys.path.insert(0, str(ROOT))
    from simulator import SANDBOX_PREFIX
    sandbox = Path(f"{SANDBOX_PREFIX}kw-{uuid.uuid4().hex[:8]}")
    sandbox.mkdir(parents=True)
    try:
        originals = {}
        for i in range(24):
            p = sandbox / f"doc_{i:02d}.txt"
            p.write_bytes((f"Document {i} quick brown fox. " * 1500).encode())
            originals[p] = p.read_bytes()
        cfg = _cfg(tmp_path, [sandbox])
        agent = AegisAgent(cfg)
        agent.start()
        time.sleep(1)
        proc = subprocess.Popen([sys.executable, str(ROOT / "simulator.py"),
                                 "--target", str(sandbox)],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            deadline = time.time() + 60
            while time.time() < deadline and not _incidents(tmp_path):
                time.sleep(0.3)
            reports = _incidents(tmp_path)
            assert reports, "kernel sensor never detected the attack"
            deadline = time.time() + 30
            while time.time() < deadline:
                try:
                    if "simulator" not in " ".join(psutil.Process(proc.pid).cmdline()):
                        break
                except psutil.NoSuchProcess:
                    break
                time.sleep(0.3)
            else:
                pytest.fail("simulator was NOT killed")
        finally:
            agent.stop()
            if proc.poll() is None:
                proc.kill()
                proc.wait()
        stats = Journal(cfg["state_dir"], cfg).rollback(reports[0]["id"])
        assert stats["failed"] == []
        for path, data in originals.items():
            assert path.read_bytes() == data, f"not restored: {path}"
    finally:
        shutil.rmtree(sandbox, ignore_errors=True)
'''

LAUNCHER_MODULE = r'''"""Desktop-icon entry point on Windows: ``pythonw -m aegis.launcher``.

Starts the dashboard without a console window. Anything the agent prints goes
to a log file, and a startup failure is shown in a message box instead of the
icon silently doing nothing.
"""
from __future__ import annotations

import os
import sys
import traceback

LOG_MAX_BYTES = 5 * 1024 * 1024


def log_path() -> str:
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "Aegis", "gui.log")


def _open_log():
    path = log_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.exists(path) and os.path.getsize(path) > LOG_MAX_BYTES:
            os.replace(path, path + ".1")
        return open(path, "a", encoding="utf-8", buffering=1), path
    except OSError:
        return None, None


def show_error(text: str) -> None:
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, "Aegis Defender", 0x10)
    except Exception:  # not Windows, or no desktop session
        print(text, file=sys.stderr or sys.stdout)


def main() -> int:
    log, path = None, None
    if sys.stdout is None or sys.stderr is None:  # pythonw: no console
        log, path = _open_log()
        if log is not None:
            sys.stdout = sys.stderr = log
    where = path or log_path()
    try:
        from aegis.cli import main as cli_main
        code = cli_main(["gui"])
    except SystemExit as exc:
        code = exc.code
    except BaseException as exc:
        traceback.print_exc()
        show_error(f"Aegis Defender could not start:\n\n{exc}\n\n"
                   f"Details: {where}")
        return 1
    if code in (0, None):
        return 0
    detail = code if isinstance(code, str) else f"exit code {code}"
    show_error(f"Aegis Defender stopped with an error ({detail}).\n\n"
               f"Details: {where}")
    return code if isinstance(code, int) else 1


if __name__ == "__main__":
    raise SystemExit(main())
'''

README_SECTION = r'''
---

## This build: reviewed release (November 2026)

Built by the Aegis upgrade kit from `Aegis_Defender.zip` at pinned commit
`7422ee2d1d06288626120715496a7935e5d11825` of `matrixrabbit1337/Aegis-Defender-`.
The download is hash-checked and the original archive is never modified.

### Install on Windows

Double-click **Install_Aegis_Defender.bat** and approve the administrator
prompt. The installer:

- installs Python 3.12 if no Python 3.10+ with Tk is present (winget, or the
  python.org installer after checking its digital signature);
- installs Aegis into `C:\Program Files\Aegis Defender` with its own Python
  environment and all dependencies;
- creates an **Aegis Defender** desktop icon and Start menu entry that run as
  administrator, and an entry under Settings > Apps for removal.

Run it again to update. Settings, incidents and file snapshots are kept in
`%LOCALAPPDATA%\Aegis`. **Uninstall_Aegis_Defender.bat** removes the program
and asks before deleting that data. The dashboard log is
`%LOCALAPPDATA%\Aegis\gui.log`. From a terminal:
`"C:\Program Files\Aegis Defender\aegis.cmd" status`; health check:
`Run_Diagnostics.cmd` in the install folder.

Linux and macOS: `./install.sh` as before.

### What changed

- **Full-drive mode is hybrid.** The *rollback tier* (`protected_dirs`:
  Documents, Desktop, Pictures and folders you add) is snapshotted at start
  and restored after an attack. The *watch-only tier* (`watch_only_dirs`: home
  folder and every local drive) is watched and the attacker is stopped, but
  nothing is copied: recover those files from shadow copies, Time Machine or
  backups. Noisy locations are skipped there (system folders, AppData,
  dot-folders, `.git`, `node_modules`, recycle bins, `watch_only_exclude`);
  `watch_only_contain: false` makes that tier alert-only.
- **Windows full-drive and auto mode start again.** They used to put drive
  roots (`C:\`, `D:\`) into `protected_dirs`, which the agent refuses.
- **Linux kernel sensor scores real writes, not file opens,** so programs that
  only read photos or archives are no longer frozen and killed.
- **Stop protection really stops** the integrity monitor and process guard.
- Home-folder (`~`) paths expand correctly; dashboard times show local time;
  `python -m aegis.diagnostics` reports exactly what the agent will do with
  your configuration.

### Limits

This is a hardening pass, not a security certification. Windows and macOS
containment still needs testing on real machines. A tool that rewrites many
compressed files across several folders within a minute (batch photo or
archive editing) can look like encryption: add it to `trusted_processes`, or
try new setups with `dry_run: true` under `response:` first. Rollback restores the snapshot, so
preview with `aegis rollback --since <incident-id> --dry-run` before restoring.
'''

# Anchored patches (before text verified against the pinned upstream).
PATCHES = [
    ('aegis/agent.py',
     'from .canary import CanaryManager\n',
     'from .canary import CanaryManager\nfrom .fulldrive import WatchFilter, layout as full_drive_layout, under\n'),
    ('aegis/agent.py',
     '        raw_dirs = config["protected_dirs"]\n        if not raw_dirs or raw_dirs == ["auto"]:\n            raw_dirs = self._auto_protect_dirs()\n',
     '        raw_dirs = config["protected_dirs"]\n        raw_watch = list(config.get("watch_only_dirs") or [])\n        if not raw_dirs or raw_dirs == ["auto"]:\n            raw_dirs = self._auto_protect_dirs()\n            raw_watch += self._auto_watch_dirs()\n'),
    ('aegis/agent.py',
     '                self.protected_dirs.append(rp)\n',
     '                self.protected_dirs.append(rp)\n        # Watch-only tier (full-drive mode): detect + contain, no snapshot.\n        self.watch_only_dirs = []\n        for d in raw_watch:\n            rp = os.path.realpath(os.path.expanduser(d))\n            if rp not in seen and os.path.isdir(rp):\n                seen.add(rp)\n                self.watch_only_dirs.append(rp)\n        self.watch_filter = WatchFilter(\n            self.plat, self.state_dir, config.get("watch_only_exclude") or [])\n'),
    ('aegis/agent.py',
     '    def _auto_protect_dirs(self) -> list[str]:\n        """Auto-detect directories to protect: the user\'s home folder and\n        any additional data drives. Excludes system dirs the OS needs."""\n        home = os.path.expanduser("~")\n        dirs = [home]\n        # On Windows, also check for D:\\, E:\\ etc. data drives\n        if self.plat.name == "windows":\n            import string\n            for letter in string.ascii_uppercase:\n                drive = f"{letter}:\\\\"\n                if os.path.isdir(drive) and drive.upper() not in ("C:\\\\",):\n                    dirs.append(drive)\n        return dirs\n\n    # -- scope -------------------------------------------------------------\n    def _in_scope(self, path: str) -> bool:\n        n = self.plat.normcase\n        rp = n(os.path.realpath(path))\n        state = n(self.state_dir)\n        if rp == state or rp.startswith(state + os.sep):\n            return False\n        return any(rp == n(d) or rp.startswith(n(d) + os.sep)\n                   for d in self.protected_dirs)\n',
     '    def _auto_protect_dirs(self) -> list[str]:\n        """Auto mode is full-drive mode. This is the rollback tier (your user\n        data folders); home and drive roots go to the watch-only tier because\n        start() refuses to snapshot a drive root."""\n        return full_drive_layout(self.plat)[0]\n\n    def _auto_watch_dirs(self) -> list[str]:\n        return full_drive_layout(self.plat)[1]\n\n    # -- scope -------------------------------------------------------------\n    def _scope(self, path: str):\n        """\'protected\' (rollback tier), \'watch\' (watch-only tier) or None."""\n        n = self.plat.normcase\n        rp = n(os.path.realpath(path))\n        state = n(self.state_dir)\n        if rp == state or rp.startswith(state + os.sep):\n            return None\n        if any(under(rp, n(d)) for d in self.protected_dirs):\n            return "protected"\n        watch = getattr(self, "watch_only_dirs", None)\n        if (watch and any(under(rp, n(d)) for d in watch)\n                and not self.watch_filter.excluded(rp)):\n            return "watch"\n        return None\n\n    def _in_scope(self, path: str) -> bool:\n        return self._scope(path) is not None\n\n    def _in_protected_scope(self, path: str) -> bool:\n        return self._scope(path) == "protected"\n'),
    ('aegis/agent.py',
     '        # A high-entropy WRITE to a protected file is encryption in progress —\n        # block it. This is language-agnostic: C, Go, Rust, bash+openssl, or an\n        # AI-generated encryptor all produce high-entropy ciphertext.\n        d = self.config["detection"]\n        if (entropy is not None and entropy >= d["entropy_threshold"]\n                and (size or 0) >= max(512, d["entropy_min_bytes"])):\n            return Decision.DENY\n',
     '        # No entropy-based block at permission time: the file still holds its\n        # OLD content then, so a high reading means "this is a photo or an\n        # archive", not "this is being encrypted" (blocking on it froze photo\n        # editors and archivers). The kernel sensor scores the bytes actually\n        # written on FAN_CLOSE_WRITE and contains the writer from there.\n'),
    ('aegis/agent.py',
     '        context = dict(context or {})\n        context.pop("event", None)\n',
     '        context = dict(context or {})\n        event = context.pop("event", None)\n        path = getattr(event, "dest", None) or getattr(event, "src", None)\n        if (path and not self.config.get("watch_only_contain", True)\n                and self._scope(path) == "watch"):\n            context["alert_only"] = True  # watch-only tier set to alert-only\n'),
    ('aegis/agent.py',
     '    def start(self) -> str:\n        for d in self.protected_dirs:\n',
     '    def start(self) -> str:\n        if not self.protected_dirs and not self.watch_only_dirs:\n            raise RuntimeError("no existing folders to protect or watch")\n        for d in self.protected_dirs:\n'),
    ('aegis/agent.py',
     '                             protected_dirs=self.protected_dirs,\n                             dry_run=self.dry_run)\n',
     '                             protected_dirs=self.protected_dirs,\n                             watch_only_dirs=self.watch_only_dirs,\n                             dry_run=self.dry_run)\n'),
    ('aegis/agent.py',
     '        print(f"[aegis] watching {len(self.protected_dirs)} dir(s); baseline "\n',
     '        print(f"[aegis] rollback tier: {len(self.protected_dirs)} dir(s); "\n              f"watch-only tier: {len(self.watch_only_dirs)} dir(s); baseline "\n'),
    ('aegis/config.py',
     '    "protected_dirs": [],\n',
     '    "protected_dirs": [],\n    # Full-drive mode: folders watched for ransomware behaviour, with the\n    # attacker contained, but NOT snapshotted (no rollback). Drive roots and\n    # the home folder are fine here.\n    "watch_only_dirs": [],\n    # Extra paths ignored inside watch-only folders (caches, build output).\n    "watch_only_exclude": [],\n    # Suspend/kill an attacker seen only in watch-only folders (False = alert).\n    "watch_only_contain": True,\n'),
    ('aegis/config.py',
     '    cfg["protected_dirs"] = dirs\n',
     '    cfg["protected_dirs"] = dirs\n    for key in ("watch_only_dirs", "watch_only_exclude"):\n        extra = cfg.get(key)\n        if extra is None:\n            extra = []\n        if isinstance(extra, str):\n            extra = [extra]\n        if not isinstance(extra, list) or not all(isinstance(d, str)\n                                                  for d in extra):\n            raise RuntimeError(f"{key} must be a list of directory paths")\n        cfg[key] = extra\n'),
    ('aegis/sensors/watchdog_sensor.py',
     'from ..events import Event, EventKind\n',
     'from ..events import Event, EventKind\nfrom ..fulldrive import under\n'),
    ('aegis/sensors/watchdog_sensor.py',
     'class WatchdogSensor:\n',
     'def _outermost(dirs, n):\n    """Drop folders nested inside another listed folder (and duplicates)."""\n    keys = [n(d) for d in dirs]\n    out, taken = [], set()\n    for key, d in zip(keys, dirs):\n        if key in taken or any(o != key and under(key, o) for o in keys):\n            continue\n        taken.add(key)\n        out.append(d)\n    return out\n\n\nclass WatchdogSensor:\n'),
    ('aegis/sensors/watchdog_sensor.py',
     '    def __init__(self, agent):\n        self.agent = agent\n',
     '    def __init__(self, agent, only_scope=None):\n        self.agent = agent\n        # "watch" = run beside the kernel sensor, covering only the\n        # watch-only tier (the kernel sensor owns the rollback tier)\n        self.only_scope = only_scope\n'),
    ('aegis/sensors/watchdog_sensor.py',
     '            if not self.agent._in_scope(target):\n                return\n',
     '            if self.only_scope:\n                if self.agent._scope(target) != self.only_scope:\n                    return\n            elif not self.agent._in_scope(target):\n                return\n'),
    ('aegis/sensors/watchdog_sensor.py',
     '    def start(self):\n        for d in self.agent.protected_dirs:\n            self._obs.schedule(self._handler, d, recursive=True)\n        self._obs.start()\n',
     '    def start(self):\n        """Watch only the outermost folders (nested watches would report each\n        event twice). Watch-only folders are best effort: one that cannot be\n        watched (e.g. the Linux inotify watch limit on a huge home folder) is\n        reported and skipped, and protected folders inside it are watched\n        directly instead."""\n        n = self.agent.plat.normcase\n        protected = list(self.agent.protected_dirs)\n        watch = list(getattr(self.agent, "watch_only_dirs", []) or [])\n        self.unwatched = []\n        self._obs.start()\n        try:\n            covered = []\n            for root in _outermost(watch, n):\n                try:\n                    self._obs.schedule(self._handler, root, recursive=True)\n                    covered.append(n(root))\n                except Exception as exc:\n                    self.unwatched.append(root)\n                    print(f"[aegis] watch-only folder NOT watched "\n                          f"({exc.__class__.__name__}: {exc}): {root}",\n                          flush=True)\n            for d in _outermost(protected, n):\n                if self.only_scope == "watch":\n                    break  # the kernel sensor watches the rollback tier\n                if not any(under(n(d), c) for c in covered):\n                    self._obs.schedule(self._handler, d, recursive=True)\n        except BaseException:\n            self.stop()\n            raise\n'),
    ('aegis/sensors/fanotify_sensor.py',
     '        if not self.agent._in_scope(path):\n',
     '        if not self.agent._in_protected_scope(path):\n'),
    ('aegis/sensors/fanotify_sensor.py',
     'FAN_OPEN_EXEC_PERM = 0x00040000\n',
     'FAN_OPEN_EXEC_PERM = 0x00040000\nFAN_CLOSE_WRITE = 0x00000008\n_FRESH_MAX = 4096\n'),
    ('aegis/sensors/fanotify_sensor.py',
     '        mask = FAN_OPEN_PERM | FAN_ACCESS_PERM\n',
     '        mask = FAN_OPEN_PERM | FAN_ACCESS_PERM | FAN_CLOSE_WRITE\n'),
    ('aegis/sensors/fanotify_sensor.py',
     '        self._worker: threading.Thread | None = None\n',
     '        self._worker: threading.Thread | None = None\n        # paths that were empty when opened = files being created; their\n        # first FAN_CLOSE_WRITE is reported as a creation (ransom notes,\n        # files written under a ransomware extension)\n        self._fresh: dict[str, None] = {}\n'),
    ('aegis/sensors/fanotify_sensor.py',
     '            if mask & (FAN_OPEN_PERM | FAN_ACCESS_PERM | FAN_OPEN_EXEC_PERM):\n                self._answer(fd, pid, mask)\n            elif fd >= 0:\n',
     '            if mask & (FAN_OPEN_PERM | FAN_ACCESS_PERM | FAN_OPEN_EXEC_PERM):\n                self._answer(fd, pid, mask)\n            elif mask & FAN_CLOSE_WRITE:\n                self._notify_write(fd, pid)\n            elif fd >= 0:\n'),
    ('aegis/sensors/fanotify_sensor.py',
     '    @staticmethod\n    def _pid_has_write_open',
     '    def _mark_fresh(self, path: str) -> None:\n        self._fresh[path] = None\n        while len(self._fresh) > _FRESH_MAX:\n            self._fresh.pop(next(iter(self._fresh)))\n\n    def _notify_write(self, fd: int, pid: int):\n        # FAN_CLOSE_WRITE: a file was written and closed. This is what gets\n        # scored: exact writer pid and the entropy of the bytes now on disk.\n        try:\n            if fd < 0 or not pid or pid == self._self_pid:\n                return\n            path = os.readlink(f"/proc/self/fd/{fd}")\n            if path.startswith(self.agent.state_dir + os.sep):\n                return\n            if not self.agent._in_protected_scope(path):\n                return\n            created = path in self._fresh\n            self._fresh.pop(path, None)\n            entropy = size = None\n            try:\n                data = os.pread(fd, 32768, 0)\n                from ..heuristics import shannon_entropy\n                entropy, size = (shannon_entropy(data), len(data)) if data \\\n                    else (0.0, 0)\n            except OSError:\n                pass\n            exe = None\n            try:\n                exe = os.readlink(f"/proc/{pid}/exe")\n            except OSError:\n                pass\n            canary = self.agent.canaries.is_canary(path)\n            try:\n                self._work.put_nowait(("write", path, pid, exe, entropy, size,\n                                       canary, created))\n            except queue.Full:\n                pass\n        except Exception as exc:\n            print(f"[aegis] fanotify write event error: {exc!r}", flush=True)\n        finally:\n            if fd >= 0:\n                try:\n                    os.close(fd)\n                except OSError:\n                    pass\n\n    @staticmethod\n    def _pid_has_write_open'),
    ('aegis/sensors/fanotify_sensor.py',
     '        # Fast canary/known-extension verdict needs NO fd read.\n        entropy = size = None\n        if not canary:\n            try:\n                from .. import intel\n                if not intel.is_ransom_extension(path):\n                    data = os.pread(fd, 32768, 0)\n                    if data:\n                        from ..heuristics import shannon_entropy\n                        entropy, size = shannon_entropy(data), len(data)\n            except OSError:\n                pass\n',
     '        # No entropy read here: at permission time the file still holds its\n        # OLD content. Written bytes are scored on FAN_CLOSE_WRITE instead.\n        entropy = size = None\n        try:\n            if os.fstat(fd).st_size == 0:  # being created (or empty)\n                self._mark_fresh(path)\n        except OSError:\n            pass\n'),
    ('aegis/sensors/fanotify_sensor.py',
     '        try:\n            self._work.put_nowait((path, pid, exe, entropy, size, canary,\n                                   verdict))\n        except queue.Full:\n            pass\n',
     '        # Opens are not scored (a reader is not an attacker). Only a blocked\n        # write or a canary touch goes to the engine from here.\n        if verdict == Decision.DENY or canary:\n            try:\n                self._work.put_nowait((path, pid, exe, entropy, size, canary,\n                                       verdict))\n            except queue.Full:\n                pass\n'),
    ('aegis/sensors/fanotify_sensor.py',
     '            path, pid, exe, entropy, size, canary, verdict = item\n            try:\n                if verdict == Decision.DENY and self._copy_before_block:\n                    try:\n                        self.agent.journal.capture_pre_modification(path)\n                    except Exception:\n                        pass\n                ev = Event(kind=EventKind.FILE_MODIFY, path=path, pid=pid,\n                           exe=exe, entropy=entropy, size=size, canary=canary,\n                           source="fanotify", blockable=True)\n',
     '            if item[0] == "write":\n                _, path, pid, exe, entropy, size, canary, created = item\n                verdict = Decision.ALLOW\n                kind = EventKind.FILE_CREATE if created else EventKind.FILE_MODIFY\n            else:\n                path, pid, exe, entropy, size, canary, verdict = item\n                kind = EventKind.FILE_MODIFY\n            try:\n                if verdict == Decision.DENY and self._copy_before_block:\n                    try:\n                        self.agent.journal.capture_pre_modification(path)\n                    except Exception:\n                        pass\n                ev = Event(kind=kind, path=path, pid=pid,\n                           exe=exe, entropy=entropy, size=size, canary=canary,\n                           source="fanotify", blockable=item[0] != "write")\n'),
    ('aegis/sensors/__init__.py',
     'def build_sensor(agent):\n',
     'class _Combined:\n    # Kernel sensor for the rollback tier plus the user-space watcher for\n    # the watch-only tier.\n\n    def __init__(self, primary, secondary):\n        self.primary, self.secondary = primary, secondary\n        self.blocking = getattr(primary, "blocking", False)\n\n    def start(self):\n        self.primary.start()\n        try:\n            self.secondary.start()\n        except BaseException:\n            self.primary.stop()\n            raise\n\n    def stop(self):\n        for sensor in (self.secondary, self.primary):\n            try:\n                sensor.stop()\n            except Exception:\n                pass\n\n\ndef build_sensor(agent):\n'),
    ('aegis/sensors/__init__.py',
     '                return FanotifySensor(agent), "kernel (fanotify, pre-write block)"\n',
     '                kernel = FanotifySensor(agent)\n                if getattr(agent, "watch_only_dirs", None):\n                    from .watchdog_sensor import WatchdogSensor\n                    return (_Combined(kernel, WatchdogSensor(agent, "watch")),\n                            "kernel (fanotify, pre-write block) + userspace "\n                            "watch-only tier")\n                return kernel, "kernel (fanotify, pre-write block)"\n'),
    ('aegis/cli.py',
     'def _write_dirs_to_config(path: str, dirs: list[str]) -> None:\n    import yaml\n    path = write_default_config(path)\n    with open(path, "r", encoding="utf-8") as fh:\n        data = yaml.safe_load(fh) or {}\n    data["protected_dirs"] = dirs\n',
     'def _write_dirs_to_config(path: str, dirs: list[str],\n                          watch: list[str] | None = None) -> None:\n    import yaml\n    path = write_default_config(path)\n    with open(path, "r", encoding="utf-8") as fh:\n        data = yaml.safe_load(fh) or {}\n    data["protected_dirs"] = dirs\n    if watch is not None:\n        data["watch_only_dirs"] = watch\n'),
    ('aegis/cli.py',
     '    if getattr(args, "full_drive", False):\n        home = os.path.realpath(os.path.expanduser("~"))\n        chosen = [home]\n        if plat.name == "windows":\n            import string\n            for letter in string.ascii_uppercase:\n                drive = f"{letter}:\\\\"\n                if os.path.isdir(drive):\n                    chosen.append(drive)\n        print(f"Full-drive protection: {chosen}")\n',
     '    watch = None\n    if getattr(args, "full_drive", False):\n        from .fulldrive import apply_full_drive\n        chosen, watch = apply_full_drive({}, plat)\n        print("Full-drive mode")\n        print(f"  rollback tier (snapshotted): {chosen or \'none found\'}")\n        print(f"  watch-only tier (detect + contain): {watch}")\n'),
    ('aegis/cli.py',
     '    _write_dirs_to_config(path, chosen)\n',
     '    _write_dirs_to_config(path, chosen, watch)\n'),
    ('aegis/cli.py',
     '    if not dirs:\n        sys.exit("no protected_dirs configured — run `aegis setup` or edit "\n',
     '    if not dirs and not cfg.get("watch_only_dirs"):\n        sys.exit("no protected_dirs configured — run `aegis setup` or edit "\n'),
    ('aegis/gui.py',
     '    def _refresh_folder_list(self):\n        for w in self._folder_items:\n            w.destroy()\n        self._folder_items.clear()\n        dirs = self.cfg.get("protected_dirs", [])\n        if not dirs:\n            lbl = ctk.CTkLabel(self._folder_list,\n                               text="No folders protected yet. Add one below.",\n                               font=FONT_BODY, text_color=C_DIM)\n            lbl.pack(pady=30)\n            self._folder_items.append(lbl)\n            return\n        for d in dirs:\n            row = ctk.CTkFrame(self._folder_list, fg_color="transparent")\n            row.pack(fill="x", padx=12, pady=4)\n            exists = os.path.isdir(d)\n            icon = "✓" if exists else "✗"\n            color = C_GREEN if exists else C_RED\n            ctk.CTkLabel(row, text=icon, font=FONT_BADGE,\n                         text_color=color, width=24).pack(side="left")\n            ctk.CTkLabel(row, text=d, font=FONT_MONO,\n                         text_color=C_TEXT).pack(side="left", padx=8)\n            ctk.CTkButton(row, text="Remove", font=FONT_SMALL, width=70,\n                          height=26, corner_radius=6, fg_color="#da3633",\n                          hover_color="#b62324",\n                          command=lambda p=d: self._remove_folder(p)).pack(\n                side="right")\n            self._folder_items.append(row)\n',
     '    def _refresh_folder_list(self):\n        for w in self._folder_items:\n            w.destroy()\n        self._folder_items.clear()\n        dirs = self.cfg.get("protected_dirs", []) or []\n        watch = self.cfg.get("watch_only_dirs", []) or []\n        if not dirs and not watch:\n            lbl = ctk.CTkLabel(self._folder_list,\n                               text="No folders protected yet. Add one below.",\n                               font=FONT_BODY, text_color=C_DIM)\n            lbl.pack(pady=30)\n            self._folder_items.append(lbl)\n            return\n        rows = [(d, "rollback") for d in dirs] + [(d, "watch-only")\n                                                   for d in watch]\n        for d, tier in rows:\n            row = ctk.CTkFrame(self._folder_list, fg_color="transparent")\n            row.pack(fill="x", padx=12, pady=4)\n            exists = os.path.isdir(d)\n            icon = "✓" if exists else "✗"\n            color = C_GREEN if exists else C_RED\n            ctk.CTkLabel(row, text=icon, font=FONT_BADGE,\n                         text_color=color, width=24).pack(side="left")\n            ctk.CTkLabel(row, text=tier, font=FONT_SMALL, width=80,\n                         text_color=C_GREEN if tier == "rollback"\n                         else C_DIM).pack(side="left")\n            ctk.CTkLabel(row, text=d, font=FONT_MONO,\n                         text_color=C_TEXT).pack(side="left", padx=8)\n            ctk.CTkButton(row, text="Remove", font=FONT_SMALL, width=70,\n                          height=26, corner_radius=6, fg_color="#da3633",\n                          hover_color="#b62324",\n                          command=lambda p=d: self._remove_folder(p)).pack(\n                side="right")\n            self._folder_items.append(row)\n'),
    ('aegis/gui.py',
     '    def _protect_drive(self):\n        home = os.path.expanduser("~")\n        if home not in self.cfg.get("protected_dirs", []):\n            self.cfg.setdefault("protected_dirs", []).append(home)\n        # Windows: add data drives\n        if self.plat.name == "windows":\n            import string\n            for letter in string.ascii_uppercase:\n                drive = f"{letter}:\\\\"\n                if (os.path.isdir(drive)\n                        and drive not in self.cfg["protected_dirs"]):\n                    self.cfg["protected_dirs"].append(drive)\n        self.cfg["allow_dangerous_dirs"] = True\n        self._save_config()\n        self._refresh_folder_list()\n        self._refresh_status()\n        self._feed.append(f"[{_ts()}] Full drive protection enabled", C_GREEN)\n        tk.messagebox.showinfo(\n            "Full Drive Protection",\n            "Your home folder is now protected.\\n\\n"\n            "Note: the first start will snapshot your files into ~/.aegis for "\n            "rollback. On a large home folder this can take time and disk "\n            "space. Files over 100 MB (videos, VM images) are watched but not "\n            "snapshotted. You can raise that limit in Settings.")\n',
     '    def _protect_drive(self):\n        from .fulldrive import apply_full_drive\n        protected, watch = apply_full_drive(self.cfg, self.plat)\n        self._save_config()\n        self._refresh_folder_list()\n        self._refresh_status()\n        self._feed.append(f"[{_ts()}] Full drive protection enabled", C_GREEN)\n        tk.messagebox.showinfo(\n            "Full Drive Protection",\n            f"Rollback tier ({len(protected)} folder(s)): snapshotted at "\n            "start and restored after an attack. Your Documents, Desktop and "\n            "Pictures folders are added; add more on this page.\\n\\n"\n            f"Watch-only tier ({len(watch)} location(s)): your home folder and "\n            "every local drive are watched and an attacker is stopped, but "\n            "files there are not snapshotted. Recover those from shadow "\n            "copies / Time Machine or your own backups, so keep them on.")\n'),
    ('aegis/gui.py',
     '    def _remove_folder(self, path):\n        dirs = self.cfg.get("protected_dirs", [])\n        if path in dirs:\n            dirs.remove(path)\n',
     '    def _remove_folder(self, path):\n        removed = False\n        for key in ("protected_dirs", "watch_only_dirs"):\n            dirs = self.cfg.get(key) or []\n            if path in dirs:\n                dirs.remove(path)\n                removed = True\n        if removed:\n'),
    ('aegis/gui.py',
     '    def _start_agent(self):\n        dirs = self.cfg.get("protected_dirs", [])\n        if not dirs:\n',
     '    def _start_agent(self):\n        dirs = self.cfg.get("protected_dirs", [])\n        if not dirs and not self.cfg.get("watch_only_dirs"):\n'),
    ('aegis/agent.py',
     '        for comp in (self.sensor, self.egress, self.integrity,\n',
     '        for comp in (self.sensor, self.egress, self.integrity_mon,\n                     self.proc_guard,\n'),
]
# --- END EMBEDDED SOURCES ---



def clean_extract(source_bytes: bytes, dest: Path) -> Path:
    """Extract a trusted-size ZIP without following traversal or symlink entries."""
    if len(source_bytes) > MAX_ARCHIVE_BYTES:
        raise ValueError("Archive exceeds allowed download size")
    with zipfile.ZipFile(io.BytesIO(source_bytes)) as archive:
        members = archive.infolist()
        if len(members) > MAX_ENTRIES:
            raise ValueError("Too many archive entries")
        total = 0
        seen = set()
        modes = {}
        for info in members:
            name = info.filename.replace("\\", "/")
            part = PurePosixPath(name)
            if (not name.startswith("Aegis/") or part.is_absolute() or
                    any(x in ("..", "") or ":" in x for x in part.parts) or
                    len(part.parts) < 2):
                if name == "Aegis/":
                    continue
                raise ValueError("Unsafe archive path: " + repr(name))
            key = name.rstrip("/").lower()  # Windows/macOS are case-insensitive
            if key in seen:
                raise ValueError("Duplicate archive path: " + name)
            seen.add(key)
            file_type = (info.external_attr >> 16) & 0o170000
            if file_type == stat.S_IFLNK:
                raise ValueError("Symlink entries are not accepted")
            if info.file_size > MAX_FILE_BYTES:
                raise ValueError("Oversized archive member")
            total += info.file_size
            if total > MAX_UNPACKED_BYTES:
                raise ValueError("Unpacked archive too large")
            out = dest.joinpath(*part.parts)
            if info.is_dir():
                out.mkdir(parents=True, exist_ok=True)
                continue
            out.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as src, out.open("xb") as dst:
                shutil.copyfileobj(src, dst)
            unix_mode = (info.external_attr >> 16) & 0o777
            modes[PurePosixPath(*part.parts[1:]).as_posix()] = (
                0o755 if unix_mode & 0o111 else 0o644)
        root = dest / "Aegis"
        for required in ("aegis/agent.py", "aegis/gui.py", "aegis/journal.py",
                         "README.md", "LICENSE", "tests/test_journal.py"):
            if not (root / required).is_file():
                raise ValueError("Not the expected Aegis package: missing " + required)
        (root / MODES_FILE).write_text(repr(modes), encoding="utf-8")
        return root


def replace_once(path: Path, before: str, after: str) -> None:
    with path.open("r", encoding="utf-8", newline="") as fh:
        src = fh.read()
    if "\r\n" in src:  # keep the file's own line endings
        before, after = before.replace("\n", "\r\n"), after.replace("\n", "\r\n")
    if after in src and before not in src:
        return
    if src.count(before) != 1:
        raise ValueError(f"Patch mismatch in {path}: expected one exact anchor, got {src.count(before)}")
    path.write_text(src.replace(before, after, 1), encoding="utf-8", newline="")


def write_text_exact(path: Path, text: str, crlf: bool = False) -> None:
    """Write with fixed line endings whatever OS runs the kit.

    Path.write_text() converts LF to CRLF on Windows, which breaks the
    generated shell script ("/bin/sh^M: bad interpreter") on Linux/macOS.
    """
    data = text.replace("\r\n", "\n")
    if crlf:
        data = data.replace("\n", "\r\n")
    path.write_bytes(data.encode("utf-8"))


def apply_patches(root: Path) -> None:
    replace_once(root / "aegis" / "agent.py",
                 "rp = os.path.realpath(d)",
                 "rp = os.path.realpath(os.path.expanduser(d))")
    # GUI feed timestamps: honour epoch 0 and show the user's local time.
    # Upstream formatted in UTC, so the activity feed was hours off for most users.
    gui = root / "aegis" / "gui.py"
    replace_once(gui,
                 "datetime.fromtimestamp(epoch or time.time(),\n"
                 "                                 tz=timezone.utc).strftime(\"%H:%M:%S\")",
                 "datetime.fromtimestamp(\n"
                 "        epoch if epoch is not None else time.time()).strftime(\"%H:%M:%S\")")
    replace_once(gui, "from datetime import datetime, timezone\n", "from datetime import datetime\n")
    # Full-drive mode (hybrid): rollback tier + watch-only tier.
    for rel, before, after in PATCHES:
        replace_once(root / rel, before, after)
    write_text_exact(root / "aegis" / "fulldrive.py", FULLDRIVE_MODULE)
    write_text_exact(root / "aegis" / "diagnostics.py", DIAGNOSTICS_MODULE)
    write_text_exact(root / "tests" / "test_review_regressions.py", REGRESSION_TESTS)
    write_text_exact(root / "tests" / "test_full_drive.py", FULLDRIVE_TESTS)
    write_text_exact(root / "tests" / "test_kernel_write_scoring.py", KERNEL_TESTS)
    write_text_exact(root / "aegis" / "launcher.py", LAUNCHER_MODULE)
    # Windows installer, launchers and icon come from the kit itself.
    for rel, dest in KIT_FILES.items():
        target = root / dest
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(kit_file(rel))
    # One text file for people: the README. The reviewed-build notes go into
    # it instead of separate files, and the upstream changelog is dropped.
    readme = root / "README.md"
    text = readme.read_bytes().decode("utf-8")
    if README_MARKER not in text:
        write_text_exact(readme, text.rstrip("\n") + "\n" + README_SECTION)
    (root / "CHANGELOG.md").unlink(missing_ok=True)
    write_text_exact(root / "Run_Diagnostics.cmd",
                     "@echo off\n"
                     "cd /d \"%~dp0\"\n"
                     "if exist .venv\\Scripts\\python.exe (\n"
                     "  .venv\\Scripts\\python.exe -m aegis.diagnostics %*\n"
                     ") else (\n"
                     "  python -m aegis.diagnostics %*\n"
                     ")\n"
                     "pause\n", crlf=True)
    write_text_exact(root / "run_diagnostics.sh",
                     "#!/bin/sh\n"
                     "cd \"$(dirname \"$0\")\" || exit 1\n"
                     "if [ -x .venv/bin/python ]; then exec .venv/bin/python -m aegis.diagnostics \"$@\"; fi\n"
                     "exec python3 -m aegis.diagnostics \"$@\"\n")


def load_modes(root: Path) -> dict:
    """Permission bits recorded from the original archive, plus our scripts."""
    modes_path = root / MODES_FILE
    modes = ast.literal_eval(modes_path.read_text(encoding="utf-8")) if modes_path.exists() else {}
    if modes_path.exists():
        modes_path.unlink()
    modes.update(GENERATED_MODES)
    return modes


def apply_local_modes(root: Path, modes: dict) -> None:
    if os.name == "nt":
        return
    for rel, mode in modes.items():
        target = root / rel
        if target.is_file():
            target.chmod(mode)


def package(root: Path, output: Path, modes: dict | None = None) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError("Output already exists: " + str(output))
    modes = modes or {}
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as archive:
        for p in sorted(root.rglob("*")):
            if p.is_file():
                rel = p.relative_to(root).as_posix()
                info = zipfile.ZipInfo.from_file(p, "Aegis/" + rel)
                info.create_system = 3  # Unix, so permission bits are honoured
                info.external_attr = (stat.S_IFREG | modes.get(rel, 0o644)) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, p.read_bytes(), compresslevel=9)


def git_blob_sha(data: bytes) -> str:
    """Verify the original archive against GitHub's immutable blob ID."""
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def download_source() -> bytes:
    req = urllib.request.Request(SOURCE_URL, headers={"User-Agent": "Aegis-Upgrade-Kit/1.0"})
    with urllib.request.urlopen(req, timeout=25) as response:
        data = response.read(MAX_ARCHIVE_BYTES + 1)
    if len(data) > MAX_ARCHIVE_BYTES:
        raise ValueError("Download exceeds limit")
    if git_blob_sha(data) != EXPECTED_BLOB_SHA:
        raise ValueError("Upstream ZIP integrity verification failed")
    return data


def upgrade(source: bytes, output: Path, keep_source_folder: Path | None = None) -> None:
    if output.exists():
        raise FileExistsError("Output already exists: " + str(output))
    if keep_source_folder and keep_source_folder.exists():
        raise FileExistsError("Source folder already exists: " + str(keep_source_folder))
    with tempfile.TemporaryDirectory(prefix="aegis-reviewed-") as tmp:
        root = clean_extract(source, Path(tmp) / "src")
        apply_patches(root)
        modes = load_modes(root)
        apply_local_modes(root, modes)
        staged = Path(tmp) / "staged.zip"
        package(root, staged, modes)
        # Only now touch the user's folders, and never leave half-written output.
        copied = False
        try:
            if keep_source_folder:
                shutil.copytree(root, keep_source_folder)
                copied = True
            output.parent.mkdir(parents=True, exist_ok=True)
            with staged.open("rb") as src, output.open("xb") as dst:
                shutil.copyfileobj(src, dst)
        except BaseException:
            if copied:
                shutil.rmtree(keep_source_folder, ignore_errors=True)
            if output.exists() and output.stat().st_size != staged.stat().st_size:
                output.unlink()
            raise


def main(argv=None):
    parser = argparse.ArgumentParser(description="Upgrade Aegis Defender without overwriting your original")
    parser.add_argument("--source", type=Path, help="Path to the original Aegis_Defender.zip; optional with internet")
    parser.add_argument("--allow-modified-source", action="store_true",
                        help="Allow a user-supplied ZIP with different hash (inspect it first)")
    parser.add_argument("--output", type=Path, default=Path("Aegis_Defender_Improved.zip"))
    parser.add_argument("--keep-source-folder", type=Path, help="Optional separate reviewed source tree")
    args = parser.parse_args(argv)
    try:
        source = args.source.read_bytes() if args.source else download_source()
        if args.source and not args.allow_modified_source and git_blob_sha(source) != EXPECTED_BLOB_SHA:
            raise ValueError("Local ZIP differs from the verified GitHub revision; "
                             "pass --allow-modified-source only after reviewing your ZIP")
        upgrade(source, args.output, args.keep_source_folder)
    except Exception as exc:
        parser.exit(1, f"Upgrade failed safely: {type(exc).__name__}: {exc}\n")
    print("Created:", args.output.resolve())
    print("Original installation and source ZIP remain unchanged.")
    print("On Windows, run Install_Aegis_Defender.bat from the kit to install it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
